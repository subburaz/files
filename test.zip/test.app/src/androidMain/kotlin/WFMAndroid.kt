package com.genesys.purecloud.wfmsharedandroid

import android.content.Context
import com.genesys.purecloud.wfmshared.BuildKonfig
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.util.resources.CommonStrings
import dev.icerock.moko.resources.StringResource
import org.kodein.di.erased.instance

fun populateCommonStrings(context: Context) {
    val commonStrings: CommonStrings by kodein.instance()

    val stringMap: Map<StringResource, String> = commonStrings.resourceMap.map {
        it.key to it.value.toString(context)
    }.toMap()

    commonStrings.update(stringMap)
}

val oauthClientId = BuildKonfig.OAUTH_CLIENT_ID
val oauthSecret = BuildKonfig.OAUTH_CLIENT_SECRET
