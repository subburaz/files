package com.genesys.purecloud.wfmshared.util.coroutines

import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.Dispatchers

internal actual val bgContext: CoroutineContext = Dispatchers.IO
internal actual val uiContext: CoroutineContext = Dispatchers.Main
