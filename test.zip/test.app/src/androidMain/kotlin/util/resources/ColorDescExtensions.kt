package com.genesys.purecloud.wfmsharedandroid.util.resources

import android.graphics.Color
import com.genesys.purecloud.wfmshared.util.resources.ColorDesc

val ColorDesc.toColor: Int
    get() = Color.parseColor(this.aarrggbb)
