package com.genesys.purecloud.wfmshared.util

import android.util.Log

internal actual object Logger {
    actual fun logVerbose(tag: String, message: String, cause: Throwable?) {
        Log.v(tag, message, cause)
    }

    actual fun logDebug(tag: String, message: String, cause: Throwable?) {
        Log.d(tag, message, cause)
    }

    actual fun logError(tag: String, message: String, cause: Throwable?) {
        Log.e(tag, message, cause)
    }
}
