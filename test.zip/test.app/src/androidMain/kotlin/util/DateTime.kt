package com.genesys.purecloud.wfmshared.util

import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit.StartDayOfWeek
import org.joda.time.DateTime as JodaDateTime
import org.joda.time.DateTimeConstants
import org.joda.time.DateTimeZone
import org.joda.time.format.ISODateTimeFormat

actual class DateTime internal constructor(
    private val utcDate: JodaDateTime
) : Comparable<DateTime> {
    actual fun plusSeconds(seconds: Int): DateTime {
        return DateTime(this.utcDate.plusSeconds(seconds))
    }

    actual fun minusSeconds(seconds: Int): DateTime {
        return DateTime(this.utcDate.minusSeconds(seconds))
    }

    actual fun plusMinutes(minutes: Int): DateTime {
        return DateTime(this.utcDate.plusMinutes(minutes))
    }

    actual fun minusMinutes(minutes: Int): DateTime {
        return DateTime(this.utcDate.minusMinutes(minutes))
    }

    actual fun plusDays(days: Int): DateTime {
        return DateTime(this.utcDate.plusDays(days))
    }

    actual fun minusDays(days: Int): DateTime {
        return DateTime(this.utcDate.minusDays(days))
    }

    actual fun startOfDay(timeZoneName: String): DateTime {
        val timeZone = DateTimeZone.forID(timeZoneName)
        val dateTimeInTz = this.utcDate.withZone(timeZone)
        val startDateTimeInTz = dateTimeInTz.withTimeAtStartOfDay()

        return DateTime(startDateTimeInTz.withZone(DateTimeZone.UTC))
    }

    private fun getDayOfWeek(startDayOfWeek: StartDayOfWeek): Int {
        return when (startDayOfWeek) {
            StartDayOfWeek.SUNDAY -> DateTimeConstants.SUNDAY
            StartDayOfWeek.MONDAY -> DateTimeConstants.MONDAY
            StartDayOfWeek.TUESDAY -> DateTimeConstants.TUESDAY
            StartDayOfWeek.WEDNESDAY -> DateTimeConstants.WEDNESDAY
            StartDayOfWeek.THURSDAY -> DateTimeConstants.THURSDAY
            StartDayOfWeek.FRIDAY -> DateTimeConstants.FRIDAY
            StartDayOfWeek.SATURDAY -> DateTimeConstants.SATURDAY
        }
    }

    actual fun startOfWeek(timeZoneName: String, startDayOfWeek: StartDayOfWeek): DateTime {
        val timeZone = DateTimeZone.forID(timeZoneName)
        val startOfDay = this.startOfDay(timeZoneName)
        val dateTimeInTz = startOfDay.utcDate.withZone(timeZone)
        val sdow = getDayOfWeek(startDayOfWeek)
        val weekday = dateTimeInTz.dayOfWeek().get()

        var daysToSubtract = weekday - sdow
        if (daysToSubtract < 0) {
            daysToSubtract += DAYS_PER_WEEK
        }

        return startOfDay.minusDays(daysToSubtract)
    }

    actual override fun equals(other: Any?): Boolean {
        if (other !is DateTime) {
            return false
        }

        return this.utcDate == other.utcDate
    }

    actual override fun hashCode(): Int {
        return this.utcDate.millis.hashCode()
    }

    actual override operator fun compareTo(other: DateTime): Int {
        return this.utcDate.compareTo(other.utcDate)
    }

    actual fun crossesDst(endDate: DateTime, timeZoneName: String): Boolean {
        val timeZone = DateTimeZone.forID(timeZoneName)
        return timeZone.isStandardOffset(this.utcDate.millis) != timeZone.isStandardOffset(endDate.utcDate.millis)
    }

    actual fun formatDate(formatString: String, timeZoneName: String): String {
        val timeZone = DateTimeZone.forID(timeZoneName)
        return this.utcDate.withZone(timeZone).toString(formatString)
    }

    actual fun isBefore(dateTime: DateTime): Boolean {
        return this.utcDate < dateTime.utcDate
    }

    actual fun isAfter(dateTime: DateTime): Boolean {
        return this.utcDate > dateTime.utcDate
    }

    actual companion object {
        actual fun parse(dateString: String): DateTime {
            try {
                return DateTime(ISODateTimeFormat.dateTimeParser().withZone(DateTimeZone.UTC).parseDateTime(dateString))
            } catch (ex: Exception) {
                throw IllegalArgumentException(INVALID_DATE_FORMAT_EXCEPTION_MESSAGE)
            }
        }

        actual fun now(): DateTime {
            return DateTime(JodaDateTime(DateTimeZone.UTC))
        }
    }

    val timeInMillis get() = utcDate.toCalendar(null).timeInMillis
}
