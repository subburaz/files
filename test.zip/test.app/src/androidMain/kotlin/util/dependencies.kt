package com.genesys.purecloud.wfmshared.util

actual val thirdPartyDependencies: List<ThirdPartyDependency> = listOf(
    *commonDependencies,

    ThirdPartyDependency(
        projectName = "joda-time",
        projectLink = "https://github.com/JodaOrg/joda-time",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/JodaOrg/joda-time/master/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "com.google.guava",
        projectLink = "https://github.com/google/guava",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/google/guava/master/COPYING"
    ),

    ThirdPartyDependency(
        projectName = "androidx.appcompat:appcompat",
        projectLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-release/appcompat/",
        licenseName = "Apache 2.0",
        licenseLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-dev/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "androidx.core:core-ktx",
        projectLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-release/core/core-ktx/",
        licenseName = "Apache 2.0",
        licenseLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-dev/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "androidx.constraintlayout:constraintlayout",
        projectLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-dev",
        licenseName = "Apache 2.0",
        licenseLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-dev/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "com.google.android.material:material",
        projectLink = "https://github.com/material-components/material-components-android",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/material-components/material-components-android/master/LICENSE"
    ),

    ThirdPartyDependency(
        projectName = "androidx.legacy:legacy-support",
        projectLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-dev",
        licenseName = "Apache 2.0",
        licenseLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-dev/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "material-calendarview",
        projectLink = "https://github.com/prolificinteractive/material-calendarview",
        licenseName = "MIT License",
        licenseLink = "https://raw.githubusercontent.com/prolificinteractive/material-calendarview/master/LICENSE"
    ),

    ThirdPartyDependency(
        projectName = "slf4j-android",
        projectLink = "https://github.com/twwwt/slf4j/tree/master/slf4j-android",
        licenseName = "MIT License",
        licenseLink = "https://raw.githubusercontent.com/twwwt/slf4j/master/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "androidx.navigation",
        projectLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-release/navigation/",
        licenseName = "Apache 2.0",
        licenseLink = "https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-master-dev/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "com.squareup.retrofit:retrofit",
        projectLink = "https://github.com/square/retrofit",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/square/retrofit/master/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "com.squareup:otto",
        projectLink = "https://github.com/square/otto",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/square/otto/master/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "io.reactivex:rxjava",
        projectLink = "https://github.com/ReactiveX/RxJava",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/ReactiveX/RxJava/3.x/LICENSE"
    ),

    ThirdPartyDependency(
        projectName = "io.reactivex:rxandroid",
        projectLink = "https://github.com/ReactiveX/RxAndroid",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/ReactiveX/RxAndroid/3.x/LICENSE"
    ),

    ThirdPartyDependency(
        projectName = "Firebase SDK",
        projectLink = "https://github.com/firebase/firebase-android-sdk",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/firebase/firebase-android-sdk/master/LICENSE"
    )
)
