package com.genesys.purecloud.wfmshared.testutil

actual fun overrideTimeZone(timeZoneName: String?) {
    TODO("Figure out how to do this on iOS")
}
