package com.genesys.purecloud.wfmshared.testutil

import com.genesys.purecloud.wfmshared.util.coroutines.WFMSharedScope
import com.genesys.purecloud.wfmshared.util.mainDispatcher
import kotlinx.coroutines.CoroutineScope

val testScope = WFMSharedScope(mainDispatcher)

actual fun getTestCoroutineBGScope(): CoroutineScope {
    return testScope
}

actual fun getTestCoroutineUIScope(): CoroutineScope {
    return testScope
}
