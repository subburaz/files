package com.genesys.purecloud.wfmshared.util.resources

import com.genesys.purecloud.wfmsharedios.util.resources.toColor
import kotlin.test.Test
import kotlin.test.assertEquals
import platform.UIKit.UIColor

class ColorDescExtensionsTests {
    @Test
    fun `ColorDesc.toColor should work for red #RGB`() {
        val actual = ColorDesc("#F00").toColor
        assertEquals(UIColor.redColor, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for red #RRGGBB`() {
        val actual = ColorDesc("#FF0000").toColor
        assertEquals(UIColor.redColor, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for red #AARRGGBB`() {
        val actual = ColorDesc("#FFFF0000").toColor
        assertEquals(UIColor.redColor, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for green #RGB`() {
        val actual = ColorDesc("#0F0").toColor
        assertEquals(UIColor.greenColor, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for green #RRGGBB`() {
        val actual = ColorDesc("#00FF00").toColor
        assertEquals(UIColor.greenColor, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for green #AARRGGBB`() {
        val actual = ColorDesc("#FF00FF00").toColor
        assertEquals(UIColor.greenColor, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for blue #RGB`() {
        val actual = ColorDesc("#00F").toColor
        assertEquals(UIColor.blueColor, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for blue #RRGGBB`() {
        val actual = ColorDesc("#0000FF").toColor
        assertEquals(UIColor.blueColor, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for blue #AARRGGBB`() {
        val actual = ColorDesc("#FF0000FF").toColor
        assertEquals(UIColor.blueColor, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for no alpha #AARRGGBB`() {
        val actual = ColorDesc("#00FF4F1F").toColor
        val expected = UIColor(
            red = 0xFF / 255.0,
            green = 0x4F / 255.0,
            blue = 0x1F / 255.0,
            alpha = 0x00 / 255.0
        )
        assertEquals(expected, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for some alpha #AARRGGBB`() {
        val actual = ColorDesc("#80FF4F1F").toColor
        val expected = UIColor(
            red = 0xFF / 255.0,
            green = 0x4F / 255.0,
            blue = 0x1F / 255.0,
            alpha = 0x80 / 255.0
        )
        assertEquals(expected, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for warm red color`() {
        val actual = ColorDesc("#FF4F1F").toColor
        val expected = UIColor(
            red = 0xFF / 255.0,
            green = 0x4F / 255.0,
            blue = 0x1F / 255.0,
            alpha = 0xFF / 255.0
        )
        assertEquals(expected, actual)
    }

    @Test
    fun `ColorDesc.toColor should work for plum color`() {
        val actual = ColorDesc("#5d3d5e").toColor
        val expected = UIColor(
            red = 0x5d / 255.0,
            green = 0x3d / 255.0,
            blue = 0x5e / 255.0,
            alpha = 0xFF / 255.0
        )
        assertEquals(expected, actual)
    }
}
