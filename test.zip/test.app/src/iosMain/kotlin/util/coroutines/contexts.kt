package com.genesys.purecloud.wfmshared.util.coroutines

import com.genesys.purecloud.wfmshared.util.mainDispatcher
import kotlin.coroutines.CoroutineContext

// Use the main queue for both UI and BG, coroutines don't support multithreaded communication on iOS at the moment
// https://github.com/Kotlin/kotlinx.coroutines/issues/462

internal actual val bgContext: CoroutineContext = mainDispatcher
internal actual val uiContext: CoroutineContext = mainDispatcher
