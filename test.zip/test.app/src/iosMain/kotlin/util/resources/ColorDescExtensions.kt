package com.genesys.purecloud.wfmsharedios.util.resources

import com.genesys.purecloud.wfmshared.util.resources.ColorDesc
import com.genesys.purecloud.wfmshared.util.resources.HEX_COLOR_VALUE_START_INDEX
import platform.UIKit.UIColor

private const val HEX_COLOR_BYTE_LENGTH = 2

private const val ARGB_ALPHA_INDEX = 0
private const val ARGB_RED_INDEX = 1
private const val ARGB_GREEN_INDEX = 2
private const val ARGB_BLUE_INDEX = 3

private const val HEXADECIMAL_RADIX = 16
private const val MAX_COLOR_VALUE = 255.0

val ColorDesc.toColor: UIColor
    get() {
        val argb = this.aarrggbb
            .substring(startIndex = HEX_COLOR_VALUE_START_INDEX)
            .chunkedSequence(size = HEX_COLOR_BYTE_LENGTH)
            .map {
                it.toInt(radix = HEXADECIMAL_RADIX) / MAX_COLOR_VALUE
            }
            .toList()

        return UIColor(
            red = argb[ARGB_RED_INDEX],
            green = argb[ARGB_GREEN_INDEX],
            blue = argb[ARGB_BLUE_INDEX],
            alpha = argb[ARGB_ALPHA_INDEX]
        )
    }
