package com.genesys.purecloud.wfmshared.util

import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit.StartDayOfWeek
import com.genesys.purecloud.wfmshared.serviceLocator
import platform.Foundation.NSCalendar
import platform.Foundation.NSCalendarUnitWeekday
import platform.Foundation.NSDate
import platform.Foundation.NSDateFormatter
import platform.Foundation.NSISO8601DateFormatWithFullDate
import platform.Foundation.NSISO8601DateFormatter
import platform.Foundation.NSLocale
import platform.Foundation.NSOrderedAscending
import platform.Foundation.NSOrderedDescending
import platform.Foundation.NSOrderedSame
import platform.Foundation.NSTimeZone
import platform.Foundation.compare
import platform.Foundation.create
import platform.Foundation.dateByAddingTimeInterval
import platform.Foundation.dateWithTimeInterval
import platform.Foundation.localTimeZone

private val dateParser = NSISO8601DateFormatter()
private val dateTimeParser = NSISO8601DateFormatter()

private val dateFormatter = NSDateFormatter()

private val dateRegex = Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}\$")
private val dateTimeRegex = Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z\$")
private val dateTimeFSRegex = Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}Z\$")

// The dateTime format "YYYY-MM-DDTHH:MM:SS.SSSZ" includes fractional seconds
// NSISO8601DateFormatter does not parse fractional seconds
// So declare the indices necessary for substring operations (remove fractional seconds)
private const val DATE_TIME_FS_SECONDS_END_INDEX = 18

actual class DateTime internal constructor(
    private val utcDate: NSDate
) : Comparable<DateTime> {
    actual fun plusSeconds(seconds: Int): DateTime {
        return DateTime(this.utcDate.dateByAddingTimeInterval(seconds.toDouble()))
    }

    actual fun minusSeconds(seconds: Int): DateTime {
        return DateTime(this.utcDate.dateByAddingTimeInterval(-seconds.toDouble()))
    }

    actual fun plusMinutes(minutes: Int): DateTime {
        return DateTime(this.utcDate.dateByAddingTimeInterval((minutes * SECONDS_PER_MINUTE).toDouble()))
    }

    actual fun minusMinutes(minutes: Int): DateTime {
        return DateTime(this.utcDate.dateByAddingTimeInterval(-(minutes * SECONDS_PER_MINUTE).toDouble()))
    }

    actual fun plusDays(days: Int): DateTime {
        return DateTime(this.utcDate.dateByAddingTimeInterval((days * SECONDS_PER_DAY).toDouble()))
    }

    actual fun minusDays(days: Int): DateTime {
        return DateTime(this.utcDate.dateByAddingTimeInterval(-(days * SECONDS_PER_DAY).toDouble()))
    }

    actual fun startOfDay(timeZoneName: String): DateTime {
        val timeZone: NSTimeZone = NSTimeZone.Companion.create(timeZoneName) ?: NSTimeZone.localTimeZone

        val calendar = NSCalendar.currentCalendar
        calendar.timeZone = timeZone

        val sod = calendar.startOfDayForDate(this.utcDate)

        return DateTime(sod)
    }

    private fun getDayOfWeek(startDayOfWeek: StartDayOfWeek): Int {
        return when (startDayOfWeek) {
            StartDayOfWeek.SUNDAY -> 1
            StartDayOfWeek.MONDAY -> 2
            StartDayOfWeek.TUESDAY -> 3
            StartDayOfWeek.WEDNESDAY -> 4
            StartDayOfWeek.THURSDAY -> 5
            StartDayOfWeek.FRIDAY -> 6
            StartDayOfWeek.SATURDAY -> 7
        }
    }

    actual fun startOfWeek(timeZoneName: String, startDayOfWeek: StartDayOfWeek): DateTime {
        val startOfDay = this.startOfDay(timeZoneName)

        val timeZone: NSTimeZone = NSTimeZone.Companion.create(timeZoneName) ?: NSTimeZone.localTimeZone

        val calendar = NSCalendar.currentCalendar
        calendar.timeZone = timeZone

        val sdow = getDayOfWeek(startDayOfWeek)
        val weekday = calendar.component(NSCalendarUnitWeekday, startOfDay.utcDate)
        var daysToSubtract = (weekday - sdow).toInt()
        if (daysToSubtract < 0) {
            daysToSubtract += DAYS_PER_WEEK
        }

        return startOfDay.minusDays(daysToSubtract)
    }

    actual override fun equals(other: Any?): Boolean {
        if (other !is DateTime) {
            return false
        }

        return this.utcDate == other.utcDate
    }

    actual override fun hashCode(): Int {
        return this.utcDate.timeIntervalSinceReferenceDate.hashCode()
    }

    actual override operator fun compareTo(other: DateTime): Int {
        val order = this.utcDate.compare(other.utcDate)
        if (order == NSOrderedSame) {
            return 0
        }

        return if (order == NSOrderedDescending) 1 else -1
    }

    actual fun crossesDst(endDate: DateTime, timeZoneName: String): Boolean {
        val timeZone = NSTimeZone.Companion.create(timeZoneName)
        return timeZone?.isDaylightSavingTimeForDate(this.utcDate) != timeZone?.isDaylightSavingTimeForDate(endDate.utcDate)
    }

    actual fun formatDate(formatString: String, timeZoneName: String): String {
        dateFormatter.locale = NSLocale(serviceLocator.localeData.localeIdentifier)
        dateFormatter.setDateFormat(formatString)
        dateFormatter.setTimeZone(NSTimeZone.Companion.create(timeZoneName))

        return dateFormatter.stringFromDate(this.utcDate)
    }

    private fun getLocalizedDateTime(dateTime: DateTime, timeZoneName: String): DateTime {
        val timeZone = NSTimeZone.Companion.create(timeZoneName) ?: NSTimeZone.localTimeZone
        val seconds = timeZone.secondsFromGMTForDate(dateTime.utcDate)
        return DateTime(NSDate.dateWithTimeInterval(secsToBeAdded = seconds.toDouble(), sinceDate = dateTime.utcDate))
    }

    actual fun isBefore(dateTime: DateTime): Boolean {
        return this.utcDate.compare(dateTime.utcDate) == NSOrderedAscending
    }

    actual fun isAfter(dateTime: DateTime): Boolean {
        return this.utcDate.compare(dateTime.utcDate) == NSOrderedDescending
    }

    actual companion object {
        init {
            dateParser.formatOptions = NSISO8601DateFormatWithFullDate
        }

        actual fun parse(dateString: String): DateTime {
            val instance: NSDate? =
                when {
                    dateRegex.matches(dateString) -> dateParser.dateFromString(dateString)
                    dateTimeRegex.matches(dateString) -> dateTimeParser.dateFromString(dateString)
                    dateTimeFSRegex.matches(dateString) -> dateTimeParser.dateFromString(
                        dateString.substring(
                            startIndex = 0,
                            endIndex = DATE_TIME_FS_SECONDS_END_INDEX + 1
                        ) + "Z"
                    )
                    else -> throw IllegalArgumentException(INVALID_DATE_FORMAT_EXCEPTION_MESSAGE)
                }

            return instance?.let(::DateTime) ?: throw IllegalArgumentException()
        }

        actual fun now(): DateTime {
            return DateTime(NSDate())
        }
    }
}
