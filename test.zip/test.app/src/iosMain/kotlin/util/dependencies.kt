package com.genesys.purecloud.wfmshared.util

actual val thirdPartyDependencies: List<ThirdPartyDependency> = listOf(
    *commonDependencies,

    ThirdPartyDependency(
        projectName = "AFNetworking",
        projectLink = "https://github.com/AFNetworking/AFNetworking",
        licenseName = "MIT License",
        licenseLink = "https://raw.githubusercontent.com/AFNetworking/AFNetworking/master/LICENSE"
    ),

    ThirdPartyDependency(
        projectName = "Firebase SDK",
        projectLink = "https://github.com/firebase/firebase-ios-sdk",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/firebase/firebase-ios-sdk/master/LICENSE"
    ),

    ThirdPartyDependency(
        projectName = "FSCalendar",
        projectLink = "https://github.com/WenchaoD/FSCalendar",
        licenseName = "MIT License",
        licenseLink = "https://raw.githubusercontent.com/WenchaoD/FSCalendar/master/LICENSE"
    ),

    ThirdPartyDependency(
        projectName = "KeychainAccess",
        projectLink = "https://github.com/kishikawakatsumi/KeychainAccess",
        licenseName = "MIT License",
        licenseLink = "https://raw.githubusercontent.com/kishikawakatsumi/KeychainAccess/master/LICENSE"
    ),

    ThirdPartyDependency(
        projectName = "WMSegmentControl",
        projectLink = "https://github.com/malekwasim/WMSegmentControl",
        licenseName = "MIT License",
        licenseLink = "https://raw.githubusercontent.com/malekwasim/WMSegmentControl/master/LICENSE"
    )
)
