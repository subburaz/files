package com.genesys.purecloud.wfmshared.util

import platform.Foundation.NSLog

enum class LogLevel {
    ERROR,
    DEBUG,
    VERBOSE
}

internal actual object Logger {
    private fun log(tag: String, level: LogLevel, message: String) {
        NSLog("$tag, [$level] $message)")
    }

    actual fun logVerbose(tag: String, message: String, cause: Throwable?) {
        log(
            tag = tag,
            level = LogLevel.VERBOSE,
            message = message + cause?.message
        )
    }

    actual fun logDebug(tag: String, message: String, cause: Throwable?) {
        log(
            tag = tag,
            level = LogLevel.DEBUG,
            message = message + cause?.message
        )
    }

    actual fun logError(tag: String, message: String, cause: Throwable?) {
        log(
            tag = tag,
            level = LogLevel.ERROR,
            message = message + cause?.message
        )
    }
}
