package com.genesys.purecloud.wfmsharedios

import com.genesys.purecloud.wfmshared.BuildKonfig
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.util.ViewModelProvider
import com.genesys.purecloud.wfmshared.util.resources.CommonStrings
import dev.icerock.moko.resources.StringResource
import org.kodein.di.erased.instance

val viewModelProvider = ViewModelProvider(kodein)
val commonStrings: CommonStrings by kodein.instance()

fun populateCommonStrings() {
    val commonStrings: CommonStrings by kodein.instance()

    val stringMap: Map<StringResource, String> = commonStrings.resourceMap.map {
        it.key to it.value.localized()
    }.toMap()

    commonStrings.update(stringMap)
}

val oauthClientId = BuildKonfig.OAUTH_CLIENT_ID
val oauthSecret = BuildKonfig.OAUTH_CLIENT_SECRET
