package com.genesys.purecloud.wfmsharedios.presentation.viewmodels

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.presentation.viewmodels.IScheduleViewModel
import com.soywiz.klock.Date
import com.soywiz.klock.YearMonth
import dev.icerock.moko.resources.desc.desc

// These overloads are for Swift where Date and YearMonth do not translate to more than Ints
fun IScheduleViewModel.hasScheduleFor(year: Int, month: Int, day: Int) =
    hasScheduleFor(Date(year, month, day))

fun IScheduleViewModel.updateSchedule(year: Int, month: Int) = updateSchedule(YearMonth(year, month))

fun IScheduleViewModel.selectDate(year: Int, month: Int, day: Int) = selectDate(Date(year, month, day))

val IScheduleViewModel.Selection.formattedDate: String get() {
    return date.format(MR.strings.schedule_bar_date_format.desc().localized()).toUpperCase()
}
