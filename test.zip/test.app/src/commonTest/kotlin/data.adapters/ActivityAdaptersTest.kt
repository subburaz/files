package com.genesys.purecloud.wfmshared.data.adapters

import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode.Category
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.BREAK
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.MEAL
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.MEETING
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.OFF_QUEUE_WORK
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.ON_QUEUE_WORK
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.TIME_OFF
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.TRAINING
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.UNAVAILABLE
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.UNSCHEDULED
import com.genesys.purecloud.wfmshared.testutil.IgnoreIos
import com.genesys.purecloud.wfmshared.testutil.useTimeZone
import com.soywiz.klock.DateTime
import com.soywiz.klock.YearMonth
import kotlin.test.Test
import kotlin.test.assertEquals

class ActivityAdaptersTest {
    @Test
    fun `should translate all categories`() {
        mapOf(
            BREAK to Category.BREAK,
            MEAL to Category.MEAL,
            MEETING to Category.MEETING,
            OFF_QUEUE_WORK to Category.OFF_QUEUE_WORK,
            ON_QUEUE_WORK to Category.ON_QUEUE,
            TIME_OFF to Category.TIME_OFF,
            TRAINING to Category.TRAINING,
            UNAVAILABLE to Category.UNAVAILABLE,
            UNSCHEDULED to Category.UNSCHEDULED
        )
        .forEach { (input, expected) ->
            assertEquals(expected, input.toCategory, "$input.toCategory")
        }
    }

    @Test
    @IgnoreIos
    fun `should translate YearMonth to proper range`() {
        useTimeZone("America/Indiana/Indianapolis") {
            assertEquals(
                DateTime(2020, 3, 1, 5)..DateTime(2020, 4, 1, 4),
                YearMonth(2020, 3).monthRange,
                "YearMonth(2020, 3).monthRange")
        }
    }
}
