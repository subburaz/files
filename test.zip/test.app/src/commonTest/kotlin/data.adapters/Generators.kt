@file:Suppress("unused")

package com.genesys.purecloud.wfmshared.data.adapters

import com.genesys.purecloud.wfmshared.purecloudapi.entities.ActivityCode
import com.genesys.purecloud.wfmshared.purecloudapi.entities.UserReference
import com.genesys.purecloud.wfmshared.purecloudapi.entities.WfmVersionedEntityMetadata
import com.genesys.purecloud.wfmshared.testutil.Generator
import com.genesys.purecloud.wfmshared.testutil.booleans
import com.genesys.purecloud.wfmshared.testutil.dateTimes
import com.genesys.purecloud.wfmshared.testutil.enumValues
import com.genesys.purecloud.wfmshared.testutil.ints
import com.genesys.purecloud.wfmshared.testutil.strings
import com.soywiz.klock.DateFormat
import com.soywiz.klock.DateTime
import kotlin.random.Random

fun Generator.Companion.userReferences(
    random: Random = Random.Default,
    ids: Sequence<String> = Generator.strings(random = random),
    selfUris: Sequence<String> = Generator.strings(random = random)
) = ids.zip(selfUris) { id, url -> UserReference(id = id, selfUri = url) }

fun Generator.Companion.wfmVersionedEntityMetadata(
    random: Random = Random.Default,
    versions: Sequence<Int> = Generator.ints(0..100, random = random),
    modifiedBys: Sequence<UserReference> = Generator.userReferences(random),
    datesModified: Sequence<DateTime> = Generator.dateTimes(random = random)
) = versions.zip(modifiedBys).zip(datesModified) { (version, modifiedBy), modifiedDate ->
    WfmVersionedEntityMetadata(
        version = version,
        modifiedBy = modifiedBy,
        dateModified = modifiedDate.format(DateFormat.DEFAULT_FORMAT)
    )
}

fun Generator.Companion.activityCodes(
    random: Random = Random.Default,
    categories: Sequence<ActivityCode.Category> = Generator.enumValues(random),
    ids: Sequence<String> = Generator.strings(random = random),
    lengthsInMinutes: Sequence<Int> = Generator.ints(1..500),
    countsAsPaidTime: Sequence<Boolean> = Generator.booleans(random),
    agentTimeOffSelectable: Sequence<Boolean> = Generator.booleans(random),
    countsAsWorkTime: Sequence<Boolean> = Generator.booleans(random),
    isActive: Sequence<Boolean> = generateSequence { true },
    isDefault: Sequence<Boolean> = generateSequence { false },
    names: Sequence<String> = Generator.strings(random = random),
    selfUris: Sequence<String> = Generator.strings(random = random),
    metadata: Sequence<WfmVersionedEntityMetadata> = Generator.wfmVersionedEntityMetadata(random)
): Sequence<ActivityCode> {
    val booleans = countsAsPaidTime
        .zip(agentTimeOffSelectable)
        .zip(countsAsWorkTime.zip(isActive))
        .zip(isDefault) { (a, b), c ->
            a.toList() + b.toList() + c
        }

    val strings = ids.zip(names).zip(selfUris) {
        a, b -> a.toList() + b
    }

    return (categories.zip(lengthsInMinutes))
        .zip(booleans.zip(strings))
        .zip(metadata) { (categoryAndLength, booleansAndStrings), meta ->
            ActivityCode(
                category = categoryAndLength.first,
                id = booleansAndStrings.second[0],
                lengthInMinutes = categoryAndLength.second,
                countsAsPaidTime = booleansAndStrings.first[0],
                agentTimeOffSelectable = booleansAndStrings.first[1],
                countsAsWorkTime = booleansAndStrings.first[2],
                isActive = booleansAndStrings.first[3],
                isDefault = booleansAndStrings.first[4],
                name = booleansAndStrings.second[1],
                selfUri = booleansAndStrings.second[2],
                metadata = meta
            )
        }
}
