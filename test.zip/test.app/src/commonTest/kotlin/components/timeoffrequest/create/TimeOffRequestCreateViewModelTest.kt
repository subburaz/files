package com.genesys.purecloud.wfmshared.components.timeoffrequest.create

import com.genesys.purecloud.wfmshared.AuthenticationData
import com.genesys.purecloud.wfmshared.AuthenticationListener
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.AdherenceSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.IgnoredActivityCategories
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnitSettingsResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ShortTermForecastingSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.UserReference
import com.genesys.purecloud.wfmshared.purecloudapi.entities.WfmVersionedEntityMetadata
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.testutil.IgnoreIos
import com.genesys.purecloud.wfmshared.testutil.generateActivityCodeResponse
import com.genesys.purecloud.wfmshared.testutil.generateApiUrl
import com.genesys.purecloud.wfmshared.testutil.generateMockHttpClient
import com.genesys.purecloud.wfmshared.testutil.generateTimeOffRequest
import com.genesys.purecloud.wfmshared.testutil.populateCommonTestStrings
import com.genesys.purecloud.wfmshared.testutil.runBlockingTest
import com.genesys.purecloud.wfmshared.testutil.withMockHttpResponses
import com.genesys.purecloud.wfmshared.testutil.withTestCoroutineScopes
import com.genesys.purecloud.wfmshared.util.DEFAULT_TIME_ZONE_NAME
import com.genesys.purecloud.wfmshared.util.ServiceLocator
import com.genesys.purecloud.wfmshared.util.dateFormatISO8601
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestCreateViewModel
import com.soywiz.klock.DateTime
import com.soywiz.klock.DateTimeSpan
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.kodein.di.Kodein
import org.kodein.di.direct
import org.kodein.di.erased.instance

@ExperimentalCoroutinesApi
class TimeOffRequestCreateViewModelTest {
    private lateinit var di: Kodein
    private lateinit var vm: ITimeOffRequestCreateViewModel

    private val activityCode = ActivityCode(
        id = "5",
        name = "Time Off",
        isActive = true,
        isDefault = true,
        category = ActivityCode.Category.TIME_OFF,
        lengthInMinutes = 180,
        countsAsPaidTime = true,
        countsAsWorkTime = false,
        agentTimeOffSelectable = true
    )
    private val activityCodeResponse = generateActivityCodeResponse(activityCode)

    private val apiUrl = generateApiUrl()
    private val mockHttpResponses = mapOf(
        "$apiUrl/api/v2/workforcemanagement/businessunits/mine/activitycodes" to activityCodeResponse
    )

    @BeforeTest
    fun setup() {
        di = kodein
            .withTestCoroutineScopes()
            .withMockHttpResponses(mockHttpResponses)

        val auth: AuthenticationListener by di.instance()

        auth.loggedIn(
            AuthenticationData(
                apiUrl = apiUrl,
                accessToken = "accessToken",
                userAgent = "userAgent"
            )
        )

        populateCommonTestStrings()

        vm = di.direct.instance()
    }

    @Test
    @IgnoreIos
    fun `initialize observes activityCodes and sets selectedActivityCode`() {
        runBlockingTest {
            vm.initialize().join()
        }
        assertEquals(vm.viewState.value.activityId, "5")
    }

    @Test
    @IgnoreIos
    fun `initialize observes activityCodes and sets selectableActivityCodes`() {
        runBlockingTest {
            vm.initialize().join()
        }
        assertEquals(vm.viewState.value.selectableActivityCodes, listOf(activityCode))
    }

    @Test
    fun `initializeViewModel sets default dates if the Management Unit is Null`() {
        val startDate = vm.viewState.value.startMin
        val endDate = vm.viewState.value.endMax
        assertEquals(
            DateTime.now().format(dateFormatISO8601),
            startDate.format(dateFormatISO8601)
        )
        assertEquals(
            DateTime.now().format(dateFormatISO8601), endDate.format(dateFormatISO8601)
        )
    }

    @Test
    @IgnoreIos
    fun `initializeViewModel sets the date in Management unit`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val mu = managementUnit()

        val muPath = PureCloudApiEndpoints.GET_USERS_MU
        ServiceLocator.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(muPath),
                        serviceLocator.jsonSerializer.stringify(
                            ManagementUnit.serializer(),
                            mu
                        )
                    )
                )
            )
        )

        runBlockingTest {
            vm.initialize().join()
        }

        val startDate = vm.viewState.value.startMin
        val endDate = vm.viewState.value.endMax
        assertEquals(
            startDate.format(dateFormatISO8601),
            DateTime.now().minus(DateTimeSpan(days = 365 * 3)).format(dateFormatISO8601)
        )
        assertEquals(
            endDate.format(dateFormatISO8601),
            DateTime.now().plus(DateTimeSpan(days = 365 * 3)).format(dateFormatISO8601)
        )
    }

    private fun managementUnit() = ManagementUnit(
        id = "id",
        timeZone = DEFAULT_TIME_ZONE_NAME,
        selfUri = "selfUri",
        startDayOfWeek = ManagementUnit.StartDayOfWeek.SUNDAY,
        settings = ManagementUnitSettingsResponse(
            adherence = AdherenceSettings(
                severeAlertThresholdMinutes = 0,
                adherenceTargetPercent = 0,
                adherenceExceptionThresholdSeconds = 0,
                nonOnQueueActivitiesEquivalent = false,
                trackOnQueueActivity = false,
                ignoredActivityCategories = IgnoredActivityCategories(
                    listOf(IgnoredActivityCategories.Values.ON_QUEUE_WORK)
                )
            ),
            shortTermForecasting = ShortTermForecastingSettings(0),
            timeOff = TimeOffRequestSettings(false, 5, 20),
            metadata = WfmVersionedEntityMetadata(42, UserReference("", ""), "")
        )
    )

    @Test
    @IgnoreIos
    fun `createTimeOffRequest creates TimeOffRequest and sets in the field`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )
        val torPath = PureCloudApiEndpoints.POST_USERS_TORS
        val timeOffRequest =
            generateTimeOffRequest(setOf("2000-01-01"), emptySet(), dailyDurationInMinutes = 20)
        val muPath = PureCloudApiEndpoints.GET_USERS_MU
        val mu = managementUnit()
        ServiceLocator.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(torPath),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestResponse.serializer(),
                            timeOffRequest
                        )
                    ),
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(muPath),
                        serviceLocator.jsonSerializer.stringify(
                            ManagementUnit.serializer(),
                            mu
                        )
                    )
                )
            )
        )
        vm.initialize()
        runBlockingTest {
            vm.submitTimeOffRequest()
        }

        vm.submitResult.observe {
            assertTrue(it.successful)
        }
    }
}
