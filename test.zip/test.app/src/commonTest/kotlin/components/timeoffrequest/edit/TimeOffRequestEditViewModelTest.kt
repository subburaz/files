package com.genesys.purecloud.wfmshared.components.timeoffrequest.edit

import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.testutil.IgnoreIos
import com.genesys.purecloud.wfmshared.testutil.generateMockHttpClient
import com.genesys.purecloud.wfmshared.testutil.generateTimeOffRequest
import com.genesys.purecloud.wfmshared.testutil.runBlockingTest
import com.genesys.purecloud.wfmshared.testutil.withTestCoroutineScopes
import com.genesys.purecloud.wfmshared.util.ServiceLocator
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestEditViewModel
import io.ktor.util.KtorExperimentalAPI
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.kodein.di.Kodein
import org.kodein.di.direct
import org.kodein.di.erased.instance

@ExperimentalCoroutinesApi
class TimeOffRequestEditViewModelTest {
    private lateinit var di: Kodein
    private lateinit var vm: ITimeOffRequestEditViewModel

    @BeforeTest
    fun setup() {
        di = kodein.withTestCoroutineScopes()
        vm = di.direct.instance()
    }

    @Test
    @IgnoreIos
    @KtorExperimentalAPI
    @ExperimentalStdlibApi
    fun `cancelTimeOffRequest patches the TimeOffRequest`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )
        val torPath = PureCloudApiEndpoints.PATCH_USER_TORS + "/255"
        val timeOffRequest = generateTimeOffRequest(setOf("2000-01-01"), emptySet(), dailyDurationInMinutes = 20)
        ServiceLocator.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(torPath),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestResponse.serializer(),
                            timeOffRequest
                        )
                    )
                )
            )
        )
        runBlockingTest {
            vm.cancelTimeOffRequest()
        }
    }

    @Test
    @IgnoreIos
    @KtorExperimentalAPI
    @ExperimentalStdlibApi
    fun `updateTimeOffRequest patches the TimeOffRequest with new notes`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )
        val torPath = PureCloudApiEndpoints.PATCH_USER_TORS + "/255"
        val timeOffRequest = generateTimeOffRequest(setOf("2000-01-01"), emptySet(), dailyDurationInMinutes = 20)
        ServiceLocator.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(torPath),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestResponse.serializer(),
                            timeOffRequest
                        )
                    )
                )
            )
        )
        runBlockingTest {
            vm.updateTimeOffRequest()
        }
    }
}
