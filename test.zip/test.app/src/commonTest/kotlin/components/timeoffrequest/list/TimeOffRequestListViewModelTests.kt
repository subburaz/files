package com.genesys.purecloud.wfmshared.components.timeoffrequest.list

import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.AdherenceSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.IgnoredActivityCategories
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit.StartDayOfWeek
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnitSettingsResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ShortTermForecastingSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestList
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.UserReference
import com.genesys.purecloud.wfmshared.purecloudapi.entities.WfmVersionedEntityMetadata
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.testutil.IgnoreIos
import com.genesys.purecloud.wfmshared.testutil.generateMockHttpClient
import com.genesys.purecloud.wfmshared.testutil.generateTimeOffRequest
import com.genesys.purecloud.wfmshared.testutil.getTestCoroutineBGScope
import com.genesys.purecloud.wfmshared.testutil.getTestCoroutineUIScope
import com.genesys.purecloud.wfmshared.testutil.runBlockingTest
import com.genesys.purecloud.wfmshared.util.DEFAULT_TIME_ZONE_NAME
import com.genesys.purecloud.wfmshared.util.ServiceLocator
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlinx.coroutines.ExperimentalCoroutinesApi

@ExperimentalCoroutinesApi
class TimeOffRequestListViewModelTests {
    @Test
    @IgnoreIos
    fun testDefaultState() {
        val vm = TimeOffRequestListViewModel(
            getTestCoroutineBGScope(),
            getTestCoroutineUIScope()
        )

        runBlockingTest {
            vm.getUpcomingTimeOffRequests().observe {}.join()
            vm.getPendingTimeOffRequests().observe {}.join()
            vm.getThisWeeksTimeOffRequests().observe {}.join()
            vm.getAllTimeOffRequests().observe {}.join()

            assertEquals(1, vm.getAllTimeOffRequests().value.count())
            assertEquals(1, vm.getPendingTimeOffRequests().value.count())
            assertEquals(1, vm.getThisWeeksTimeOffRequests().value.count())
            assertEquals(1, vm.getUpcomingTimeOffRequests().value.count())
        }
    }

    @Test
    @IgnoreIos
    fun testUpdateTimeOffRequests() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val tor = generateTimeOffRequest(
            fullDays = setOf("2000-01-01"),
            partialDays = emptySet()
        )

        val mu = ManagementUnit(
            id = "id",
            timeZone = DEFAULT_TIME_ZONE_NAME,
            selfUri = "selfUri",
            startDayOfWeek = StartDayOfWeek.SUNDAY,
            settings = ManagementUnitSettingsResponse(
                adherence = AdherenceSettings(
                    severeAlertThresholdMinutes = 0,
                    adherenceTargetPercent = 0,
                    adherenceExceptionThresholdSeconds = 0,
                    nonOnQueueActivitiesEquivalent = false,
                    trackOnQueueActivity = false, ignoredActivityCategories = IgnoredActivityCategories(
                        listOf(IgnoredActivityCategories.Values.ON_QUEUE_WORK)
                    )
                ),
                shortTermForecasting = ShortTermForecastingSettings(0),
                timeOff = TimeOffRequestSettings(false, 0, 0),
                metadata = WfmVersionedEntityMetadata(42, UserReference("", ""), "")
            )
        )

        val torPath = PureCloudApiEndpoints.GET_USERS_TORS
        val muPath = PureCloudApiEndpoints.GET_USERS_MU

        ServiceLocator.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(torPath),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestList.serializer(),
                            TimeOffRequestList(timeOffRequests = listOf(tor))
                        )
                    ),
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(muPath),
                        serviceLocator.jsonSerializer.stringify(
                            ManagementUnit.serializer(),
                            mu
                        )
                    )
                )
            )
        )

        val vm = TimeOffRequestListViewModel(getTestCoroutineBGScope(), getTestCoroutineUIScope())

        runBlockingTest {
            vm.updateTimeOffRequests().join()
        }

        assertEquals(DEFAULT_TIME_ZONE_NAME, vm.timeZoneName)
        assertEquals(1, vm.timeOffRequests.count())
        assertEquals(StartDayOfWeek.SUNDAY, vm.startDayOfWeek)
    }
}
