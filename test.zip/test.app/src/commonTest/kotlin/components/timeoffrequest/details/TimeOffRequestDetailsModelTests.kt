package com.genesys.purecloud.wfmshared.components.timeoffrequest.details

import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import kotlin.test.Test
import kotlin.test.assertEquals

class TimeOffRequestDetailsModelTests {
    @Test
    fun `test hasNotes with empty notes`() {
        val model = TimeOffRequestDetailsModel(notes = "")
        assertEquals(false, model.hasNotes)
    }

    @Test
    fun `test hasNotes with populated notes`() {
        val model = TimeOffRequestDetailsModel(notes = "notes")
        assertEquals(true, model.hasNotes)
    }

    @Test
    fun `test hasNotes with blank notes`() {
        val model = TimeOffRequestDetailsModel(notes = " ")
        assertEquals(false, model.hasNotes)
    }

    @Test
    fun `test canEditNotes with PENDING status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.PENDING)
        assertEquals(true, model.canEditNotes)
    }

    @Test
    fun `test canEditNotes with APPROVED status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.APPROVED)
        assertEquals(false, model.canEditNotes)
    }

    @Test
    fun `test canEditNotes with CANCELED status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.CANCELED)
        assertEquals(false, model.canEditNotes)
    }

    @Test
    fun `test canEditNotes with DENIED status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.DENIED)
        assertEquals(false, model.canEditNotes)
    }

    @Test
    fun `test canCancelRequest with PENDING status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.PENDING)
        assertEquals(true, model.canCancelRequest)
    }

    @Test
    fun `test canCancelRequest with APPROVED status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.APPROVED)
        assertEquals(true, model.canCancelRequest)
    }

    @Test
    fun `test canCancelRequest with DENIED status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.DENIED)
        assertEquals(false, model.canCancelRequest)
    }

    @Test
    fun `test canCancelRequest with CANCELED status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.CANCELED)
        assertEquals(false, model.canCancelRequest)
    }

    @Test
    fun `test canEditRequest with PENDING status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.PENDING)
        assertEquals(true, model.canEditRequest)
    }

    @Test
    fun `test canEditRequest with APPROVED status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.APPROVED)
        assertEquals(true, model.canEditRequest)
    }

    @Test
    fun `test canEditRequest with DENIED status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.DENIED)
        assertEquals(false, model.canEditRequest)
    }

    @Test
    fun `test canEditRequest with CANCELED status`() {
        val model = TimeOffRequestDetailsModel(status = TimeOffRequestResponse.Status.CANCELED)
        assertEquals(false, model.canEditRequest)
    }
}
