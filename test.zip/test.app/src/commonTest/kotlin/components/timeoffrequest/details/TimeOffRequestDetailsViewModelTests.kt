package com.genesys.purecloud.wfmshared.components.timeoffrequest.details

import com.genesys.purecloud.wfmshared.AuthenticationData
import com.genesys.purecloud.wfmshared.AuthenticationListener
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.AdherenceSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.IgnoredActivityCategories
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnitSettingsResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ShortTermForecastingSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.UserReference
import com.genesys.purecloud.wfmshared.purecloudapi.entities.WfmVersionedEntityMetadata
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.testutil.IgnoreIos
import com.genesys.purecloud.wfmshared.testutil.generateActivityCode
import com.genesys.purecloud.wfmshared.testutil.generateActivityCodeResponse
import com.genesys.purecloud.wfmshared.testutil.generateApiUrl
import com.genesys.purecloud.wfmshared.testutil.generateMockHttpClient
import com.genesys.purecloud.wfmshared.testutil.generateTimeOffRequest
import com.genesys.purecloud.wfmshared.testutil.populateCommonTestStrings
import com.genesys.purecloud.wfmshared.testutil.runBlockingTest
import com.genesys.purecloud.wfmshared.testutil.withMockHttpResponses
import com.genesys.purecloud.wfmshared.testutil.withTestCoroutineScopes
import com.genesys.purecloud.wfmshared.util.DEFAULT_TIME_ZONE_NAME
import com.genesys.purecloud.wfmshared.util.ServiceLocator
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestDetailsViewModel
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.kodein.di.Kodein
import org.kodein.di.direct
import org.kodein.di.erased.instance

@ExperimentalCoroutinesApi
class TimeOffRequestDetailsViewModelTests {
    private lateinit var di: Kodein
    private lateinit var vm: ITimeOffRequestDetailsViewModel

    private val apiUrl = generateApiUrl()
    private val mockHttpResponses = mapOf(
        "$apiUrl/api/v2/workforcemanagement/businessunits/mine/activitycodes" to generateActivityCodeResponse(generateActivityCode())
    )

    @BeforeTest
    fun setup() {
        di = kodein
            .withTestCoroutineScopes()
            .withMockHttpResponses(mockHttpResponses)

        val auth: AuthenticationListener by di.instance()

        auth.loggedIn(
            AuthenticationData(
                apiUrl = apiUrl,
                accessToken = "accessToken",
                userAgent = "userAgent"
            )
        )

        vm = di.direct.instance()
    }

    @Test
    @IgnoreIos
    fun testFetchTimeOffRequest() {
        populateCommonTestStrings()

        serviceLocator.initializeApiData(
            apiUrl = apiUrl,
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val tor = generateTimeOffRequest(
            id = "testId",
            fullDays = setOf("2000-01-01"),
            partialDays = emptySet()
        )

        val mu = ManagementUnit(
            id = "id",
            timeZone = DEFAULT_TIME_ZONE_NAME,
            selfUri = "selfUri",
            startDayOfWeek = ManagementUnit.StartDayOfWeek.SUNDAY,
            settings = ManagementUnitSettingsResponse(
                adherence = AdherenceSettings(
                    severeAlertThresholdMinutes = 0,
                    adherenceTargetPercent = 0,
                    adherenceExceptionThresholdSeconds = 0,
                    nonOnQueueActivitiesEquivalent = false,
                    trackOnQueueActivity = false,
                    ignoredActivityCategories = IgnoredActivityCategories(
                        listOf(IgnoredActivityCategories.Values.ON_QUEUE_WORK)
                    )
                ),
                shortTermForecasting = ShortTermForecastingSettings(0),
                timeOff = TimeOffRequestSettings(false, 5, 20),
                metadata = WfmVersionedEntityMetadata(42, UserReference("", ""), "")
            )
        )

        val torPath = "${PureCloudApiEndpoints.GET_USERS_TORS}/${tor.id}"
        val muPath = PureCloudApiEndpoints.GET_USERS_MU

        ServiceLocator.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(torPath),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestResponse.serializer(),
                            tor
                        )
                    ),
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(muPath),
                        serviceLocator.jsonSerializer.stringify(
                            ManagementUnit.serializer(),
                            mu
                        )
                    )
                )
            )
        )

        runBlockingTest {
            vm.fetchTimeOffRequest(tor.id)
        }

        assertEquals("01/01/2000", vm.timeOffRequestDetailsModel.value.startDate)
        assertEquals("Sat", vm.timeOffRequestDetailsModel.value.startDay)
    }

    @Test
    @IgnoreIos
    fun testReset() {
        runBlockingTest {
            vm.reset()
        }

        assertEquals(false, vm.isLoading.value)
        assertEquals(TimeOffRequestDetailsModel(), vm.timeOffRequestDetailsModel.value)
    }
}
