package com.genesys.purecloud.wfmshared.components.settings

import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.User
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.testutil.IgnoreIos
import com.genesys.purecloud.wfmshared.testutil.generateMockHttpClient
import com.genesys.purecloud.wfmshared.testutil.getTestCoroutineBGScope
import com.genesys.purecloud.wfmshared.testutil.getTestCoroutineUIScope
import com.genesys.purecloud.wfmshared.testutil.runBlockingTest
import com.genesys.purecloud.wfmshared.util.ServiceLocator
import kotlin.test.Test
import kotlin.test.assertEquals

class SettingsViewModelTests {
    @Test
    @IgnoreIos
    fun `getUserSettingsInfo gets user info and sets in the field`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val user = User(
            id = "userId",
            selfUri = "selfUri",
            username = "username"
        )

        val userInfoPath = PureCloudApiEndpoints.GET_USERS_INFO

        ServiceLocator.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(userInfoPath),
                        serviceLocator.jsonSerializer.stringify(
                            User.serializer(),
                            user
                        )

                    )
                )
            )
        )

        val vm = SettingsViewModel(
            getTestCoroutineUIScope(),
            getTestCoroutineBGScope()
        )

        runBlockingTest {
            vm.getUserSettingsInfo()
        }

        assertEquals("username", vm.userSettingsModel.value.name)
        assertEquals("userId", vm.userSettingsModel.value.id)
    }
}
