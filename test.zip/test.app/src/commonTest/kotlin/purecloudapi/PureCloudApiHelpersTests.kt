package com.genesys.purecloud.wfmshared.purecloudapi

import com.genesys.purecloud.wfmshared.purecloudapi.entities.CreateAgentTimeOffRequest
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.testutil.generateMockHttpClient
import com.genesys.purecloud.wfmshared.testutil.runBlockingTest
import com.genesys.purecloud.wfmshared.util.ServiceLocator
import kotlin.test.Test
import kotlin.test.assertEquals

class PureCloudApiHelpersTests {
    @Test
    fun testExecutePureCloudGetRequestHappyPath() {
        serviceLocator.reset()
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val path = "test"
        val mockUrl = serviceLocator.apiData!!.buildFullPath(path)
        val mockResponse = "Test"
        ServiceLocator.TestUtils.setHttpClient(serviceLocator, generateMockHttpClient(mapOf(Pair(mockUrl, mockResponse))))

        val response = runBlockingTest {
            executePureCloudGetRequest(path)
        }

        assertEquals(mockResponse, response)
    }

    @Test
    fun testExecutePureCloudGetRequestNoApi() {
        serviceLocator.reset()

        val response = runBlockingTest {
            executePureCloudGetRequest("path")
        }

        assertEquals(null, response)
    }

    @Test
    fun `executePureCloudPatchRequest successful with proper response`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val path = "test"
        val body = "testBody"
        val mockUrl = serviceLocator.apiData!!.buildFullPath(path)
        val mockResponse = "Test"
        ServiceLocator.TestUtils.setHttpClient(serviceLocator, generateMockHttpClient(mapOf(Pair(mockUrl, mockResponse))))

        val response = runBlockingTest {
            executePureCloudPatchRequest(path, body)
        }
        assertEquals(mockResponse, response)
    }

    @Test
    fun `executePureCloudPostRequest successful with proper response`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val path = "test"

        val mockUrl = serviceLocator.apiData!!.buildFullPath(path)
        val mockResponse = "Test"
        ServiceLocator.setHttpClient(serviceLocator, generateMockHttpClient(mapOf(Pair(mockUrl, mockResponse))))

        val response = runBlockingTest {
            executePureCloudPostRequest(path, serviceLocator.jsonSerializer.stringify(CreateAgentTimeOffRequest.serializer(), CreateAgentTimeOffRequest(
                "213",
                20,
                "abc",
                emptySet(),
                emptySet()
            )))
        }

        assertEquals(mockResponse, response)
    }

    @Test
    fun `executePureCloudPatchRequest fails with no api`() {
        serviceLocator.reset()

        val response = runBlockingTest {
            executePureCloudPatchRequest("path", "testBody")
        }
        assertEquals(null, response)
    }

    @Test
    fun `executePureCloudPostRequest fails with no api`() {
        serviceLocator.reset()

        val response = runBlockingTest {
            executePureCloudPostRequest("path", serviceLocator.jsonSerializer.stringify(CreateAgentTimeOffRequest.serializer(), CreateAgentTimeOffRequest(
                "213",
                20,
                "abc",
                emptySet(),
                emptySet()
            )))
        }

        assertEquals(null, response)
    }
}
