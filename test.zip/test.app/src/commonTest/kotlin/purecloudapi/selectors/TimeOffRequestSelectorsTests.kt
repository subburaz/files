package com.genesys.purecloud.wfmshared.purecloudapi.selectors

import com.genesys.purecloud.wfmshared.components.timeoffrequest.details.TimeOffRequestDetailsModel
import com.genesys.purecloud.wfmshared.components.timeoffrequest.list.TimeOffRequestListCellData
import com.genesys.purecloud.wfmshared.components.timeoffrequest.list.TimeOffRequestListCellType
import com.genesys.purecloud.wfmshared.presentation.resources.displayName
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.User
import com.genesys.purecloud.wfmshared.purecloudapi.extensions.dates
import com.genesys.purecloud.wfmshared.purecloudapi.selectors.TimeOffRequestSelectors.getTimeOffRequestListCellType
import com.genesys.purecloud.wfmshared.testutil.DAILY_DURATION_IN_MINUTES
import com.genesys.purecloud.wfmshared.testutil.generateActivityCode
import com.genesys.purecloud.wfmshared.testutil.generateTimeOffRequest
import com.genesys.purecloud.wfmshared.testutil.generateUser
import com.genesys.purecloud.wfmshared.testutil.populateCommonTestStrings
import com.genesys.purecloud.wfmshared.util.DEFAULT_TIME_ZONE_NAME
import com.genesys.purecloud.wfmshared.util.DateTime
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals

class TimeOffRequestSelectorsTests {
    private val feb1 = DateTime.parse("2000-02-01")
    private val feb8 = DateTime.parse("2000-02-08")

    private val weekStart = feb1
    private val weekEnd = feb8.minusSeconds(1)
    private val user = mutableMapOf("id" to User(
        id = "id",
        selfUri = "selfUri",
        name = "username"
    ))

    private val singleFullDayTOR = generateTimeOffRequest(
        fullDays = setOf("2000-02-01"),
        partialDays = emptySet(),
        activityCodeId = "single-full-day-tor-activity-code-id"
    )

    private val multipleFullDayTOR = generateTimeOffRequest(
        fullDays = setOf(
            "2000-02-01",
            "2000-02-05",
            "2000-02-03"
        ),
        partialDays = emptySet()
    )

    private val singleDayPartialTOR = generateTimeOffRequest(
        fullDays = emptySet(),
        partialDays = setOf("2000-02-01T01:00:00Z"),
        dailyDurationInMinutes = 60
    )

    private val multipleDayPartialTOR = generateTimeOffRequest(
        fullDays = emptySet(),
        partialDays = setOf(
            "2000-02-01T01:00:00Z",
            "2000-02-05T01:00:00Z",
            "2000-02-03T01:00:00Z"
        ),
        dailyDurationInMinutes = 60
    )

    private val expectedSingleFullDayCellData = TimeOffRequestListCellData(
        type = TimeOffRequestListCellType.SINGLE_DAY_FULL_TOR_LIST_ITEM,
        id = singleFullDayTOR.id,
        notes = singleFullDayTOR.notes,
        startDate = "02/01/2000",
        startDay = "Tue",
        startTime = "",
        endDate = "",
        endDay = "",
        endTime = "",
        supportText = "",
        status = TimeOffRequestResponse.Status.APPROVED,
        dates = listOf(feb1),
        crossesDst = false,
        pending = false,
        occursThisWeek = true,
        occursAfterThisWeek = false,
        dailyDurationMinutes = DAILY_DURATION_IN_MINUTES
    )

    @BeforeTest
    fun setup() {
        populateCommonTestStrings()
    }

    @Test
    fun testGetTimeOffRequestListCellTypeSingleFullDay() {
        val cellType = getTimeOffRequestListCellType(singleDay = true, partialDay = false)
        assertEquals(TimeOffRequestListCellType.SINGLE_DAY_FULL_TOR_LIST_ITEM, cellType)
    }

    @Test
    fun testGetTimeOffRequestListCellTypeSinglePartialDay() {
        val cellType = getTimeOffRequestListCellType(singleDay = true, partialDay = true)
        assertEquals(TimeOffRequestListCellType.SINGLE_DAY_PARTIAL_TOR_LIST_ITEM, cellType)
    }

    @Test
    fun testGetTimeOffRequestListCellTypeMultipleFullDay() {
        val cellType = getTimeOffRequestListCellType(singleDay = false, partialDay = false)
        assertEquals(TimeOffRequestListCellType.MULTIPLE_DAY_TOR_LIST_ITEM, cellType)
    }

    @Test
    fun testGetTimeOffRequestListCellTypeMultiplePartialDay() {
        val cellType = getTimeOffRequestListCellType(singleDay = false, partialDay = true)
        assertEquals(TimeOffRequestListCellType.MULTIPLE_DAY_TOR_LIST_ITEM, cellType)
    }

    @Test
    fun testGetTimeOffRequestCellDataSingleFullDay() {
        val torCellData = TimeOffRequestSelectors.getTimeOffRequestCellData(singleFullDayTOR, weekStart, weekEnd, userById = user)
        assertEquals(expectedSingleFullDayCellData, torCellData)
    }

    @Test
    fun testGetTimeOffRequestsCellDataList() {
        val torList = listOf(singleFullDayTOR, multipleFullDayTOR, singleDayPartialTOR, multipleDayPartialTOR)

        val torCellDataList = TimeOffRequestSelectors.getTimeOffRequestsCellDataList(
            isLoading = false,
            torList = torList,
            weekStart = weekStart,
            weekEnd = weekEnd,
            userMap = user
        )

        assertEquals(TimeOffRequestListCellType.SINGLE_DAY_PARTIAL_TOR_LIST_ITEM, torCellDataList[0].type)
        assertEquals(TimeOffRequestListCellType.MULTIPLE_DAY_TOR_LIST_ITEM, torCellDataList[1].type)
        assertEquals(TimeOffRequestListCellType.SINGLE_DAY_FULL_TOR_LIST_ITEM, torCellDataList[2].type)
        assertEquals(TimeOffRequestListCellType.MULTIPLE_DAY_TOR_LIST_ITEM, torCellDataList[3].type)
    }

    @Test
    fun testGetTimeOffRequestsCellDataListIsLoading() {
        val torList = listOf(singleFullDayTOR, multipleFullDayTOR, singleDayPartialTOR, multipleDayPartialTOR)

        val torCellDataList = TimeOffRequestSelectors.getTimeOffRequestsCellDataList(
            isLoading = true,
            torList = torList,
            weekStart = weekStart,
            weekEnd = weekEnd,
            userMap = user
        )

        assertEquals(1, torCellDataList.count())
        assertEquals(TimeOffRequestListCellType.LOADING_INDICATOR_LIST_ITEM, torCellDataList[0].type)
    }

    @Test
    fun testGetTimeOffRequestsCellDataListIsEmpty() {
        val torList = emptyList<TimeOffRequestResponse>()

        val torCellDataList = TimeOffRequestSelectors.getTimeOffRequestsCellDataList(
            isLoading = false,
            torList = torList,
            weekStart = weekStart,
            weekEnd = weekEnd,
            userMap = user
        )

        assertEquals(1, torCellDataList.count())
        assertEquals(TimeOffRequestListCellType.EMPTY_SECTION_LIST_ITEM, torCellDataList[0].type)
    }

    @Test
    fun testGetPendingTimeOffRequestsCellData() {
        val torList = listOf(
            expectedSingleFullDayCellData.copy(pending = false),
            expectedSingleFullDayCellData.copy(pending = true)
        )

        val torCellDataList = TimeOffRequestSelectors.getPendingTimeOffRequestsCellData(false, torList)
        assertEquals(1, torCellDataList.count())
        assertEquals(true, torCellDataList[0].pending)
    }

    @Test
    fun testGetPendingTimeOffRequestsCellDataIsLoading() {
        val torList = listOf(
            expectedSingleFullDayCellData.copy(pending = false),
            expectedSingleFullDayCellData.copy(pending = true)
        )

        val torCellDataList = TimeOffRequestSelectors.getPendingTimeOffRequestsCellData(true, torList)
        assertEquals(1, torCellDataList.count())
        assertEquals(TimeOffRequestListCellType.LOADING_INDICATOR_LIST_ITEM, torCellDataList[0].type)
    }

    @Test
    fun testGetPendingTimeOffRequestsCellDataIsEmpty() {
        val torList = listOf(
            expectedSingleFullDayCellData.copy(pending = false),
            expectedSingleFullDayCellData.copy(pending = false)
        )

        val torCellDataList = TimeOffRequestSelectors.getPendingTimeOffRequestsCellData(false, torList)
        assertEquals(1, torCellDataList.count())
        assertEquals(TimeOffRequestListCellType.EMPTY_SECTION_LIST_ITEM, torCellDataList[0].type)
    }

    @Test
    fun testGetThisWeeksTimeOffRequestsCellData() {
        val torList = listOf(
            expectedSingleFullDayCellData.copy(occursThisWeek = true),
            expectedSingleFullDayCellData.copy(occursThisWeek = false)
        )

        val torCellDataList = TimeOffRequestSelectors.getThisWeeksTimeOffRequestsCellData(false, torList)
        assertEquals(1, torCellDataList.count())
        assertEquals(true, torCellDataList[0].occursThisWeek)
    }

    @Test
    fun testGetThisWeeksTimeOffRequestsCellDataIsLoading() {
        val torList = listOf(
            expectedSingleFullDayCellData.copy(occursThisWeek = true),
            expectedSingleFullDayCellData.copy(occursThisWeek = false)
        )

        val torCellDataList = TimeOffRequestSelectors.getThisWeeksTimeOffRequestsCellData(true, torList)
        assertEquals(1, torCellDataList.count())
        assertEquals(TimeOffRequestListCellType.LOADING_INDICATOR_LIST_ITEM, torCellDataList[0].type)
    }

    @Test
    fun testGetThisWeeksTimeOffRequestsCellDataIsEmpty() {
        val torList = listOf(
            expectedSingleFullDayCellData.copy(occursThisWeek = false),
            expectedSingleFullDayCellData.copy(occursThisWeek = false)
        )

        val torCellDataList = TimeOffRequestSelectors.getThisWeeksTimeOffRequestsCellData(false, torList)
        assertEquals(1, torCellDataList.count())
        assertEquals(TimeOffRequestListCellType.EMPTY_SECTION_LIST_ITEM, torCellDataList[0].type)
    }

    @Test
    fun testGetUpcomingTimeOffRequestsCellData() {
        val torList = listOf(
            expectedSingleFullDayCellData.copy(occursAfterThisWeek = true),
            expectedSingleFullDayCellData.copy(occursAfterThisWeek = false)
        )

        val torCellDataList = TimeOffRequestSelectors.getUpcomingTimeOffRequestsCellData(false, torList)
        assertEquals(1, torCellDataList.count())
        assertEquals(true, torCellDataList[0].occursAfterThisWeek)
    }

    @Test
    fun testGetUpcomingTimeOffRequestsCellDataIsLoading() {
        val torList = listOf(
            expectedSingleFullDayCellData.copy(occursAfterThisWeek = true),
            expectedSingleFullDayCellData.copy(occursAfterThisWeek = false)
        )

        val torCellDataList = TimeOffRequestSelectors.getUpcomingTimeOffRequestsCellData(true, torList)
        assertEquals(1, torCellDataList.count())
        assertEquals(TimeOffRequestListCellType.LOADING_INDICATOR_LIST_ITEM, torCellDataList[0].type)
    }

    @Test
    fun testGetUpcomingTimeOffRequestsCellDataIsEmpty() {
        val torList = listOf(
            expectedSingleFullDayCellData.copy(occursAfterThisWeek = false),
            expectedSingleFullDayCellData.copy(occursAfterThisWeek = false)
        )

        val torCellDataList = TimeOffRequestSelectors.getUpcomingTimeOffRequestsCellData(false, torList)
        assertEquals(1, torCellDataList.count())
        assertEquals(TimeOffRequestListCellType.EMPTY_SECTION_LIST_ITEM, torCellDataList[0].type)
    }

    @Test
    fun `test dates extension property on single full day TOR`() {
        val dates = singleFullDayTOR.dates
        assertEquals(dates, listOf(DateTime.parse("2000-02-01")))
    }

    @Test
    fun `test dates extension property on single partial day TOR`() {
        val dates = singleDayPartialTOR.dates
        assertEquals(dates, listOf(DateTime.parse("2000-02-01T01:00:00Z")))
    }

    @Test
    fun `test dates extension property on multiple full day TOR`() {
        val dates = multipleFullDayTOR.dates
        assertEquals(
            dates, listOf(
                DateTime.parse("2000-02-01"),
                DateTime.parse("2000-02-03"),
                DateTime.parse("2000-02-05")
            )
        )
    }

    @Test
    fun `test dates extension property on multiple partial day TOR`() {
        val dates = multipleDayPartialTOR.dates
        assertEquals(dates, listOf(
            DateTime.parse("2000-02-01T01:00:00Z"),
            DateTime.parse("2000-02-03T01:00:00Z"),
            DateTime.parse("2000-02-05T01:00:00Z")
        ))
    }

    @Test
    fun testGetTimeOffRequestDetailsModel() {
        val user = generateUser()
        val activityCode = generateActivityCode(id = singleFullDayTOR.activityCodeId)

        val model = TimeOffRequestSelectors.getTimeOffRequestDetailsModel(
            timeOffRequest = singleFullDayTOR,
            timeZoneName = DEFAULT_TIME_ZONE_NAME,
            userById = mapOf(user.id to user),
            activityCodeMap = mapOf(activityCode.id to activityCode)
        )

        val expectedModel = TimeOffRequestDetailsModel(
            id = singleFullDayTOR.id,
            type = activityCode.displayName,
            isFullDayRequest = singleFullDayTOR.isFullDayRequest,
            startDate = "02/01/2000",
            startDay = "Tue",
            startTime = "",
            endDate = "02/01/2000",
            endDay = "Tue",
            endTime = "",
            duration = "8h 0m",
            notes = singleFullDayTOR.notes,
            status = singleFullDayTOR.status,
            submittedByUserName = user.name!!,
            submittedByDate = "01/01/2000",
            hasOccurred = true
        )

        assertEquals(expectedModel, model)
    }
}
