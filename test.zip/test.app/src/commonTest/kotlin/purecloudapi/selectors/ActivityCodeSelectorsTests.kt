package com.genesys.purecloud.wfmshared.purecloudapi.selectors

import com.genesys.purecloud.wfmshared.purecloudapi.selectors.ActivityCodeSelectors.getAgentTimeOffSelectableActivityCodes
import com.genesys.purecloud.wfmshared.purecloudapi.selectors.ActivityCodeSelectors.getDefaultTimeOffActivityCode
import com.genesys.purecloud.wfmshared.testutil.generateActivityCode
import com.genesys.purecloud.wfmshared.testutil.generateActivityCodeMap
import kotlin.test.Test
import kotlin.test.assertEquals

class ActivityCodeSelectorsTests {
    private val defaultActiveSelectableActivityCode = generateActivityCode(id = "id1", agentTimeOffSelectable = true, isActive = true, isDefault = true)
    private val activeSelectableActivityCode = generateActivityCode(id = "id2", agentTimeOffSelectable = true, isActive = true, isDefault = false)
    private val inactiveSelectableActivityCode = generateActivityCode(id = "id3", agentTimeOffSelectable = true, isActive = false, isDefault = false)
    private val inactiveNotSelectableActivityCode = generateActivityCode(id = "id4", agentTimeOffSelectable = false, isActive = false, isDefault = false)

    @Test
    fun testGetAgentTimeOffSelectableActivityCodes() {
        var acMap = generateActivityCodeMap(
            defaultActiveSelectableActivityCode,
            activeSelectableActivityCode,
            inactiveSelectableActivityCode,
            inactiveNotSelectableActivityCode
        )
        var selectableCodes = getAgentTimeOffSelectableActivityCodes(acMap)
        assertEquals(2, selectableCodes.size)

        acMap = generateActivityCodeMap(
            defaultActiveSelectableActivityCode
        )
        selectableCodes = getAgentTimeOffSelectableActivityCodes(acMap)
        assertEquals(1, selectableCodes.size)

        acMap = generateActivityCodeMap(
            inactiveNotSelectableActivityCode
        )
        selectableCodes = getAgentTimeOffSelectableActivityCodes(acMap)
        assertEquals(0, selectableCodes.size)

        acMap = generateActivityCodeMap()
        selectableCodes = getAgentTimeOffSelectableActivityCodes(acMap)
        assertEquals(0, selectableCodes.size)
    }

    @Test
    fun testGetDefaultTimeOffActivityCode() {
        var acMap = generateActivityCodeMap(
            defaultActiveSelectableActivityCode,
            activeSelectableActivityCode,
            inactiveSelectableActivityCode,
            inactiveNotSelectableActivityCode
        )

        var defaultCode = getDefaultTimeOffActivityCode(acMap)

        assertEquals(defaultActiveSelectableActivityCode, defaultCode)

        acMap = generateActivityCodeMap(
            activeSelectableActivityCode,
            inactiveSelectableActivityCode,
            inactiveNotSelectableActivityCode
        )
        defaultCode = getDefaultTimeOffActivityCode(acMap)

        assertEquals(null, defaultCode)

        acMap = generateActivityCodeMap()
        defaultCode = getDefaultTimeOffActivityCode(acMap)

        assertEquals(null, defaultCode)
    }
}
