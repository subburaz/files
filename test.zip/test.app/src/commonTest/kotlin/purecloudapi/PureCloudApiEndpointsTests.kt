package com.genesys.purecloud.wfmshared.purecloudapi

import kotlin.test.Test
import kotlin.test.assertEquals

class PureCloudApiEndpointsTests {
    @Test
    fun testGetUsersTors() {
        assertEquals(
            "api/v2/workforcemanagement/timeoffrequests",
            PureCloudApiEndpoints.GET_USERS_TORS
        )
    }

    @Test
    fun testGetUsersMu() {
        assertEquals(
            "api/v2/workforcemanagement/managementunits/mine?expand=settings",
            PureCloudApiEndpoints.GET_USERS_MU
        )
    }

    @Test
    fun testPatchUsersTors() {
        assertEquals(
            "api/v2/workforcemanagement/timeoffrequests",
            PureCloudApiEndpoints.PATCH_USER_TORS
        )
    }
}
