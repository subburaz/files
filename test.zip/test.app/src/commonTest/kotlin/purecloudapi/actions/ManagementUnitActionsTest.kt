package com.genesys.purecloud.wfmshared.purecloudapi.actions

import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.AdherenceSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.IgnoredActivityCategories
import com.genesys.purecloud.wfmshared.purecloudapi.entities.IgnoredActivityCategories.Values.OFF_QUEUE_WORK
import com.genesys.purecloud.wfmshared.purecloudapi.entities.IgnoredActivityCategories.Values.ON_QUEUE_WORK
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnitSettingsResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ShortTermForecastingSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.UserReference
import com.genesys.purecloud.wfmshared.purecloudapi.entities.WfmVersionedEntityMetadata
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.testutil.generateMockHttpClient
import com.genesys.purecloud.wfmshared.testutil.runBlockingTest
import com.genesys.purecloud.wfmshared.util.ServiceLocator
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotEquals

class ManagementUnitActionsTest {
    @Test
    fun testGetUsersTimeOffRequests() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val mu = ManagementUnit(
            id = "id",
            timeZone = "America/New_York",
            selfUri = "selfUri",
            startDayOfWeek = ManagementUnit.StartDayOfWeek.SUNDAY,
            settings = ManagementUnitSettingsResponse(
                adherence = AdherenceSettings(
                    severeAlertThresholdMinutes = 0,
                    adherenceTargetPercent = 0,
                    adherenceExceptionThresholdSeconds = 0,
                    nonOnQueueActivitiesEquivalent = false,
                    trackOnQueueActivity = false,
                    ignoredActivityCategories = IgnoredActivityCategories(
                        listOf(ON_QUEUE_WORK)
                    )
                ),
                shortTermForecasting = ShortTermForecastingSettings(0),
                timeOff = TimeOffRequestSettings(false, 0, 0),
                metadata = WfmVersionedEntityMetadata(42, UserReference("", ""), "")
            )
        )

        val path = PureCloudApiEndpoints.GET_USERS_MU

        ServiceLocator.TestUtils.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(path),
                        serviceLocator.jsonSerializer.stringify(
                            ManagementUnit.serializer(),
                            mu
                        )
                    )
                )
            )
        )

        val unit = runBlockingTest {
            getUsersManagementUnit()
        }
        assertEquals(mu, unit)
    }

    @Suppress("ReplaceCallWithBinaryOperator")
    @Test
    fun shouldSupportEqualsForIgnoredActivityCategories() {
        val instance1 = IgnoredActivityCategories(listOf(ON_QUEUE_WORK))
        val instance2 = IgnoredActivityCategories(listOf(ON_QUEUE_WORK))
        val instance3 = IgnoredActivityCategories(listOf(ON_QUEUE_WORK, OFF_QUEUE_WORK))
        val instance4 = IgnoredActivityCategories(listOf(OFF_QUEUE_WORK, ON_QUEUE_WORK))
        val instance5 = IgnoredActivityCategories(listOf(OFF_QUEUE_WORK, ON_QUEUE_WORK))

        assertFalse(instance1.equals(null))
        assertEquals(instance1, instance1)
        assertEquals(instance1, instance2)
        assertNotEquals(instance2, instance3)
        assertNotEquals(instance3, instance2)
        assertNotEquals(instance3, instance4)
        assertNotEquals(instance4, instance3)
        assertEquals(instance5, instance4)
        assertEquals(instance4, instance5)
        assertFalse { instance1.equals("") }
        assertFalse { "".equals(instance3) }
    }
}
