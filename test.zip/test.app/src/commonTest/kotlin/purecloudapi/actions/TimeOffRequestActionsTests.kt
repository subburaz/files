package com.genesys.purecloud.wfmshared.purecloudapi.actions

import com.genesys.purecloud.wfmshared.AuthenticationData
import com.genesys.purecloud.wfmshared.AuthenticationListener
import com.genesys.purecloud.wfmshared.components.timeoffrequest.details.TimeOffRequestDetailsModel
import com.genesys.purecloud.wfmshared.domain.repositories.IActivityCodeRepository
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.AdherenceSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.AgentTimeOffRequestPatch
import com.genesys.purecloud.wfmshared.purecloudapi.entities.CreateAgentTimeOffRequest
import com.genesys.purecloud.wfmshared.purecloudapi.entities.IgnoredActivityCategories
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnitSettingsResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ShortTermForecastingSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestList
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestSettings
import com.genesys.purecloud.wfmshared.purecloudapi.entities.UserReference
import com.genesys.purecloud.wfmshared.purecloudapi.entities.WfmVersionedEntityMetadata
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.testutil.IgnoreIos
import com.genesys.purecloud.wfmshared.testutil.generateActivityCode
import com.genesys.purecloud.wfmshared.testutil.generateActivityCodeResponse
import com.genesys.purecloud.wfmshared.testutil.generateApiUrl
import com.genesys.purecloud.wfmshared.testutil.generateMockHttpClient
import com.genesys.purecloud.wfmshared.testutil.generateTimeOffRequest
import com.genesys.purecloud.wfmshared.testutil.populateCommonTestStrings
import com.genesys.purecloud.wfmshared.testutil.runBlockingTest
import com.genesys.purecloud.wfmshared.testutil.withMockHttpResponses
import com.genesys.purecloud.wfmshared.util.DEFAULT_TIME_ZONE_NAME
import com.genesys.purecloud.wfmshared.util.ServiceLocator
import kotlin.random.Random
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals
import org.kodein.di.Kodein
import org.kodein.di.erased.instance

class TimeOffRequestActionsTests {
    private lateinit var di: Kodein

    private val apiUrl = generateApiUrl()
    private val mockHttpResponses = mapOf(
        "$apiUrl/api/v2/workforcemanagement/businessunits/mine/activitycodes" to generateActivityCodeResponse(generateActivityCode())
    )

    @BeforeTest
    fun setup() {
        di = kodein.withMockHttpResponses(mockHttpResponses)

        val auth: AuthenticationListener by di.instance()

        auth.loggedIn(
            AuthenticationData(
                apiUrl = apiUrl,
                accessToken = "accessToken",
                userAgent = "userAgent"
            )
        )
    }

    @Test
    fun testGetUsersTimeOffRequests() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val tor = generateTimeOffRequest(setOf("2000-01-01"), emptySet())
        val getTorListResponseObject = TimeOffRequestList(timeOffRequests = listOf(tor))

        val path = PureCloudApiEndpoints.GET_USERS_TORS

        ServiceLocator.TestUtils.setHttpClient(
            serviceLocator, generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(path),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestList.serializer(),
                            getTorListResponseObject
                        )
                    )
                )
            )
        )

        val requests = runBlockingTest {
            getUsersTimeOffRequests()
        }

        assertEquals(tor, requests.first())
    }

    @Test
    fun testGetTimeOffRequest() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val tor = generateTimeOffRequest(
            id = "testId",
            fullDays = setOf("2000-01-01"),
            partialDays = emptySet()
        )

        val torPath = "${PureCloudApiEndpoints.GET_USERS_TORS}/${tor.id}"

        ServiceLocator.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(torPath),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestResponse.serializer(),
                            tor
                        )
                    )
                )
            )
        )

        runBlockingTest {
            val request = getTimeOffRequest(tor.id)
            assertEquals(tor, request)
        }
    }

    @Test
    fun `patchUsersTimeOffRequests successful returns proper response`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val tor = generateTimeOffRequest(setOf("2000-01-01"), emptySet())
        val userTorId = "TorId-" + Random.Default.nextInt()
        val path = "${PureCloudApiEndpoints.PATCH_USER_TORS}/$userTorId"
        ServiceLocator.TestUtils.setHttpClient(
            serviceLocator, generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(path),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestResponse.serializer(), tor
                        )
                    )
                )
            )
        )
        val requestBody =
            AgentTimeOffRequestPatch(
                status = AgentTimeOffRequestPatch.Status.CANCELED,
                notes = "notes"
            )

        val requests = runBlockingTest {
            patchUsersTimeOffRequest(requestBody, userTorId)
        }

        assertEquals(tor, requests)
    }

    @Test
    fun `postUsersTimeOffRequests successful returns proper response`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val tor = generateTimeOffRequest(setOf("2000-01-01"), emptySet())
        val path = PureCloudApiEndpoints.POST_USERS_TORS

        ServiceLocator.TestUtils.setHttpClient(
            serviceLocator, generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(path),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestResponse.serializer(), tor
                        )
                    )
                )
            )
        )

        val requests = runBlockingTest {
            postUsersTimeOffRequests(CreateAgentTimeOffRequest(
                "213",
                20,
                "abc",
                emptySet(),
                emptySet()
            ))
        }

        assertEquals(tor, requests)
    }

    @Test
    fun `postUsersTimeOffRequests fails with exception returns null`() {
        serviceLocator.initializeApiData(
            apiUrl = "http://test.com/exception",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val path = PureCloudApiEndpoints.POST_USERS_TORS

        ServiceLocator.TestUtils.setHttpClient(
            serviceLocator, generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(path),
                        "exception"
                    )
                )
            )
        )

        val requests = runBlockingTest {
            postUsersTimeOffRequests(CreateAgentTimeOffRequest(
                "213",
                20,
                "abc",
                emptySet(),
                emptySet()
            ))
        }

        assertEquals(null, requests)
    }

    @Test
    @IgnoreIos
    fun fetchTimeOffRequestDetails() {
        populateCommonTestStrings()

        serviceLocator.initializeApiData(
            apiUrl = "http://test.com",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val tor = generateTimeOffRequest(
            id = "testId",
            fullDays = setOf("2000-01-01", "2000-01-03"),
            partialDays = emptySet()
        )

        val mu = ManagementUnit(
            id = "id",
            timeZone = DEFAULT_TIME_ZONE_NAME,
            selfUri = "selfUri",
            startDayOfWeek = ManagementUnit.StartDayOfWeek.SUNDAY,
            settings = ManagementUnitSettingsResponse(
                adherence = AdherenceSettings(
                    severeAlertThresholdMinutes = 0,
                    adherenceTargetPercent = 0,
                    adherenceExceptionThresholdSeconds = 0,
                    nonOnQueueActivitiesEquivalent = false,
                    trackOnQueueActivity = false,
                    ignoredActivityCategories = IgnoredActivityCategories(
                        listOf(IgnoredActivityCategories.Values.ON_QUEUE_WORK)
                    )
                ),
                shortTermForecasting = ShortTermForecastingSettings(0),
                timeOff = TimeOffRequestSettings(false, 0, 0),
                metadata = WfmVersionedEntityMetadata(42, UserReference("", ""), "")
            )
        )

        val torPath = "${PureCloudApiEndpoints.GET_USERS_TORS}/${tor.id}"
        val muPath = PureCloudApiEndpoints.GET_USERS_MU

        ServiceLocator.setHttpClient(
            serviceLocator,
            generateMockHttpClient(
                mapOf(
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(torPath),
                        serviceLocator.jsonSerializer.stringify(
                            TimeOffRequestResponse.serializer(),
                            tor
                        )
                    ),
                    Pair(
                        serviceLocator.apiData!!.buildFullPath(muPath),
                        serviceLocator.jsonSerializer.stringify(
                            ManagementUnit.serializer(),
                            mu
                        )
                    )
                )
            )
        )

        val activityCodeRepository: IActivityCodeRepository by di.instance()

        runBlockingTest {
            val detailsModel = fetchTimeOffRequestDetails(tor.id, activityCodeRepository)
            assertNotEquals(TimeOffRequestDetailsModel(), detailsModel)
            assertEquals("01/01/2000", detailsModel.startDate)
            assertEquals("Sat", detailsModel.startDay)
            assertEquals("01/03/2000", detailsModel.endDate)
            assertEquals("Mon", detailsModel.endDay)
        }
    }
}
