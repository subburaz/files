package com.genesys.purecloud.wfmshared.purecloudapi

import kotlin.test.Test
import kotlin.test.assertEquals

class PureCloudApiDataTests {
    @Test
    fun testBuildFullPath() {
        val apiUrl = "https://test.com"
        val path = "test"
        val apiData = PureCloudApiData(
            apiUrl = apiUrl,
            accessToken = "accessToken",
            userAgent = "userAgent"
        )

        val fullPath = apiData.buildFullPath(path)

        assertEquals("https://test.com/test", fullPath)
    }
}
