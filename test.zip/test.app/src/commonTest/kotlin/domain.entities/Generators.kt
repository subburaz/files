package com.genesys.purecloud.wfmshared.domain.entities

import com.genesys.purecloud.wfmshared.testutil.Generator
import com.genesys.purecloud.wfmshared.testutil.booleans
import com.genesys.purecloud.wfmshared.testutil.dateTimes
import com.genesys.purecloud.wfmshared.testutil.enumValues
import com.genesys.purecloud.wfmshared.testutil.ints
import com.genesys.purecloud.wfmshared.testutil.lists
import com.genesys.purecloud.wfmshared.testutil.strings
import com.soywiz.klock.DateTime
import kotlin.random.Random

fun Generator.Companion.activities(
    random: Random = Random.Default,
    categories: Sequence<ActivityCode.Category> = enumValues(random),
    descriptions: Sequence<String?> = strings(),
    countsAsPaidTimes: Sequence<Boolean> = booleans(random),
    lengthsInMinutes: Sequence<Int> = ints(0..5000, random),
    startTimes: Sequence<DateTime> = dateTimes(random = random)
) = categories.zip(descriptions).zip(countsAsPaidTimes).zip(lengthsInMinutes).zip(startTimes)
        .map {
            Activity(
                category = it.first.first.first.first,
                description = it.first.first.first.second,
                countsAsPaidTime = it.first.first.second,
                lengthInMinutes = it.first.second,
                startTime = it.second)
        }

fun Generator.Companion.shifts(
    random: Random = Random.Default,
    startDates: Sequence<DateTime> = dateTimes(random = random),
    lengthsInMinutes: Sequence<Int> = ints(0..5000, random),
    activities: Sequence<List<Activity>> = lists({ Generator.activities(random) })
) = startDates.zip(lengthsInMinutes).zip(activities)
        .map {
            Shift(
                startDate = it.first.first,
                lengthInMinutes = it.first.second,
                activities = it.second
            )
        }
