package com.genesys.purecloud.wfmshared.domain.entities

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ActivityCodeCategoryTests {
    private val expectedValues = setOf(
        ActivityCode.Category.BREAK,
        ActivityCode.Category.MEETING,
        ActivityCode.Category.MEAL,
        ActivityCode.Category.TIME_OFF,
        ActivityCode.Category.TRAINING,
        ActivityCode.Category.OFF_QUEUE_WORK,
        ActivityCode.Category.ON_QUEUE,
        ActivityCode.Category.UNAVAILABLE,
        ActivityCode.Category.UNSCHEDULED
    )

    @Test
    fun `should be an enum`() {
        expectedValues.forEach {
            @Suppress("USELESS_IS_CHECK")
            assertTrue(it is Enum<ActivityCode.Category>, "$it is an enum value")
        }
    }

    @Test
    fun `should only have values BREAK MEETING MEAL TIME_OFF TRAINING OFF_QUEUE_WORK ON_QUEUE UNAVAILABLE UNSCHEDULED`() {
        assertEquals(
            expectedValues,
            ActivityCode.Category.values().toSet(),
            "ActivityCode.Category.values()"
        )
    }
}
