package com.genesys.purecloud.wfmshared.domain.entities

import com.genesys.purecloud.wfmshared.testutil.Generator
import com.genesys.purecloud.wfmshared.testutil.assertContains
import com.genesys.purecloud.wfmshared.testutil.assertEndsWith
import com.genesys.purecloud.wfmshared.testutil.assertProperty
import com.genesys.purecloud.wfmshared.testutil.assertStartsWith
import com.genesys.purecloud.wfmshared.testutil.booleans
import com.genesys.purecloud.wfmshared.testutil.dateTimes
import com.genesys.purecloud.wfmshared.testutil.enumValues
import com.genesys.purecloud.wfmshared.testutil.ints
import com.genesys.purecloud.wfmshared.testutil.strings
import com.soywiz.klock.DateTime
import com.soywiz.klock.days
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals
import kotlin.test.assertNull

class ActivityTests {
    private lateinit var category: ActivityCode.Category
    private var lengthInMinutes: Int = 0
    private var countsAsPaidTime: Boolean = false
    private var startTime = DateTime.now()
    private var description: String? = null

    private fun instance(
        category: ActivityCode.Category = this.category,
        lengthInMinutes: Int = this.lengthInMinutes,
        countsAsPaidTime: Boolean = this.countsAsPaidTime,
        startTime: DateTime = this.startTime,
        description: String? = this.description
    ) = Activity(
        category = category,
        startTime = startTime,
        lengthInMinutes = lengthInMinutes,
        description = description,
        countsAsPaidTime = countsAsPaidTime)

    @BeforeTest
    fun setup() {
        category = Generator.enumValues<ActivityCode.Category>().first()
        lengthInMinutes = Generator.ints(0..3000).first()
        countsAsPaidTime = Generator.booleans().first()
        startTime = Generator.dateTimes().first()
        description = Generator.strings().first()
    }

    @Test
    fun `should have category property`() {
        with(Activity::category) {
            assertProperty(
                nullable = false,
                mutable = false,
                name = "category"
            )

            enumValues<ActivityCode.Category>()
                .asSequence()
                .map { it to Generator.activities(categories = sequenceOf(it)).first() }
                .forEach { (category, instance) ->
                    assertEquals(category, instance.category, name)
                }
        }
    }

    @Test
    fun `should have lengthInMinutes property`() {
        with(Activity::lengthInMinutes) {
            assertProperty(
                nullable = false,
                mutable = false,
                name = "lengthInMinutes"
            )

            Generator.ints(0..3000)
                .take(10)
                .map { it to Generator.activities(lengthsInMinutes = sequenceOf(it)).first() }
                .forEach { (length, instance) ->
                    assertEquals(length, instance.lengthInMinutes, name)
                }
        }
    }

    @Test
    fun `should have countsAsPaidTime property`() {
        with(Activity::countsAsPaidTime) {
            assertProperty(
                nullable = false,
                mutable = false,
                name = "countsAsPaidTime"
            )

            sequenceOf(true, false)
                .map { it to Generator.activities(countsAsPaidTimes = sequenceOf(it)).first() }
                .forEach { (value, instance) ->
                    assertEquals(value, instance.countsAsPaidTime, name)
                }
        }
    }

    @Test
    fun `should have startTime property`() {
        with(Activity::startTime) {
            assertProperty(
                nullable = false,
                mutable = false,
                name = "startTime"
            )

            Generator.dateTimes()
                .take(10)
                .map { it to Generator.activities(startTimes = sequenceOf(it)).first() }
                .forEach { (time, instance) ->
                    assertEquals(time, instance.startTime, name)
                }
        }
    }

    @Test
    fun `should have description property`() {
        with(Activity::description) {
            assertProperty(
                nullable = true,
                mutable = false,
                name = "description"
            )

            Generator.strings()
                .take(10)
                .map { it to Generator.activities(descriptions = sequenceOf(it)).first() }
                .forEach { (description, instance) ->
                    assertEquals(description, instance.description, name)
                }
        }
    }

    @Test
    fun `should accept null for description`() {
        assertNull(
            Generator.activities(descriptions = sequenceOf(null)).first().description
        )
    }

    @Test
    fun `toString should include class name and all properties`() {
        with(instance()) {
            with(toString()) {
                assertStartsWith("Activity(")
                assertContains("category=$category")
                assertContains("startTime=$startTime")
                assertContains("lengthInMinutes=$lengthInMinutes")
                assertContains("countsAsPaidTime=$countsAsPaidTime")
                assertContains("description=$description")
                assertEndsWith(")")
            }
        }
    }

    @Test
    fun `equals should be true if all fields the same`() {
        assertEquals(instance(), instance())
    }

    @Test
    fun `equals should be false if lengthInMinutes differs`() {
        assertNotEquals(
            instance(lengthInMinutes = Generator.ints(0..50).first()),
            instance(lengthInMinutes = Generator.ints(100..150).first())
        )
    }

    @Test
    fun `equals should be false if countsAsPaidTime differs`() {
        assertNotEquals(
            instance(countsAsPaidTime = true),
            instance(countsAsPaidTime = false)
        )
    }

    @Test
    fun `equals should be false if startTime differs`() {
        assertNotEquals(
            instance(startTime = DateTime.now()),
            instance(startTime = DateTime.now().plus(2.days))
        )
    }

    @Test
    fun `equals should be false if description differs`() {
        Generator.strings()
            .distinct()
            .take(2)
            .toList()
            .let { (a, b) ->
                assertNotEquals(
                    instance(description = a),
                    instance(description = b)
                )
                assertNotEquals(
                    instance(description = a),
                    instance(description = null)
                )
        }
    }

    @Test
    fun `equals should be false if category differs`() {
        Generator.enumValues<ActivityCode.Category>()
            .distinct()
            .take(2)
            .map { instance(category = it) }
            .toList()
            .run {
                assertNotEquals(first(), last())
            }
    }
}
