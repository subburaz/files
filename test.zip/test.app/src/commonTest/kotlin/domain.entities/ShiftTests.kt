package com.genesys.purecloud.wfmshared.domain.entities

import com.genesys.purecloud.wfmshared.testutil.Generator
import com.genesys.purecloud.wfmshared.testutil.assertProperty
import com.genesys.purecloud.wfmshared.testutil.dateTimes
import com.genesys.purecloud.wfmshared.testutil.ints
import com.genesys.purecloud.wfmshared.testutil.lists
import kotlin.test.Test
import kotlin.test.assertEquals

class ShiftTests {
    @Test
    fun `should have lengthInMinutes property`() {

        with(Shift::lengthInMinutes) {
            assertProperty(
                nullable = false,
                mutable = false,
                name = "lengthInMinutes"
            )

            Generator.ints(0..3000)
                .take(10)
                .map { it to Generator.shifts(lengthsInMinutes = sequenceOf(it)).first() }
                .forEach { (length, instance) ->
                    assertEquals(length, instance.lengthInMinutes, name)
                }
        }
    }

    @Test
    fun `should have startDate property`() {
        with(Shift::startDate) {
            assertProperty(
                nullable = false,
                mutable = false,
                name = "startDate"
            )

            Generator.dateTimes()
                .take(10)
                .map { it to Generator.shifts(startDates = sequenceOf(it)).first() }
                .forEach { (date, instance) ->
                    assertEquals(date, instance.startDate, name)
                }
        }
    }

    @Test
    fun `should have activities property`() {
        with(Shift::activities) {
            assertProperty(
                nullable = false,
                mutable = false,
                name = "activities"
            )

            Generator.lists({ Generator.activities(it) })
                .take(10)
                .map { it to Generator.shifts(activities = sequenceOf(it)).first() }
                .forEach { (activities, instance) ->
                    assertEquals(activities, instance.activities, name)
                }
        }
    }
}
