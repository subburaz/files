package com.genesys.purecloud.wfmshared.testutil

expect fun overrideTimeZone(timeZoneName: String?)

inline fun useTimeZone(timeZoneName: String, block: () -> Unit) {
    try {
        overrideTimeZone(timeZoneName)
        block()
    } finally {
        overrideTimeZone(null)
    }
}
