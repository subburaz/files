package com.genesys.purecloud.wfmshared.testutil

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class TimeOffRequestGeneratorTests {
    @Test
    fun testGenerateTimeOffRequestsThrowsOnBothEmpty() {
        val exception = assertFailsWith<Exception> { generateTimeOffRequest(emptySet(), emptySet()) }
        assertEquals(TWO_EMPTY_EXCEPTION_MESSAGE, exception.message)
    }

    @Test
    fun testGenerateTimeOffRequestsThrowsOnBothNonEmpty() {
        val exception = assertFailsWith<Exception> { generateTimeOffRequest(setOf(""), setOf("")) }
        assertEquals(TWO_NON_EMPTY_EXCEPTION_MESSAGE, exception.message)
    }

    @Test
    fun testGenerateTimeOffRequestWithFullDays() {
        val emptySet: Set<String> = emptySet()
        val fullDays: Set<String> = setOf(
            "2000-01-01"
        )

        val requestWithFullDays = generateTimeOffRequest(
            fullDays = fullDays,
            partialDays = emptySet
        )

        assertEquals(fullDays, requestWithFullDays.fullDayManagementUnitDates)
        assertEquals(emptySet, requestWithFullDays.partialDayStartDateTimes)
        assertEquals(true, requestWithFullDays.isFullDayRequest)
    }

    @Test
    fun testGenerateTimeOffRequestWithPartialDays() {
        val emptySet: Set<String> = emptySet()
        val partialDays: Set<String> = setOf(
            "2000-01-01T00:00:00Z"
        )

        val requestWithPartialDays = generateTimeOffRequest(
            fullDays = emptySet,
            partialDays = partialDays
        )

        assertEquals(emptySet, requestWithPartialDays.fullDayManagementUnitDates)
        assertEquals(partialDays, requestWithPartialDays.partialDayStartDateTimes)
        assertEquals(false, requestWithPartialDays.isFullDayRequest)
    }
}
