package com.genesys.purecloud.wfmshared.testutil

import com.genesys.purecloud.wfmshared.di.COROUTINE_SCOPE_BG_TAG
import com.genesys.purecloud.wfmshared.di.COROUTINE_SCOPE_UI_TAG
import io.ktor.client.engine.HttpClientEngine
import kotlinx.coroutines.CoroutineScope
import org.kodein.di.Copy
import org.kodein.di.Kodein
import org.kodein.di.erased.bind
import org.kodein.di.erased.singleton

fun Kodein.withTestCoroutineScopes() =
    Kodein {
        // extend and copy all bindings so that they use the singletons declared here
        extend(this@withTestCoroutineScopes, allowOverride = true, copy = Copy.All)

        bind<CoroutineScope>(tag = COROUTINE_SCOPE_BG_TAG, overrides = true) with singleton { getTestCoroutineBGScope() }
        bind<CoroutineScope>(tag = COROUTINE_SCOPE_UI_TAG, overrides = true) with singleton { getTestCoroutineUIScope() }
    }

fun Kodein.withMockHttpResponses(responses: Map<String, Any>) =
    Kodein {
        // extend and copy all bindings so that they use the singletons declared here
        extend(this@withMockHttpResponses, allowOverride = true, copy = Copy.All)

        bind<HttpClientEngine>() with singleton {
            generateMockHttpClientEngine(responses)
        }
    }
