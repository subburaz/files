@file:Suppress("unused")

package com.genesys.purecloud.wfmshared.testutil

import kotlin.reflect.KMutableProperty
import kotlin.reflect.KProperty
import kotlin.test.assertEquals
import kotlin.test.assertTrue

fun <R> KProperty<R>.assertProperty(
    nullable: Boolean? = null,
    mutable: Boolean? = null,
    name: String? = null
) {
    nullable?.let { assertEquals(returnType.isMarkedNullable, it, "$this is nullable") }
    mutable?.let { assertEquals(this is KMutableProperty<*>, it, "$this is mutable") }
    name?.let { assertEquals(name, it, "$this name") }
}

fun String.assertStartsWith(prefix: String) {
    assertTrue("$this startsWith \"$prefix\"") { startsWith(prefix) }
}

fun String.assertEndsWith(suffix: String) {
    assertTrue("$this endsWith \"$suffix\"") { endsWith(suffix) }
}

fun String.assertContains(string: String) {
    assertTrue("$this contains \"$string\"") { contains(string) }
}
