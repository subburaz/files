@file:Suppress("EXPERIMENTAL_API_USAGE")

package com.genesys.purecloud.wfmshared.testutil

import io.ktor.client.HttpClient
import io.ktor.client.engine.mock.MockEngine
import io.ktor.client.engine.mock.respond
import io.ktor.client.engine.mock.toByteArray
import io.ktor.client.features.json.serializer.KotlinxSerializer
import io.ktor.http.ContentType
import io.ktor.http.Url
import io.ktor.http.fullPath
import io.ktor.http.headersOf
import io.ktor.http.hostWithPort
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonConfiguration

private val Url.hostWithPortIfRequired: String get() = if (port == protocol.defaultPort) host else hostWithPort
private val Url.fullUrl: String get() = "${protocol.name}://$hostWithPortIfRequired$fullPath"
private val jsonHeader = headersOf("Content-Type", ContentType.Application.Json.toString())
private val json = Json(JsonConfiguration.Stable.copy(ignoreUnknownKeys = true))
private val serializer = KotlinxSerializer(json)
/**
 * Uses Ktor `MockEngine` https://ktor.io/clients/http-client/testing.html
 */
internal fun generateMockHttpClient(responses: Map<String, String>) =
    HttpClient(MockEngine) {
        engine {
            addHandler { request ->
                respond(
                    content = request.url.fullUrl.let { responses[it] ?: error("Unhandled $it") },
                    headers = jsonHeader
                )
            }
        }
    }

internal fun generateMockHttpClientEngine(responses: Map<String, Any>) =
    MockEngine.create {
        addHandler { request ->
            respond(
                content = request.url.fullUrl.let { responses[it] ?: error("Unhandled $it") }
                    .let { serializer.write(it).toByteArray() },
                headers = jsonHeader
            )
        }
    }
