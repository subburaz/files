package com.genesys.purecloud.wfmshared.testutil

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.util.resources.CommonStrings
import org.kodein.di.erased.instance

fun populateCommonTestStrings() {
    val commonStrings: CommonStrings by kodein.instance()

    commonStrings.update(mapOf(
        MR.strings.date_format_time to "h:mm a",
        MR.strings.date_format_day_short to "EEE",
        MR.strings.date_format_date_with_slashes to "MM/dd/yyyy",
        MR.strings.date_format_date_with_hyphens to "yyyy-MM-dd",
        MR.strings.hour_abbreviation to "h",
        MR.strings.minute_abbreviation to "m"
    ))
}
