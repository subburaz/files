package com.genesys.purecloud.wfmshared.testutil

import kotlinx.coroutines.CoroutineScope

expect fun getTestCoroutineBGScope(): CoroutineScope

expect fun getTestCoroutineUIScope(): CoroutineScope
