package com.genesys.purecloud.wfmshared.testutil

import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.UserReference
import com.genesys.purecloud.wfmshared.purecloudapi.entities.WfmVersionedEntityMetadata

const val TWO_EMPTY_EXCEPTION_MESSAGE = "Received 2 Empty Lists"
const val TWO_NON_EMPTY_EXCEPTION_MESSAGE = "Received 2 Non Empty Lists"
const val DAILY_DURATION_IN_MINUTES = 480

fun generateTimeOffRequest(
    fullDays: Set<String>,
    partialDays: Set<String>,
    status: TimeOffRequestResponse.Status = TimeOffRequestResponse.Status.APPROVED,
    dailyDurationInMinutes: Int = DAILY_DURATION_IN_MINUTES,
    id: String = "id",
    activityCodeId: String = "activityCodeId"
): TimeOffRequestResponse {
    if (fullDays.isEmpty() && partialDays.isEmpty()) {
        throw(Exception(TWO_EMPTY_EXCEPTION_MESSAGE))
    }

    if (fullDays.isNotEmpty() && partialDays.isNotEmpty()) {
        throw(Exception(TWO_NON_EMPTY_EXCEPTION_MESSAGE))
    }

    val userReference = UserReference(
        id = id,
        selfUri = "selfUri"
    )

    val metadata = WfmVersionedEntityMetadata(
        dateModified = "2000-01-01T00:00:00Z",
        modifiedBy = userReference,
        version = 1
    )

    return TimeOffRequestResponse(
        activityCodeId = activityCodeId,
        dailyDurationMinutes = dailyDurationInMinutes,
        fullDayManagementUnitDates = fullDays,
        user = userReference,
        id = id,
        isFullDayRequest = fullDays.any(),
        metadata = metadata,
        notes = "notes",
        partialDayStartDateTimes = partialDays,
        selfUri = "selfUri",
        status = status,
        submittedBy = userReference,
        submittedDate = "2000-01-01T00:00:00Z"
    )
}
