package com.genesys.purecloud.wfmshared.testutil

import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext
import kotlinx.coroutines.CoroutineScope

// Testing coroutines relies on the `runBlocking` call in jvm and native
// We are testing coroutines in a common package
// Common coroutines do not contain the `runBlocking` function because it cannot be implemented in JS.
// https://github.com/Kotlin/kotlinx.coroutines/issues/1039
// So we have to wrap `runBlocking` in our own `runBlockingTest` function
expect fun <T> runBlockingTest(context: CoroutineContext = EmptyCoroutineContext, block: suspend CoroutineScope.() -> T): T
