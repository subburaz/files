package com.genesys.purecloud.wfmshared.testutil

import com.soywiz.klock.DateTime
import com.soywiz.klock.days
import kotlin.random.Random

class Generator {
    companion object
}

fun Generator.Companion.doubles(
    range: ClosedRange<Double> = Double.MIN_VALUE..Double.MAX_VALUE,
    random: Random = Random.Default
) = generateSequence { random.nextDouble(range.start, range.endInclusive) }

fun Generator.Companion.ints(
    range: ClosedRange<Int> = Int.MIN_VALUE..Int.MAX_VALUE,
    random: Random = Random.Default
) = generateSequence { random.nextInt(range.start, range.endInclusive) }

fun Generator.Companion.dateTimes(
    range: ClosedRange<Double> = -15.0..15.0,
    random: Random = Random.Default
) = doubles(range, random)
    .map { DateTime.now() + it.days }

fun Generator.Companion.booleans(random: Random = Random.Default) =
    generateSequence { random.nextBoolean() }

inline fun <reified T : Enum<T>> Generator.Companion.enumValues(random: Random = Random.Default) =
    arrayValues(kotlin.enumValues<T>(), random)

fun <T> Generator.Companion.arrayValues(values: Array<T>, random: Random = Random.Default) =
    with(values) {
        ints(indices, random)
            .map { get(it) }
    }

fun Generator.Companion.chars(range: ClosedRange<Char>, random: Random = Random.Default) =
    ints(range.start.toInt()..range.endInclusive.toInt(), random)
        .map { it.toChar() }

fun Generator.Companion.ascii(random: Random = Random.Default) = chars(' '..'~', random)

fun Generator.Companion.asciiUppercase(random: Random = Random.Default) =
    chars('A'..'Z', random)

fun Generator.Companion.asciiAlphabetic(random: Random = Random.Default) =
    asciiUppercase(random)
        .map {
            when (random.nextBoolean()) {
                true -> it.toLowerCase()
                false -> it
            }
        }

fun Generator.Companion.digits(random: Random = Random.Default) = chars('0'..'9', random)

fun Generator.Companion.alphaNumeric(random: Random = Random.Default) =
    ints(0 until 62, random)
        .map {
            when (it) {
                in 0..9 -> '0' + it
                in 10 until 36 -> 'a' + it - 10
                else -> 'A' + it - 36
            }
        }

// TODO: Should really support all Unicode not just the BMP
fun Generator.Companion.strings(
    length: ClosedRange<Int> = 10..20,
    random: Random = Random.Default,
    codePoints: (Random) -> Sequence<Char> = ::ascii
) = ints(length, random)
    .map { codePoints(random).take(it) }
    .map { it.joinToString("") }

fun <T> Generator.Companion.lists(
    content: (Random) -> Sequence<T>,
    length: ClosedRange<Int> = 1..3,
    random: Random = Random
) = ints(length, random)
    .map { content(random).take(it).toList() }
