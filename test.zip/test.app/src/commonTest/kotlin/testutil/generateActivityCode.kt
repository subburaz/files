package com.genesys.purecloud.wfmshared.testutil

import com.genesys.purecloud.wfmshared.data.adapters.toCategory
import com.genesys.purecloud.wfmshared.data.adapters.wfmVersionedEntityMetadata
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCodeListing

fun generateActivityCode(
    id: String = "id",
    name: String = "name",
    isActive: Boolean = true,
    isDefault: Boolean = true,
    category: ActivityCode.Category = ActivityCode.Category.UNAVAILABLE,
    lengthInMinutes: Int = 1,
    countsAsPaidTime: Boolean = true,
    countsAsWorkTime: Boolean = true,
    agentTimeOffSelectable: Boolean = true
): ActivityCode {
    return ActivityCode(
        id = id,
        name = name,
        isActive = isActive,
        isDefault = isDefault,
        category = category,
        lengthInMinutes = lengthInMinutes,
        countsAsPaidTime = countsAsPaidTime,
        countsAsWorkTime = countsAsWorkTime,
        agentTimeOffSelectable = agentTimeOffSelectable
    )
}

fun generateActivityCodeMap(vararg activityCodes: ActivityCode): Map<String, ActivityCode> {
    return activityCodes.associateBy({ it.id }, { it })
}

fun generateActivityCodeResponse(vararg activityCodes: ActivityCode): BusinessUnitActivityCodeListing {
    return BusinessUnitActivityCodeListing(
        entities = activityCodes.map {
            BusinessUnitActivityCode(
                id = it.id,
                name = it.name,
                active = it.isActive,
                defaultCode = it.isDefault,
                category = it.category.toCategory,
                lengthInMinutes = it.lengthInMinutes,
                countsAsPaidTime = it.countsAsPaidTime,
                countsAsWorkTime = it.countsAsWorkTime,
                metadata = Generator.wfmVersionedEntityMetadata().first(),
                selfUri = "",
                agentTimeOffSelectable = it.agentTimeOffSelectable
            )
        }
    )
}
