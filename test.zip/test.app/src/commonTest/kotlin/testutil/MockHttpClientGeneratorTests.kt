package com.genesys.purecloud.wfmshared.testutil

import io.ktor.client.request.get
import io.ktor.client.request.url
import kotlin.test.Test
import kotlin.test.assertEquals

class MockHttpClientGeneratorTests {
    @Test
    fun testGenerateMockHttpClient() {
        val mockUrl = "http://test.com/test"
        val mockResponse = "Test"
        val client = generateMockHttpClient(mapOf(Pair(mockUrl, mockResponse)))

        val response: String? = runBlockingTest<String> {
            client.get {
                url(mockUrl)
            }
        }

        assertEquals(mockResponse, response)
    }
}
