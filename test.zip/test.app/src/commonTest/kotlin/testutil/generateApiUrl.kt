package com.genesys.purecloud.wfmshared.testutil

import kotlin.random.Random

fun generateApiUrl() = "http://test${Random.nextInt()}.com"
