package com.genesys.purecloud.wfmshared.testutil

import com.genesys.purecloud.wfmshared.purecloudapi.entities.User

fun generateUser(name: String = "John Doe", id: String = "id", selfUri: String = "selfUri"): User {
    return User(
        id = id,
        name = name,
        selfUri = selfUri
    )
}
