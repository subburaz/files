package com.genesys.purecloud.wfmshared

import kotlin.test.Test
import kotlin.test.assertEquals

class WFMSharedTests {
    @Test
    fun testInitializeApi() {
        val apiUrl = "apiUrl"
        val accessToken = "accessToken"
        val userAgent = "userAgent"

        initializeApi(
            apiUrl = apiUrl,
            accessToken = accessToken,
            userAgent = userAgent
        )

        assertEquals(apiUrl, serviceLocator.apiData?.apiUrl)
        assertEquals(accessToken, serviceLocator.apiData?.accessToken)
        assertEquals(userAgent, serviceLocator.apiData?.userAgent)
    }

    @Test
    fun testSetLocale() {
        val languageCode = "languageCode"
        val scriptCode = "scriptCode"
        val regionCode = "regionCode"
        val variantCode = "variantCode"

        setLocale(
            languageCode = languageCode,
            scriptCode = scriptCode,
            regionCode = regionCode,
            variantCode = variantCode
        )

        assertEquals(languageCode, serviceLocator.localeData.languageCode)
        assertEquals(scriptCode, serviceLocator.localeData.scriptCode)
        assertEquals(regionCode, serviceLocator.localeData.regionCode)
        assertEquals(variantCode, serviceLocator.localeData.variantCode)
    }
}
