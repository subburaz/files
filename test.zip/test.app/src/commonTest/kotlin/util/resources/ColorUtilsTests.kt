package com.genesys.purecloud.wfmshared.util.resources

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFails

class ColorUtilsTests {
    @Test
    fun `getSourceType should recognize #RGB input`() {
        val actual = getSourceType("#012")
        assertEquals(ColorDescSourceType.RGB, actual)
    }

    @Test
    fun `getSourceType should recognize #RRGGB input`() {
        val actual = getSourceType("#012345")
        assertEquals(ColorDescSourceType.RRGGBB, actual)
    }

    @Test
    fun `getSourceType should recognize #AARRGGBB input`() {
        val actual = getSourceType("#01234567")
        assertEquals(ColorDescSourceType.AARRGGBB, actual)
    }

    @Test
    fun `getSourceType should recognize invalid input with no hash`() {
        val actual = getSourceType("FF00FF")
        assertEquals(ColorDescSourceType.INVALID, actual)
    }

    @Test
    fun `getSourceType should recognize invalid input with too few characters`() {
        val actual = getSourceType("#01")
        assertEquals(ColorDescSourceType.INVALID, actual)
    }

    @Test
    fun `getSourceType should recognize invalid input with too many characters`() {
        val actual = getSourceType("#012345678")
        assertEquals(ColorDescSourceType.INVALID, actual)
    }

    @Test
    fun `getSourceType should recognize invalid input with invalid characters`() {
        val actual = getSourceType("#HIJ")
        assertEquals(ColorDescSourceType.INVALID, actual)
    }

    @Test
    fun `formatToAARRGGBB from RGB`() {
        val actual = formatToAARRGGBB("#012")
        assertEquals("#FF001122", actual)
    }

    @Test
    fun `formatToAARRGGBB from RRGGBB`() {
        val actual = formatToAARRGGBB("#334455")
        assertEquals("#FF334455", actual)
    }

    @Test
    fun `formatToAARRGGBB from ARRGGBB`() {
        val actual = formatToAARRGGBB("#66778899")
        assertEquals("#66778899", actual)
    }

    @Test
    fun `formatToAARRGGBB throws on invalid input`() {
        assertFails {
            formatToAARRGGBB("")
        }
    }
}
