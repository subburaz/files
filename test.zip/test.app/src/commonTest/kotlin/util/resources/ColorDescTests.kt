package com.genesys.purecloud.wfmshared.util.resources

import kotlin.test.Test
import kotlin.test.assertFails

class ColorDescTests {
    @Test
    fun `should throw Exception on invalid input with too few characters`() {
        assertFails {
            ColorDesc("#00")
        }
    }

    @Test
    fun `should throw Exception on invalid input with too many characters`() {
        assertFails {
            ColorDesc("#000000000")
        }
    }

    @Test
    fun `should throw Exception on invalid input with no hash`() {
        assertFails {
            ColorDesc("0000000")
        }
    }

    @Test
    fun `should throw Exception on invalid input with invalid characters`() {
        assertFails {
            ColorDesc("#ABCDEFGH")
        }
    }
}
