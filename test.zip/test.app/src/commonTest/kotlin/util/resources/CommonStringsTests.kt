package com.genesys.purecloud.wfmshared.util.resources

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.testutil.populateCommonTestStrings
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFails
import org.kodein.di.erased.instance

class CommonStringsTests {
    @Test
    fun testCommonStringsUninitializedGetStringThrowsException() {
        assertFails {
            val commonStrings = CommonStrings()
            commonStrings.getString(MR.strings.date_format_day_short)
        }
    }

    @Test
    fun testCommonStringsInitializedGetStringWorks() {
        populateCommonTestStrings()
        val commonStrings: CommonStrings by kodein.instance()
        assertEquals("EEE", commonStrings.getString(MR.strings.date_format_day_short))
    }

    @Test
    fun `test CommonStrings initialized getString throws exception on non common resource`() {
        assertFails {
            val commonStrings: CommonStrings by kodein.instance()
            commonStrings.getString(MR.strings.activity_break)
        }
    }
}
