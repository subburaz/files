package com.genesys.purecloud.wfmshared.util

import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit.StartDayOfWeek
import com.genesys.purecloud.wfmshared.testutil.populateCommonTestStrings
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class DateTimeTests {
    private val dtJan1 = DateTime.parse("2000-01-01")
    private val dtJan1Duplicate = DateTime.parse("2000-01-01")
    private val dtJan26 = DateTime.parse("2000-01-26")
    private val dtJan26FiveAM = DateTime.parse("2000-01-26T05:00:00Z")
    private val dtJan30 = DateTime.parse("2000-01-30")
    private val dtJan30FiveAM = DateTime.parse("2000-01-30T05:00:00Z")
    private val dtFeb1 = DateTime.parse("2000-02-01")
    private val dtFeb1Noon = DateTime.parse("2000-02-01T12:00:00Z")
    private val dtFeb1NoonThirty = DateTime.parse("2000-02-01T12:30:00Z")
    private val dtFeb2FiveAM = DateTime.parse("2000-02-02T05:00:00Z")
    private val dtFeb2Noon = DateTime.parse("2000-02-02T12:00:00Z")
    private val dtFeb2NoonAndOneSecond = DateTime.parse("2000-02-02T12:00:01Z")
    private val dtFeb3 = DateTime.parse("2000-02-03")
    private val dtJun29FourAM = DateTime.parse("2000-06-29T04:00:00Z")
    private val dtJul2FourAM = DateTime.parse("2000-07-02T04:00:00Z")
    private val dtJul3 = DateTime.parse("2000-07-03")

    private fun formatDebugMessage(d1: DateTime, d2: DateTime): String {
        return "${d1.formatDateWithSlashes(DEFAULT_TIME_ZONE_NAME)} ${d1.formatWeekdayShort(DEFAULT_TIME_ZONE_NAME)} ${d1.formatTime(DEFAULT_TIME_ZONE_NAME)} - ${d2.formatDateWithSlashes(DEFAULT_TIME_ZONE_NAME)} ${d2.formatWeekdayShort(DEFAULT_TIME_ZONE_NAME)} ${d2.formatTime(DEFAULT_TIME_ZONE_NAME)}"
    }

    @BeforeTest
    fun setup() {
        populateCommonTestStrings()
    }

    @Test
    fun testPlusSeconds() {
        val addResult = dtFeb2Noon.plusSeconds(1)
        assertEquals(true, addResult == dtFeb2NoonAndOneSecond, formatDebugMessage(addResult, dtFeb2NoonAndOneSecond))
    }

    @Test
    fun testMinusSeconds() {
        val minusResult = dtFeb2NoonAndOneSecond.minusSeconds(1)
        assertEquals(true, minusResult == dtFeb2Noon, formatDebugMessage(minusResult, dtFeb2Noon))
    }

    @Test
    fun testPlusMinutes() {
        val addResult = dtFeb1Noon.plusMinutes(30)
        assertEquals(true, addResult == dtFeb1NoonThirty, formatDebugMessage(addResult, dtFeb1NoonThirty))
    }

    @Test
    fun testMinusMinutes() {
        val minusResult = dtFeb1NoonThirty.minusMinutes(30)
        assertEquals(true, minusResult == dtFeb1Noon, formatDebugMessage(minusResult, dtFeb1Noon))
    }

    @Test
    fun testPlusDays() {
        val addResult = dtFeb1Noon.plusDays(1)
        assertEquals(true, addResult == dtFeb2Noon, formatDebugMessage(addResult, dtFeb2Noon))
    }

    @Test
    fun testMinusDays() {
        val minusResult = dtFeb2Noon.minusDays(1)
        assertEquals(true, minusResult == dtFeb1Noon, formatDebugMessage(minusResult, dtFeb1Noon))
    }

    @Test
    fun testStartOfDayUTC() {
        val sod = dtFeb1Noon.startOfDay()
        assertEquals(true, sod == dtFeb1, formatDebugMessage(sod, dtFeb1))
    }

    @Test
    fun testStartOfDayTz() {
        val sod = dtFeb3.startOfDay("America/New_York")
        assertEquals(true, sod == dtFeb2FiveAM, formatDebugMessage(sod, dtFeb2FiveAM))
    }

    @Test
    fun testStartOfDayTzInDST() {
        val sod = dtJul3.startOfDay("America/New_York")
        assertEquals(true, sod == dtJul2FourAM, formatDebugMessage(sod, dtJul2FourAM))
    }

    @Test
    fun testStartOfWeekUTC() {
        val sow = dtFeb1Noon.startOfWeek(DEFAULT_TIME_ZONE_NAME, StartDayOfWeek.SUNDAY)
        assertEquals(true, sow == dtJan30, formatDebugMessage(sow, dtJan30))
    }

    @Test
    fun testStartOfWeekUTCStartOfWeekAfterDate() {
        val sow = dtFeb1Noon.startOfWeek(DEFAULT_TIME_ZONE_NAME, StartDayOfWeek.WEDNESDAY)
        assertEquals(true, sow == dtJan26, formatDebugMessage(sow, dtJan26))
    }

    @Test
    fun testStartOfWeekTz() {
        val sow = dtFeb1Noon.startOfWeek("America/New_York", StartDayOfWeek.SUNDAY)
        assertEquals(true, sow == dtJan30FiveAM, formatDebugMessage(sow, dtJan30FiveAM))
    }

    @Test
    fun testStartOfWeekTzStartOfWeekAfterDate() {
        val sow = dtFeb1Noon.startOfWeek("America/New_York", StartDayOfWeek.WEDNESDAY)
        assertEquals(true, sow == dtJan26FiveAM, formatDebugMessage(sow, dtJan26FiveAM))
    }

    @Test
    fun testStartOfWeekTzDST() {
        val sow = dtJul3.startOfWeek("America/New_York", StartDayOfWeek.SUNDAY)
        assertEquals(true, sow == dtJul2FourAM, formatDebugMessage(sow, dtJul2FourAM))
    }

    @Test
    fun testStartOfWeekTzDSTStartOfWeekAfterDate() {
        val sow = dtJul3.startOfWeek("America/New_York", StartDayOfWeek.THURSDAY)
        assertEquals(true, sow == dtJun29FourAM, formatDebugMessage(sow, dtJun29FourAM))
    }

    @Test
    fun testEquals() {
        assertEquals(false, dtJan1 == dtFeb1)
        assertEquals(true, dtJan1 == dtJan1)
        assertEquals(true, dtJan1 == dtJan1Duplicate)
    }

    @Test
    fun testHashCode() {
        assertEquals(true, dtJan1.hashCode() == dtJan1.hashCode())
        assertEquals(true, dtJan1.hashCode() == dtJan1Duplicate.hashCode())
        assertEquals(false, dtJan1.hashCode() == dtFeb1.hashCode())
    }

    @Test
    fun testCompareTo() {
        assertEquals(false, dtJan1 > dtJan1Duplicate)
        assertEquals(false, dtJan1 > dtFeb1)
        assertEquals(true, dtFeb1 > dtJan1)
        assertEquals(false, dtJan1 < dtJan1Duplicate)
        assertEquals(false, dtFeb1 < dtJan1)
        assertEquals(true, dtJan1 < dtFeb1)
    }

    @Test
    fun testCrossesDst() {
        val jan = DateTime.parse("2000-01-01")
        val feb = DateTime.parse("2000-02-01")
        val jul = DateTime.parse("2000-07-01")

        assertEquals(false, jan.crossesDst(feb, "America/New_York"))
        assertEquals(true, jan.crossesDst(jul, "America/New_York"))
    }

    @Test
    fun testFormatDateWithSlashes() {
        assertEquals("02/01/2000", dtFeb1NoonThirty.formatDateWithSlashes(DEFAULT_TIME_ZONE_NAME))
    }

    @Test
    fun testFormatWeekdayShort() {
        assertEquals("Tue", dtFeb1NoonThirty.formatWeekdayShort(DEFAULT_TIME_ZONE_NAME))
    }

    @Test
    fun testFormatTime() {
        assertEquals("12:30 PM", dtFeb1NoonThirty.formatTime(DEFAULT_TIME_ZONE_NAME))
    }

    @Test
    fun testFormatTimeEdt() {
        assertEquals("7:30 AM", dtFeb1NoonThirty.formatTime("America/New_York"))
    }

    @Test
    fun testParseDate() {
        val testDate = DateTime.parse("2019-05-30")
        assertEquals("05/30/2019", testDate.formatDateWithSlashes(DEFAULT_TIME_ZONE_NAME))
        assertEquals("12:00 AM", testDate.formatTime(DEFAULT_TIME_ZONE_NAME))
    }

    @Test
    fun testParseDateTime() {
        val testDateTime = DateTime.parse("2019-05-30T09:29:55Z")
        assertEquals("05/30/2019", testDateTime.formatDateWithSlashes(DEFAULT_TIME_ZONE_NAME))
        assertEquals("9:29 AM", testDateTime.formatTime(DEFAULT_TIME_ZONE_NAME))
    }

    @Test
    fun testParseDateTimeFS() {
        val testDateTimeFS = DateTime.parse("2019-05-30T09:29:55.123Z")
        assertEquals("05/30/2019", testDateTimeFS.formatDateWithSlashes(DEFAULT_TIME_ZONE_NAME))
        assertEquals("9:29 AM", testDateTimeFS.formatTime(DEFAULT_TIME_ZONE_NAME))
    }

    @Test
    fun testParseDateTimeInvalid() {
        assertFailsWith<IllegalArgumentException> { DateTime.parse("") }
    }

    @Test
    fun testIsBefore() {
        assertEquals(true, dtJan1.isBefore(dtJan26))
        assertEquals(false, dtFeb1.isBefore(dtJan26))
    }

    @Test
    fun testIsAfter() {
        assertEquals(false, dtJan1.isAfter(dtJan26))
        assertEquals(true, dtFeb1.isAfter(dtJan26))
    }
}
