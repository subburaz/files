package com.genesys.purecloud.wfmshared.util

import kotlin.test.Test
import kotlin.test.assertEquals

class ServiceLocatorTests {
    private val serviceLocator = ServiceLocator()

    init {
        serviceLocator.initializeApiData(
            apiUrl = "apiUrl",
            accessToken = "accessToken",
            userAgent = "userAgent"
        )
        serviceLocator.initializeLocaleData(
            languageCode = "languageCode",
            scriptCode = "scriptCode",
            regionCode = "regionCode",
            variantCode = "variantCode"
        )
    }

    @Test
    fun testServiceLocatorHasJsonSerializer() {
        assertEquals("Json", serviceLocator.jsonSerializer::class.simpleName)
    }

    @Test
    fun testServiceLocatorHasApiData() {
        assertEquals("PureCloudApiData", serviceLocator.apiData!!::class.simpleName)
    }

    @Test
    fun testServiceLocatorHasLocaleData() {
        assertEquals("LocaleData", serviceLocator.localeData::class.simpleName)
    }

    @Test
    fun testServiceLocatorHasHttpClient() {
        assertEquals("HttpClient", serviceLocator.httpClient::class.simpleName)
    }

    @Test
    fun testServiceLocatorResetApiData() {
        serviceLocator.resetApiData()
        assertEquals(null, serviceLocator.apiData)
    }

    @Test
    fun testServiceLocatorReset() {
        serviceLocator.reset()
        assertEquals(null, serviceLocator.apiData)
    }
}
