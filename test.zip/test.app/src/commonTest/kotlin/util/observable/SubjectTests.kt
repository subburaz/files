package com.genesys.purecloud.wfmshared.util.observable

import com.genesys.purecloud.wfmshared.testutil.IgnoreIos
import com.genesys.purecloud.wfmshared.testutil.getTestCoroutineUIScope
import com.genesys.purecloud.wfmshared.testutil.runBlockingTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals
import kotlinx.coroutines.ExperimentalCoroutinesApi

@ExperimentalCoroutinesApi
class SubjectTests {
    @Test
    fun testObservableInitialization() {
        val initialObsValue = "hello"
        val obs: Subject<String> = PublishSubject(initialObsValue, getTestCoroutineUIScope())

        assertEquals(initialObsValue, obs.value)
    }

    @Test
    @IgnoreIos
    fun testPostValue() {
        val obs: PublishSubject<String> = PublishSubject("hello", getTestCoroutineUIScope())

        var localValue = ""

        val onChange: Observer<String> = {
            localValue = it
        }

        runBlockingTest {
            obs.observe(onChange).join()
        }

        assertEquals("hello", localValue)

        runBlockingTest {
            obs.postValue("world").join()
        }

        assertEquals("world", localValue)
    }

    @Test
    @IgnoreIos
    fun testSingleObserver() {
        val initialValue = "hello"
        val value2 = "world"
        val value3 = "hello world"

        var localValue = ""

        val mObs: PublishSubject<String> = PublishSubject(initialValue, getTestCoroutineUIScope())
        val obs: Subject<String> = mObs

        val onChange: Observer<String> = {
            localValue = it
        }

        runBlockingTest {
            obs.observe(onChange).join()
        }

        assertEquals(initialValue, localValue)

        runBlockingTest {
            mObs.postValue(value2).join()
        }

        assertEquals(value2, localValue)

        runBlockingTest {
            obs.removeObserver(onChange).join()
        }

        runBlockingTest {
            mObs.postValue(value3).join()
        }

        assertEquals(value2, localValue)
    }

    @Test
    @IgnoreIos
    fun testMultipleObservers() {
        val initialObsValue = "hello"
        val finalValueA = "world"
        val finalValueB = "hello world"
        val finalValueC = "goodbye"

        var localValueA = ""
        var localValueB = ""
        var localValueC = ""

        val onChangeA: Observer<String> = {
            localValueA = it
        }
        val onChangeB: Observer<String> = {
            localValueB = it
        }
        val onChangeC: Observer<String> = {
            localValueC = it
        }

        val mObs: PublishSubject<String> = PublishSubject(initialObsValue, getTestCoroutineUIScope())
        val obs: Subject<String> = mObs

        runBlockingTest {
            obs.observe(onChangeA).join()
            obs.observe(onChangeB).join()
            obs.observe(onChangeC).join()
        }

        assertEquals(initialObsValue, localValueA)
        assertEquals(initialObsValue, localValueB)
        assertEquals(initialObsValue, localValueC)

        runBlockingTest {
            mObs.postValue(finalValueA).join()
        }

        assertEquals(finalValueA, localValueA)
        assertEquals(finalValueA, localValueB)
        assertEquals(finalValueA, localValueC)

        runBlockingTest {
            obs.removeObserver(onChangeA).join()
        }

        runBlockingTest {
            mObs.postValue(finalValueB).join()
        }

        assertEquals(finalValueA, localValueA)
        assertEquals(finalValueB, localValueB)
        assertEquals(finalValueB, localValueC)

        runBlockingTest {
            obs.removeObserver(onChangeB).join()
        }

        runBlockingTest {
            mObs.postValue(finalValueC).join()
        }

        assertEquals(finalValueA, localValueA)
        assertEquals(finalValueB, localValueB)
        assertEquals(finalValueC, localValueC)

        runBlockingTest {
            obs.removeObserver(onChangeC).join()
        }

        runBlockingTest {
            mObs.postValue("gibberish").join()
        }

        assertEquals(finalValueA, localValueA)
        assertEquals(finalValueB, localValueB)
        assertEquals(finalValueC, localValueC)
    }

    @Test
    @IgnoreIos
    fun shouldWorkWithConcurrentModificationOfListOfObserversWithinAnObserver() {
        val initialObsValue = "hello"
        val mObs: PublishSubject<String> = PublishSubject(initialObsValue, getTestCoroutineUIScope())
        val obs: Subject<String> = mObs

        var localValueA = ""
        var localValueB = ""
        var localValueC = ""

        var removeObservers = false

        val onChangeA: Observer<String> = {
            localValueA = it
        }
        val onChangeC: Observer<String> = {
            localValueC = it
        }
        val onChangeB: Observer<String> = {
            localValueB = it
            if (removeObservers) {
                obs.removeObserver(onChangeA)
                obs.removeObserver(onChangeC)
            }
        }

        runBlockingTest {
            obs.observe(onChangeA).join()
            obs.observe(onChangeB).join()
            obs.observe(onChangeC).join()
        }

        val finalValue1 = "world"
        val finalValueB = "goodbye"
        removeObservers = true

        runBlockingTest {
            mObs.postValue(finalValue1).join()
        }

        assertEquals(finalValue1, localValueB)

        runBlockingTest {
            mObs.postValue(finalValueB).join()
        }

        // A and C should not get called this time
        assertNotEquals(finalValueB, localValueA)
        assertEquals(finalValueB, localValueB)
        assertNotEquals(finalValueB, localValueC)
    }
}
