package com.genesys.purecloud.wfmshared.util

import kotlin.test.Test
import kotlin.test.assertEquals

class LocaleDataTests {
    @Test
    fun testInitialState() {
        val localeData = LocaleData()

        assertEquals(DEFAULT_LANGUAGE_CODE, localeData.languageCode)
        assertEquals(DEFAULT_SCRIPT_CODE, localeData.scriptCode)
        assertEquals(DEFAULT_REGION_CODE, localeData.regionCode)
        assertEquals(DEFAULT_VARIANT_CODE, localeData.variantCode)
    }

    @Test
    fun testInitialize() {
        val languageCode = "languageCode"
        val scriptCode = "scriptCode"
        val regionCode = "regionCode"
        val variantCode = "variantCode"

        val localeData = LocaleData(languageCode, scriptCode, regionCode, variantCode)

        assertEquals(languageCode, localeData.languageCode)
        assertEquals(scriptCode, localeData.scriptCode)
        assertEquals(regionCode, localeData.regionCode)
        assertEquals(variantCode, localeData.variantCode)
    }
}
