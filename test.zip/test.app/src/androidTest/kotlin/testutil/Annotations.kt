package com.genesys.purecloud.wfmshared.testutil

actual typealias IgnoreAndroid = org.junit.Ignore

@Target(AnnotationTarget.CLASS, AnnotationTarget.FUNCTION)
actual annotation class IgnoreIos
