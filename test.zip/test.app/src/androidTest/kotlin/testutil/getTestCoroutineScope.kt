package com.genesys.purecloud.wfmshared.testutil

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestCoroutineScope

@ExperimentalCoroutinesApi
actual fun getTestCoroutineBGScope(): CoroutineScope {
    return TestCoroutineScope()
}

@ExperimentalCoroutinesApi
actual fun getTestCoroutineUIScope(): CoroutineScope {
    return TestCoroutineScope()
}
