package com.genesys.purecloud.wfmshared.testutil

import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.runBlocking

actual fun <T> runBlockingTest(context: CoroutineContext, block: suspend CoroutineScope.() -> T): T {
    return runBlocking(context, block)
}
