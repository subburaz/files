package com.genesys.purecloud.wfmshared.testutil

import java.util.TimeZone

actual fun overrideTimeZone(timeZoneName: String?) {
    TimeZone.setDefault(timeZoneName
        ?.let(TimeZone::getTimeZone))
}
