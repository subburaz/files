package com.genesys.purecloud.wfmshared

// This file is intentionally left blank other than the package declaration
// This is so that AndroidStudio recognizes the base package name for this directory
