package com.genesys.purecloud.wfmshared.viewmodels

import com.genesys.purecloud.wfmshared.util.observable.Subject
import dev.icerock.moko.resources.desc.StringDesc
import kotlinx.coroutines.Job

interface ITimeOffRequestEditViewModel : ITimeOffRequestDetailsViewModel {
    val notesMaxLength: Int
    var notes: String?

    val canUpdate: Subject<Boolean>
    val editSucceeded: Subject<Boolean?>
    val userMessage: Subject<StringDesc?>

    fun cancelTimeOffRequest(): Job?
    fun updateTimeOffRequest(): Job?
}
