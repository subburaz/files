package com.genesys.purecloud.wfmshared.viewmodels

import com.genesys.purecloud.wfmshared.components.timeoffrequest.details.TimeOffRequestDetailsModel
import com.genesys.purecloud.wfmshared.util.observable.Subject
import kotlinx.coroutines.Job

interface ITimeOffRequestDetailsViewModel {
    val timeOffRequestDetailsModel: Subject<TimeOffRequestDetailsModel>
    val isLoading: Subject<Boolean>
    val isInitialized: Subject<Boolean>
    fun fetchTimeOffRequest(torId: String): Job
    fun reset()
}
