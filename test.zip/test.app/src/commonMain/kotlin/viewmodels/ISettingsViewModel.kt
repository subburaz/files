package com.genesys.purecloud.wfmshared.viewmodels

import com.genesys.purecloud.wfmshared.components.settings.UserSettingsModel
import com.genesys.purecloud.wfmshared.util.ThirdPartyDependency
import com.genesys.purecloud.wfmshared.util.observable.Subject
import kotlinx.coroutines.Job

interface ISettingsViewModel {
    val userSettingsModel: Subject<UserSettingsModel>
    val dependencyInformation: List<ThirdPartyDependency>
    fun getUserSettingsInfo(): Job
}
