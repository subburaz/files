package com.genesys.purecloud.wfmshared.viewmodels

import com.genesys.purecloud.wfmshared.components.timeoffrequest.list.TimeOffRequestListCellData
import com.genesys.purecloud.wfmshared.util.observable.Subject
import kotlinx.coroutines.Job

interface ITimeOffRequestListViewModel {
    /**
     * Returns an Observable that contains all of the time off requests.
     */
    fun getAllTimeOffRequests(): Subject<List<TimeOffRequestListCellData>>

    /**
     * Returns an Observable that contains all of the pending time off requests.
     */
    fun getPendingTimeOffRequests(): Subject<List<TimeOffRequestListCellData>>

    /**
     * Returns an Observable that contains all time off requests that occur this week.
     */
    fun getThisWeeksTimeOffRequests(): Subject<List<TimeOffRequestListCellData>>

    /**
     * Returns an Observable that contains all time off requests that happen in the future.
     */
    fun getUpcomingTimeOffRequests(): Subject<List<TimeOffRequestListCellData>>

    /**
     * Requests the latest time off requests from the server, updates the Observables on completion.
     */
    fun updateTimeOffRequests(): Job
}
