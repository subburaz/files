package com.genesys.purecloud.wfmshared.viewmodels

import com.genesys.purecloud.wfmshared.components.timeoffrequest.create.TimeOffRequestCreateViewState
import com.genesys.purecloud.wfmshared.util.TimeDuration
import com.genesys.purecloud.wfmshared.util.observable.Observable
import com.genesys.purecloud.wfmshared.util.observable.Subject
import dev.icerock.moko.resources.desc.StringDesc
import kotlinx.coroutines.Job

interface ITimeOffRequestCreateViewModel {
    // New Implementation
    data class SubmitResult(
        val successful: Boolean,
        val userMessage: StringDesc
    )

    val submitResult: Observable<SubmitResult>
    val viewState: Subject<TimeOffRequestCreateViewState>

    var selectedActivityCodeId: String
    var selectedStartDate: String
    var selectedStartTimeOffsetInMinutes: Int
    var selectedEndDate: String
    var selectedDuration: TimeDuration
    var selectedIsFullDay: Boolean
    var selectedNotes: String
    val notesMaxLength: Int

    fun initialize(): Job
    fun submitTimeOffRequest(): Job

    fun toggleStartDateTimeVisibility()
    fun toggleEndDateVisibility()
    fun toggleDurationVisibility()
}
