package com.genesys.purecloud.wfmshared.purecloudapi.extensions

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.util.DateTime
import com.genesys.purecloud.wfmshared.util.resources.ColorDesc
import com.genesys.purecloud.wfmshared.util.resources.CommonColors
import dev.icerock.moko.resources.desc.StringDesc
import dev.icerock.moko.resources.desc.desc

val TimeOffRequestResponse.Status.text: StringDesc
    get() = when (this) {
        TimeOffRequestResponse.Status.PENDING -> MR.strings.status_pending.desc()
        TimeOffRequestResponse.Status.APPROVED -> MR.strings.status_approved.desc()
        TimeOffRequestResponse.Status.CANCELED -> MR.strings.status_canceled.desc()
        TimeOffRequestResponse.Status.DENIED -> MR.strings.status_denied.desc()
    }

val TimeOffRequestResponse.Status.color: ColorDesc
    get() = when (this) {
        TimeOffRequestResponse.Status.PENDING -> CommonColors.TOR_PENDING.description
        TimeOffRequestResponse.Status.APPROVED -> CommonColors.TOR_APPROVED.description
        TimeOffRequestResponse.Status.CANCELED -> CommonColors.TOR_CANCELED.description
        TimeOffRequestResponse.Status.DENIED -> CommonColors.TOR_DENIED.description
    }

val TimeOffRequestResponse.dates: List<DateTime>
    get() = when {
        isFullDayRequest -> fullDayManagementUnitDates
        else -> partialDayStartDateTimes
    }
        .sorted()
        .map { DateTime.parse(it) }
