package com.genesys.purecloud.wfmshared.purecloudapi

import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.util.Logger
import io.ktor.client.features.ResponseException
import io.ktor.client.request.get
import io.ktor.client.request.patch
import io.ktor.client.request.post
import io.ktor.client.request.url
import io.ktor.content.TextContent
import io.ktor.http.ContentType

const val LOG_TAG_GET = "executePureCloudGetRequest"
const val LOG_TAG_PATCH = "executePureCloudPatchRequest"
const val LOG_TAG_POST = "executePureCloudPostRequest"

suspend fun executePureCloudGetRequest(path: String): String? {
    val apiData = serviceLocator.apiData ?: run {
        Logger.logError(LOG_TAG_GET, "Api Data is not initialized")
        return null
    }

    return try {
        serviceLocator.httpClient.get {
            url(apiData.buildFullPath(path))
        }
    } catch (cause: Throwable) {
        Logger.logError(LOG_TAG_GET, "executeGetRequest - get failed", cause)
        null
    }
}

suspend fun executePureCloudPatchRequest(path: String, body: String): String? {
    val apiData = serviceLocator.apiData ?: run {
        Logger.logError(LOG_TAG_PATCH, "Api Data is not initialized")
        return null
    }
    return try {
        serviceLocator.httpClient.patch {
            url(apiData.buildFullPath(path))
            this.body = TextContent(body, ContentType.Application.Json)
        }
    } catch (cause: Throwable) {
        Logger.logError(LOG_TAG_PATCH, "executePatchRequest - Patch failed", cause)
        null
    }
}

suspend fun executePureCloudPostRequest(path: String, body: String): String? {
    val apiData = serviceLocator.apiData ?: run {
        Logger.logError(LOG_TAG_POST, "Api Data is not initialized")
        return null
    }
    return try {
        serviceLocator.httpClient.post {
            this.url(apiData.buildFullPath(path))
            println(body)
            this.body = TextContent(body, ContentType.Application.Json)
        }
    } catch (cause: ResponseException) {
        Logger.logError(LOG_TAG_POST, "executePostRequest - Post failed")
        println(cause.message)
        throw cause
    } catch (cause: Throwable) {
        Logger.logError(LOG_TAG_POST, "executePostRequest - Post failed", cause)
        null
    }
}
