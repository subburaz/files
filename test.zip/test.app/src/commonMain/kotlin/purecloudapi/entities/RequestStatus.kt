package com.genesys.purecloud.wfmshared.purecloudapi.entities

enum class RequestStatus {
    PENDING, ACTIVE, SUCCESS, FAILURE
}
