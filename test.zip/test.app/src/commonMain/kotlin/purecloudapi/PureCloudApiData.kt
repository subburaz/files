package com.genesys.purecloud.wfmshared.purecloudapi

/**
 * @property apiUrl The base url of the api service.
 * @property accessToken The access token used when making requests to the PureCloud API.
 * @property userAgent The user agent to use when making requests to the PureCloud API.
 */
data class PureCloudApiData(
    val apiUrl: String,
    val accessToken: String,
    val userAgent: String
) {
    fun buildFullPath(path: String): String {
        return "$apiUrl/$path"
    }
}
