package com.genesys.purecloud.wfmshared.purecloudapi

object PureCloudApiEndpoints {
    private const val API_BASE_PATH = "api/v2"
    const val USERS_BASE_PATH = "$API_BASE_PATH/users"
    private const val WFM_BASE_PATH = "$API_BASE_PATH/workforcemanagement"
    const val GET_USERS_TORS = "$WFM_BASE_PATH/timeoffrequests"
    const val GET_USERS_MU = "$WFM_BASE_PATH/managementunits/mine?expand=settings"
    const val GET_USERS_INFO = "$USERS_BASE_PATH/me"
    const val PATCH_USER_TORS = "$WFM_BASE_PATH/timeoffrequests"
    const val POST_USERS_TORS = "$WFM_BASE_PATH/timeoffrequests"
}
