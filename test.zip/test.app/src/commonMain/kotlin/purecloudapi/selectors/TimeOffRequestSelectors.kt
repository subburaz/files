package com.genesys.purecloud.wfmshared.purecloudapi.selectors

import com.genesys.purecloud.wfmshared.components.timeoffrequest.details.TimeOffRequestDetailsModel
import com.genesys.purecloud.wfmshared.components.timeoffrequest.list.TimeOffRequestListCellData
import com.genesys.purecloud.wfmshared.components.timeoffrequest.list.TimeOffRequestListCellType
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode
import com.genesys.purecloud.wfmshared.presentation.resources.displayName
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.User
import com.genesys.purecloud.wfmshared.purecloudapi.extensions.dates
import com.genesys.purecloud.wfmshared.util.DEFAULT_TIME_ZONE_NAME
import com.genesys.purecloud.wfmshared.util.DateTime
import com.genesys.purecloud.wfmshared.util.formatDateWithSlashes
import com.genesys.purecloud.wfmshared.util.formatDuration
import com.genesys.purecloud.wfmshared.util.formatTime
import com.genesys.purecloud.wfmshared.util.formatWeekdayShort
import dev.icerock.moko.resources.desc.desc

internal object TimeOffRequestSelectors {
    fun getTimeOffRequestListCellType(
        singleDay: Boolean,
        partialDay: Boolean
    ): TimeOffRequestListCellType {
        if (singleDay && partialDay) {
            return TimeOffRequestListCellType.SINGLE_DAY_PARTIAL_TOR_LIST_ITEM
        }

        if (singleDay && !partialDay) {
            return TimeOffRequestListCellType.SINGLE_DAY_FULL_TOR_LIST_ITEM
        }

        return TimeOffRequestListCellType.MULTIPLE_DAY_TOR_LIST_ITEM
    }

    /**
     * Gets the time off request cell data for the given time off request
     *
     * Covers 4 use cases:
     *
     * 1) Single Day Full Day - Return cell with the start date as well as the start day of week
     * 2) Single Day Partial Day - Return cell with the start date as well as the start day of week and beginning and end time
     * 3) Multiple Full Day - Return cell with the start date as well as the start day of week and end date as well as the end day of week
     * 4) Multiple Partial Day - Return cell with the start date, end date, start day of week and time, end day of week and time
     */
    fun getTimeOffRequestCellData(
        timeOffRequest: TimeOffRequestResponse,
        weekStart: DateTime,
        weekEnd: DateTime,
        timeZoneName: String = DEFAULT_TIME_ZONE_NAME,
        userById: Map<String, User>
    ): TimeOffRequestListCellData {
        val dates = timeOffRequest.dates

        val hasMultipleDates = dates.size > 1
        val endDateMinutesOffset = timeOffRequest.dailyDurationMinutes.takeUnless {
            timeOffRequest.isFullDayRequest
        } ?: 0
        val start = dates.first()
        val end = dates.last().plusMinutes(endDateMinutesOffset)

        val tz = if (timeOffRequest.isFullDayRequest) DEFAULT_TIME_ZONE_NAME else timeZoneName

        // TODO remove these 4 variables and the proceeding if statement when mockup ui is implemented
        val startDateDisplay = start.formatDateWithSlashes(tz)
        var startDayTimeDisplay = start.formatWeekdayShort(tz)
        val endDateDisplay = if (hasMultipleDates) end.formatDateWithSlashes(tz) else ""
        var endDayTimeDisplay = if (hasMultipleDates) end.formatWeekdayShort(tz) else ""

        if (!timeOffRequest.isFullDayRequest) {
            startDayTimeDisplay += " ${start.formatTime(tz)}"

            if (hasMultipleDates) {
                endDayTimeDisplay += " "
                endDayTimeDisplay += end.formatTime(tz)
            } else {
                startDayTimeDisplay += " - ${end.formatTime(tz)}"
            }
        }

        val startDate = start.formatDateWithSlashes(tz)
        val startDay = start.formatWeekdayShort(tz)
        val startTime = if (!timeOffRequest.isFullDayRequest) start.formatTime(tz) else ""
        val endDate = if (hasMultipleDates || !timeOffRequest.isFullDayRequest) end.formatDateWithSlashes(tz) else ""
        val endDay = if (hasMultipleDates || !timeOffRequest.isFullDayRequest) end.formatWeekdayShort(tz) else ""
        val endTime = if (!timeOffRequest.isFullDayRequest) end.formatTime(tz) else ""

        val isApproved = timeOffRequest.status == TimeOffRequestResponse.Status.APPROVED

        var isThisWeek = dates.any {
            it in weekStart..weekEnd
        }

        if (!isThisWeek && timeOffRequest.isFullDayRequest) {
            isThisWeek = start in weekStart..weekEnd || end in weekStart..weekEnd
        }

        val isUpcoming = dates.any {
            it > weekEnd
        }

        val singleDayRequest = dates.size == 1
        val partialDayRequest = !timeOffRequest.isFullDayRequest

        val username = userById[timeOffRequest.submittedBy.id]?.name

        return TimeOffRequestListCellData(
            type = getTimeOffRequestListCellType(singleDayRequest, partialDayRequest),
            id = timeOffRequest.id,
            notes = timeOffRequest.notes,
            startDate = startDate,
            startDay = startDay,
            startTime = startTime,
            endDate = endDate,
            endDay = endDay,
            endTime = endTime,
            dailyDurationMinutes = timeOffRequest.dailyDurationMinutes,
            status = timeOffRequest.status,
            dates = dates,
            crossesDst = start.crossesDst(end, timeZoneName),
            pending = timeOffRequest.status == TimeOffRequestResponse.Status.PENDING,
            occursThisWeek = isApproved && isThisWeek,
            occursAfterThisWeek = isApproved && isUpcoming,
            editable = timeOffRequest.status == TimeOffRequestResponse.Status.PENDING
        )
    }

    fun getTimeOffRequestsCellDataList(
        isLoading: Boolean,
        torList: List<TimeOffRequestResponse>,
        weekStart: DateTime,
        weekEnd: DateTime,
        timeZoneName: String = DEFAULT_TIME_ZONE_NAME,
        userMap: Map<String, User>
    ): List<TimeOffRequestListCellData> {
        if (isLoading) {
            return listOf(TimeOffRequestListCellData(type = TimeOffRequestListCellType.LOADING_INDICATOR_LIST_ITEM))
        }

        val allRequests = torList.map {
            getTimeOffRequestCellData(it, weekStart, weekEnd, timeZoneName, userMap)
        }.sortedByDescending {
            it.dates[0]
        }

        if (allRequests.isEmpty()) {
            return listOf(TimeOffRequestListCellData(type = TimeOffRequestListCellType.EMPTY_SECTION_LIST_ITEM))
        }

        return allRequests
    }

    fun getPendingTimeOffRequestsCellData(
        isLoading: Boolean,
        torList: List<TimeOffRequestListCellData>
    ): List<TimeOffRequestListCellData> {
        if (isLoading) {
            return listOf(TimeOffRequestListCellData(type = TimeOffRequestListCellType.LOADING_INDICATOR_LIST_ITEM))
        }

        val pendingRequests = torList.filter {
            it.pending
        }.sortedBy {
            it.dates[0]
        }

        if (pendingRequests.isEmpty()) {
            return listOf(TimeOffRequestListCellData(type = TimeOffRequestListCellType.EMPTY_SECTION_LIST_ITEM))
        }

        return pendingRequests
    }

    fun getThisWeeksTimeOffRequestsCellData(
        isLoading: Boolean,
        torList: List<TimeOffRequestListCellData>
    ): List<TimeOffRequestListCellData> {
        if (isLoading) {
            return listOf(TimeOffRequestListCellData(type = TimeOffRequestListCellType.LOADING_INDICATOR_LIST_ITEM))
        }

        val thisWeeksRequests = torList.filter {
            it.occursThisWeek
        }.sortedBy {
            it.dates[0]
        }

        if (thisWeeksRequests.isEmpty()) {
            return listOf(TimeOffRequestListCellData(type = TimeOffRequestListCellType.EMPTY_SECTION_LIST_ITEM))
        }

        return thisWeeksRequests
    }

    fun getUpcomingTimeOffRequestsCellData(
        isLoading: Boolean,
        torList: List<TimeOffRequestListCellData>
    ): List<TimeOffRequestListCellData> {
        if (isLoading) {
            return listOf(TimeOffRequestListCellData(type = TimeOffRequestListCellType.LOADING_INDICATOR_LIST_ITEM))
        }

        val upcomingRequests = torList.filter {
            it.occursAfterThisWeek
        }.sortedBy {
            it.dates[0]
        }

        if (upcomingRequests.isEmpty()) {
            return listOf(TimeOffRequestListCellData(type = TimeOffRequestListCellType.EMPTY_SECTION_LIST_ITEM))
        }

        return upcomingRequests
    }

    fun getTimeOffRequestDetailsModel(
        timeOffRequest: TimeOffRequestResponse,
        timeZoneName: String = DEFAULT_TIME_ZONE_NAME,
        userById: Map<String, User>,
        activityCodeMap: Map<String, ActivityCode>
    ): TimeOffRequestDetailsModel {
        val endDateMinutesOffset = timeOffRequest.dailyDurationMinutes.takeUnless {
            timeOffRequest.isFullDayRequest
        } ?: 0

        val start = timeOffRequest.dates.first()
        val end = timeOffRequest.dates.last().plusMinutes(endDateMinutesOffset)

        val tz = if (timeOffRequest.isFullDayRequest) DEFAULT_TIME_ZONE_NAME else timeZoneName

        val startDate = start.formatDateWithSlashes(tz)
        val startDay = start.formatWeekdayShort(tz)
        val startTime = if (!timeOffRequest.isFullDayRequest) start.formatTime(tz) else ""
        val endDate = end.formatDateWithSlashes(tz)
        val endDay = end.formatWeekdayShort(tz)
        val endTime = if (!timeOffRequest.isFullDayRequest) end.formatTime(tz) else ""

        return TimeOffRequestDetailsModel(
            id = timeOffRequest.id,
            type = activityCodeMap[timeOffRequest.activityCodeId]?.displayName ?: "".desc(),
            isFullDayRequest = timeOffRequest.isFullDayRequest,
            startDate = startDate,
            startDay = startDay,
            startTime = startTime,
            endDate = endDate,
            endDay = endDay,
            endTime = endTime,
            duration = formatDuration(timeOffRequest.dailyDurationMinutes),
            notes = timeOffRequest.notes,
            status = timeOffRequest.status,
            submittedByUserName = userById[timeOffRequest.submittedBy.id]?.name ?: "",
            submittedByDate = DateTime.parse(timeOffRequest.submittedDate).formatDateWithSlashes(timeZoneName),
            hasOccurred = timeOffRequest.dates.all { it < DateTime.now() }
        )
    }
}
