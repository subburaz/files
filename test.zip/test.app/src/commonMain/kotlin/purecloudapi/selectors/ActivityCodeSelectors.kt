package com.genesys.purecloud.wfmshared.purecloudapi.selectors

import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode

internal object ActivityCodeSelectors {
    fun getAgentTimeOffSelectableActivityCodes(activityCodes: Map<String, ActivityCode>) =
        activityCodes.values
            .filter(ActivityCode::isActive)
            .filter { it.agentTimeOffSelectable == true }

    fun getDefaultTimeOffActivityCode(activityCodes: Map<String, ActivityCode>) =
        getAgentTimeOffSelectableActivityCodes(activityCodes)
            .firstOrNull(ActivityCode::isDefault)
}
