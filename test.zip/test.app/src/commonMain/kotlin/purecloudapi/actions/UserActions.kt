package com.genesys.purecloud.wfmshared.purecloudapi.actions

import com.genesys.purecloud.wfmshared.di.COROUTINE_SCOPE_BG_TAG
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.User
import com.genesys.purecloud.wfmshared.purecloudapi.executePureCloudGetRequest
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.kodein.di.erased.instance

const val LOG_TAG_GET_USER_INFO = "getUserInfo"

suspend fun getUsersInfo(): User? {
    val response = executePureCloudGetRequest(PureCloudApiEndpoints.GET_USERS_INFO) ?: return null

    return try {
        serviceLocator.jsonSerializer.parse(User.serializer(), response)
    } catch (ex: Exception) {
        Logger.logError(LOG_TAG_GET_USER_INFO, "Failed to parse getUsersInfo response", ex)
        null
    }
}

suspend fun getUserInfo(userId: String): User? {
    val response = executePureCloudGetRequest("${PureCloudApiEndpoints.USERS_BASE_PATH}/$userId") ?: return null

    return try {
        serviceLocator.jsonSerializer.parse(User.serializer(), response)
    } catch (ex: Exception) {
        Logger.logError(LOG_TAG_GET_USER_INFO, "Failed to parse getUsersInfo response", ex)
        null
    }
}

fun checkSession(callback: (Boolean) -> Unit): Job {
    val scope: CoroutineScope by kodein.instance(tag = COROUTINE_SCOPE_BG_TAG)
    return scope.launch {
        val userInfo = getUsersInfo()

        callback(userInfo != null)
    }
}
