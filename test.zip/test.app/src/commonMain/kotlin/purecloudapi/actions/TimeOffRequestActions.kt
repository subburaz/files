package com.genesys.purecloud.wfmshared.purecloudapi.actions

import com.genesys.purecloud.wfmshared.components.timeoffrequest.details.TimeOffRequestDetailsModel
import com.genesys.purecloud.wfmshared.domain.common.getOrThrow
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode
import com.genesys.purecloud.wfmshared.domain.repositories.IActivityCodeRepository
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.AgentTimeOffRequestPatch
import com.genesys.purecloud.wfmshared.purecloudapi.entities.CreateAgentTimeOffRequest
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestList
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.User
import com.genesys.purecloud.wfmshared.purecloudapi.executePureCloudGetRequest
import com.genesys.purecloud.wfmshared.purecloudapi.executePureCloudPatchRequest
import com.genesys.purecloud.wfmshared.purecloudapi.executePureCloudPostRequest
import com.genesys.purecloud.wfmshared.purecloudapi.selectors.TimeOffRequestSelectors
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.util.DEFAULT_TIME_ZONE_NAME
import com.genesys.purecloud.wfmshared.util.Logger
import io.ktor.client.features.ResponseException
import org.kodein.di.erased.instance

const val LOG_TAG_GET_USERS_TORS = "getUsersTimeOffRequests"
const val LOG_TAG_POST_USERS_TORS = "postUsersTimeOffRequests"
const val LOG_TAG_PATCH_USERS_TORS = "patchUsersTimeOffRequest"

val users: MutableMap<String, User> by kodein.instance()

suspend fun getUsersTimeOffRequests(): List<TimeOffRequestResponse> {
    val response = executePureCloudGetRequest(PureCloudApiEndpoints.GET_USERS_TORS) ?: return emptyList()

    return try {
        serviceLocator.jsonSerializer.parse(TimeOffRequestList.serializer(), response).timeOffRequests
    } catch (ex: Exception) {
        Logger.logError(LOG_TAG_GET_USERS_TORS, "Failed to parse getUsersTimeOffRequests response", ex)
        emptyList()
    }
}

suspend fun getTimeOffRequest(id: String): TimeOffRequestResponse? {
    val response = executePureCloudGetRequest("${PureCloudApiEndpoints.GET_USERS_TORS}/$id") ?: return null

    return try {
        serviceLocator.jsonSerializer.parse(TimeOffRequestResponse.serializer(), response)
    } catch (ex: Exception) {
        Logger.logError(LOG_TAG_GET_USERS_TORS, "Failed to parse getTimeOffRequest response [torId: $id]", ex)
        null
    }
}

suspend fun patchUsersTimeOffRequest(requestBody: AgentTimeOffRequestPatch, userTorId: String): TimeOffRequestResponse? {
    val response = executePureCloudPatchRequest("${PureCloudApiEndpoints.PATCH_USER_TORS}/$userTorId",
        serviceLocator.jsonSerializer.stringify(AgentTimeOffRequestPatch.serializer(), requestBody)) ?: return null
    return try {
        serviceLocator.jsonSerializer.parse(TimeOffRequestResponse.serializer(), response)
    } catch (ex: Exception) {
        Logger.logError(LOG_TAG_PATCH_USERS_TORS, "Failed to parse patchUsersTimeOffRequest response", ex)
        null
    }
}

suspend fun postUsersTimeOffRequests(createAgentTimeOffRequest: CreateAgentTimeOffRequest): TimeOffRequestResponse? {
    return try {
        val response = executePureCloudPostRequest(
            PureCloudApiEndpoints.POST_USERS_TORS,
            serviceLocator.jsonSerializer.stringify(
                CreateAgentTimeOffRequest.serializer(),
                createAgentTimeOffRequest
            )
        ) ?: return null
        serviceLocator.jsonSerializer.parse(TimeOffRequestResponse.serializer(), response)
    } catch (cause: ResponseException) {
        throw cause
    } catch (ex: Exception) {
        Logger.logError(LOG_TAG_POST_USERS_TORS, "Failed to parse postUsersTimeOffRequests response", ex)
        return null
    }
}

suspend fun fetchTimeOffRequestDetails(
    torId: String,
    activityCodeRepository: IActivityCodeRepository
): TimeOffRequestDetailsModel {
    val timeOffRequest: TimeOffRequestResponse? = getTimeOffRequest(torId)

    return timeOffRequest?.let { tor: TimeOffRequestResponse ->
        val managementUnit = getUsersManagementUnit()

        val submittedByUserId = tor.submittedBy.id
        if (!users.containsKey(submittedByUserId)) {
            getUserInfo(submittedByUserId)?.let {
                users.put(submittedByUserId, it)
            }
        }

        val activityCodes: Map<String, ActivityCode> = activityCodeRepository.getActivityCodes().getOrThrow()

        val timeZoneName = managementUnit?.timeZone ?: DEFAULT_TIME_ZONE_NAME

        TimeOffRequestSelectors.getTimeOffRequestDetailsModel(
            timeOffRequest = tor,
            timeZoneName = timeZoneName,
            userById = users,
            activityCodeMap = activityCodes
        )
    } ?: TimeOffRequestDetailsModel()
}
