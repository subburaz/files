package com.genesys.purecloud.wfmshared.purecloudapi.actions

import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiEndpoints
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit
import com.genesys.purecloud.wfmshared.purecloudapi.executePureCloudGetRequest
import com.genesys.purecloud.wfmshared.serviceLocator
import com.genesys.purecloud.wfmshared.util.Logger

const val LOG_TAG_GET_USERS_MUS = "getUsersManagementUnit"

suspend fun getUsersManagementUnit(): ManagementUnit? {
    val response = executePureCloudGetRequest(PureCloudApiEndpoints.GET_USERS_MU) ?: return null

    return try {
        serviceLocator.jsonSerializer.parse(ManagementUnit.serializer(), response)
    } catch (ex: Exception) {
        Logger.logError(LOG_TAG_GET_USERS_MUS, "Failed to parse getUsersManagementUnit response", ex)
        null
    }
}
