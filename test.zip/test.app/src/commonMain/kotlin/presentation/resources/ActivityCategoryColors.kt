package com.genesys.purecloud.wfmshared.presentation.resources

import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode.Category
import com.genesys.purecloud.wfmshared.util.resources.CommonColors

val Category.color get() =
    when (this) {
        Category.BREAK -> CommonColors.CATEGORY_BREAK
        Category.MEAL -> CommonColors.CATEGORY_MEAL
        Category.MEETING -> CommonColors.CATEGORY_MEETING
        Category.ON_QUEUE -> CommonColors.CATEGORY_ON_QUEUE_WORK
        Category.OFF_QUEUE_WORK -> CommonColors.CATEGORY_OFF_QUEUE_WORK
        Category.TIME_OFF -> CommonColors.CATEGORY_TIME_OFF
        Category.TRAINING -> CommonColors.CATEGORY_TRAINING
        Category.UNAVAILABLE, Category.UNSCHEDULED -> CommonColors.CATEGORY_UNAVAILABLE
    }.description
