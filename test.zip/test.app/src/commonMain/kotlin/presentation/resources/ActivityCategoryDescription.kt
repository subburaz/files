package com.genesys.purecloud.wfmshared.presentation.resources

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode.Category
import dev.icerock.moko.resources.desc.StringDesc
import dev.icerock.moko.resources.desc.desc

val Category.description: StringDesc get() =
    when (this) {
        Category.BREAK -> MR.strings.activity_break
        Category.MEAL -> MR.strings.activity_meal
        Category.MEETING -> MR.strings.activity_meeting
        Category.ON_QUEUE -> MR.strings.activity_on_queue_work
        Category.OFF_QUEUE_WORK -> MR.strings.activity_off_queue_work
        Category.TIME_OFF -> MR.strings.activity_time_off
        Category.TRAINING -> MR.strings.activity_training
        Category.UNAVAILABLE, Category.UNSCHEDULED -> MR.strings.activity_unavailable
    }.desc()
