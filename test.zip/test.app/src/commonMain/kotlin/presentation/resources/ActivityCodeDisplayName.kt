package com.genesys.purecloud.wfmshared.presentation.resources

import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode
import dev.icerock.moko.resources.desc.StringDesc
import dev.icerock.moko.resources.desc.desc

val ActivityCode.displayName: StringDesc get() =
    when {
        name.isNotBlank() -> name.desc()
        else -> category.description
    }
