package com.genesys.purecloud.wfmshared.presentation.viewmodels
import com.genesys.purecloud.wfmshared.domain.common.Result
import com.genesys.purecloud.wfmshared.domain.entities.Shift
import com.genesys.purecloud.wfmshared.util.observable.Subject
import com.genesys.purecloud.wfmshared.util.resources.ColorDesc
import com.soywiz.klock.Date
import com.soywiz.klock.YearMonth
import dev.icerock.moko.resources.desc.StringDesc
import kotlinx.coroutines.Job

interface IScheduleViewModel {
    data class Selection(val date: Date, val activities: List<ActivityInfo>)

    abstract class ActivityInfo(
        val color: ColorDesc,
        val description: StringDesc
    ) {
        // See https://github.com/icerockdev/moko-resources/issues/62 for my feature request to
        // build capability into moko-resources that would make this much simpler
        // TODO: If request is implemented switch to official version
        abstract fun timeRange(localizer: StringDesc.() -> String): StringDesc
    }

    val scheduleData: Subject<Map<YearMonth, Result<List<Shift>>>>

    val loading: Subject<Boolean>

    val selectedShiftActivities: Subject<Selection>

    fun hasScheduleFor(date: Date): Boolean

    fun updateSchedule(month: YearMonth): Job

    fun selectDate(date: Date)
}
