package com.genesys.purecloud.wfmshared.presentation.features.schedule

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.domain.common.Result
import com.genesys.purecloud.wfmshared.domain.common.UseCase
import com.genesys.purecloud.wfmshared.domain.entities.Activity
import com.genesys.purecloud.wfmshared.domain.entities.Shift
import com.genesys.purecloud.wfmshared.presentation.resources.color
import com.genesys.purecloud.wfmshared.presentation.resources.description
import com.genesys.purecloud.wfmshared.presentation.viewmodels.IScheduleViewModel
import com.genesys.purecloud.wfmshared.util.observable.PublishSubject
import com.genesys.purecloud.wfmshared.util.observable.doLoad
import com.soywiz.klock.Date
import com.soywiz.klock.DateFormat
import com.soywiz.klock.DateTime
import com.soywiz.klock.DateTimeSpan
import com.soywiz.klock.YearMonth
import dev.icerock.moko.resources.desc.StringDesc
import dev.icerock.moko.resources.desc.desc
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

internal fun Shift.isOnDate(date: Date) = startDate.date == date

internal val Date.yearMonth get() = YearMonth(year, month1)

private val Activity.descriptionDesc: StringDesc get() = description
    ?.takeIf(CharSequence::isNotBlank)
    ?.desc()
    ?: category.description

internal val Activity.toActivityInfo get() =
    object : IScheduleViewModel.ActivityInfo(category.color, descriptionDesc) {
        override fun timeRange(localizer: StringDesc.() -> String) =
            with(DateFormat(MR.strings.date_format_time.desc().run(localizer))) {
                    val start = startTime.local
                    val end = start.plus(DateTimeSpan(minutes = lengthInMinutes))

                    StringDesc.ResourceFormatted(
                        MR.strings.time_range_format,
                        format(start),
                        format(end)
                    )
                }
    }

internal class ScheduleViewModel(
    private val uiScope: CoroutineScope,
    private val getSchedule: UseCase<YearMonth, List<Shift>>
) : IScheduleViewModel {
    private val schedule = mapOf<YearMonth, Result<List<Shift>>>()

    override val scheduleData = PublishSubject<Map<YearMonth, Result<List<Shift>>>>(
        emptyMap(), uiScope)

    override val loading = PublishSubject(false, uiScope)

    override val selectedShiftActivities =
        PublishSubject(IScheduleViewModel.Selection(DateTime.now().date, listOf()), uiScope)

    init {
        scheduleData.observe {
            selectDate(selectedShiftActivities.value.date)
        }
    }

    override fun updateSchedule(month: YearMonth) = uiScope.launch {
        loading.doLoad {
            scheduleData.postValue(schedule + (month to getSchedule(month)))
        }
    }

    override fun selectDate(date: Date) {
        selectedShiftActivities.postValue(IScheduleViewModel.Selection(
            date,
            (scheduleData.value[date.yearMonth]
                ?.getOrNull()
                ?.filter { it.isOnDate(date) }
                ?.flatMap(Shift::activities)
                ?.map(Activity::toActivityInfo)
                ?: listOf()))
        )
    }

    override fun hasScheduleFor(date: Date) =
        (scheduleData.value[date.yearMonth]?.getOrNull() ?: listOf())
            .any { it.isOnDate(date) }
}
