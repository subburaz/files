package com.genesys.purecloud.wfmshared.di

import com.genesys.purecloud.wfmshared.domain.common.UseCase
import com.genesys.purecloud.wfmshared.domain.entities.Shift
import com.genesys.purecloud.wfmshared.domain.usecases.GetScheduleUseCase
import com.soywiz.klock.YearMonth
import org.kodein.di.Kodein
import org.kodein.di.erased.bind
import org.kodein.di.erased.instance
import org.kodein.di.erased.singleton

fun domainModule() = Kodein.Module("Domain") {
    bind<UseCase<YearMonth, List<Shift>>>() with singleton {
        GetScheduleUseCase(instance())
    }
}
