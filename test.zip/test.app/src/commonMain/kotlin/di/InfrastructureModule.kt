package com.genesys.purecloud.wfmshared.di

import com.genesys.purecloud.wfmshared.purecloudapi.entities.User
import com.genesys.purecloud.wfmshared.util.coroutines.WFMSharedScope
import com.genesys.purecloud.wfmshared.util.coroutines.bgContext
import com.genesys.purecloud.wfmshared.util.coroutines.uiContext
import com.genesys.purecloud.wfmshared.util.resources.CommonStrings
import kotlinx.coroutines.CoroutineScope
import org.kodein.di.Kodein
import org.kodein.di.erased.bind
import org.kodein.di.erased.singleton

const val COROUTINE_SCOPE_BG_TAG = "COROUTINE_SCOPE_BG_TAG"
const val COROUTINE_SCOPE_UI_TAG = "COROUTINE_SCOPE_UI_TAG"

fun infrastructureModule() = Kodein.Module("Infrastructure") {
    bind<CoroutineScope>(tag = COROUTINE_SCOPE_BG_TAG) with singleton { WFMSharedScope(bgContext) }
    bind<CoroutineScope>(tag = COROUTINE_SCOPE_UI_TAG) with singleton { WFMSharedScope(uiContext) }

    bind<MutableMap<String, User>>() with singleton { mutableMapOf<String, User>() }
    bind<CommonStrings>() with singleton { CommonStrings() }
}
