package com.genesys.purecloud.wfmshared.di

import com.genesys.purecloud.wfmshared.AuthenticationData
import com.genesys.purecloud.wfmshared.AuthenticationListener
import com.genesys.purecloud.wfmshared.data.repositories.ActivityCodeRepository
import com.genesys.purecloud.wfmshared.data.repositories.UserScheduleRepository
import com.genesys.purecloud.wfmshared.domain.repositories.IActivityCodeRepository
import com.genesys.purecloud.wfmshared.domain.repositories.IUserScheduleRepository
import com.genesys.purecloud.wfmshared.purecloudapi.api.WorkforceManagementApi
import io.ktor.client.HttpClientConfig
import io.ktor.client.features.UserAgent
import io.ktor.client.features.json.serializer.KotlinxSerializer
import io.ktor.client.features.logging.DEFAULT
import io.ktor.client.features.logging.LogLevel
import io.ktor.client.features.logging.Logger
import io.ktor.client.features.logging.Logging
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonConfiguration
import org.kodein.di.Kodein
import org.kodein.di.erased.bind
import org.kodein.di.erased.instance
import org.kodein.di.erased.instanceOrNull
import org.kodein.di.erased.provider
import org.kodein.di.erased.singleton

val loggedOutData = AuthenticationData("", "", "")

var authentication: AuthenticationData = loggedOutData

fun dataModule() = Kodein.Module("Data") {
    bind<IActivityCodeRepository>() with singleton {
        ActivityCodeRepository(
            scope = instance(COROUTINE_SCOPE_BG_TAG),
            api = provider()
        )
    }

    bind<IUserScheduleRepository>() with singleton {
        UserScheduleRepository(
            scope = instance(COROUTINE_SCOPE_BG_TAG),
            api = provider(),
            activityCodeRepository = instance()
        )
    }

    bind<JsonConfiguration>() with instance(JsonConfiguration.Stable.copy(ignoreUnknownKeys = true))

    bind<Json>() with singleton { Json(instance<JsonConfiguration>()) }

    bind<KotlinxSerializer>() with singleton { KotlinxSerializer(instance()) }

    // Change this value to turn on logging of API traffic
    // valid values are HEADERS, BODY, INFO, and ALL or NONE
    bind<LogLevel>() with instance(LogLevel.NONE)

    bind<HttpClientConfig<*>.() -> Unit>() with provider {
        { httpClientConfig: HttpClientConfig<*> ->
            httpClientConfig.install(UserAgent) { agent = authentication.userAgent }
            httpClientConfig.install(Logging) {
                logger = Logger.DEFAULT
                level = instance()
            }
        }
    }

    bind<WorkforceManagementApi>() with provider {
        WorkforceManagementApi(
            authentication.apiUrl,
            instanceOrNull(),
            instance<KotlinxSerializer>(),
            instance()
        )
        .apply { setAccessToken(authentication.accessToken) }
    }

    bind<AuthenticationListener>() with singleton {
        object : AuthenticationListener {
            override fun loggedIn(authenticationData: AuthenticationData) {
                authentication = authenticationData
                instance<WorkforceManagementApi>().setAccessToken(authentication.accessToken)
            }

            override fun loggedOut() {
                authentication = loggedOutData
                instance<WorkforceManagementApi>().setAccessToken("")
            }
        }
    }
}
