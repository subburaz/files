package com.genesys.purecloud.wfmshared.di

import com.genesys.purecloud.wfmshared.components.settings.SettingsViewModel
import com.genesys.purecloud.wfmshared.components.timeoffrequest.create.TimeOffRequestCreateViewModel
import com.genesys.purecloud.wfmshared.components.timeoffrequest.details.TimeOffRequestDetailsViewModel
import com.genesys.purecloud.wfmshared.components.timeoffrequest.edit.TimeOffRequestEditViewModel
import com.genesys.purecloud.wfmshared.components.timeoffrequest.list.TimeOffRequestListViewModel
import com.genesys.purecloud.wfmshared.presentation.features.schedule.ScheduleViewModel
import com.genesys.purecloud.wfmshared.presentation.viewmodels.IScheduleViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ISettingsViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestCreateViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestDetailsViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestEditViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestListViewModel
import org.kodein.di.Kodein
import org.kodein.di.erased.bind
import org.kodein.di.erased.instance
import org.kodein.di.erased.singleton

fun presentationModule() = Kodein.Module("Presentation") {
    bind<ITimeOffRequestListViewModel>() with singleton {
        TimeOffRequestListViewModel(instance(tag = COROUTINE_SCOPE_BG_TAG), instance(tag = COROUTINE_SCOPE_UI_TAG))
    }
    bind<ITimeOffRequestDetailsViewModel>() with singleton {
        TimeOffRequestDetailsViewModel(instance(tag = COROUTINE_SCOPE_BG_TAG), instance(tag = COROUTINE_SCOPE_UI_TAG), instance())
    }
    bind<ITimeOffRequestEditViewModel>() with singleton {
        TimeOffRequestEditViewModel(instance(tag = COROUTINE_SCOPE_BG_TAG), instance(tag = COROUTINE_SCOPE_UI_TAG), instance())
    }
    bind<ITimeOffRequestCreateViewModel>() with singleton {
        TimeOffRequestCreateViewModel(instance(tag = COROUTINE_SCOPE_BG_TAG), instance(tag = COROUTINE_SCOPE_UI_TAG), instance())
    }
    bind<IScheduleViewModel>() with singleton {
        ScheduleViewModel(instance(tag = COROUTINE_SCOPE_UI_TAG), instance())
    }
    bind<ISettingsViewModel>() with singleton {
        SettingsViewModel(instance(tag = COROUTINE_SCOPE_UI_TAG), instance(tag = COROUTINE_SCOPE_UI_TAG))
    }
}
