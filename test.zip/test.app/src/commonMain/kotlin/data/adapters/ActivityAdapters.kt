package com.genesys.purecloud.wfmshared.data.adapters

import com.genesys.purecloud.wfmshared.domain.entities.Activity
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode.Category
import com.genesys.purecloud.wfmshared.domain.entities.Shift
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BuAgentScheduleActivity
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BuAgentScheduleSearchResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BuAgentScheduleShift
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BuCurrentAgentScheduleSearchResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.BREAK
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.MEAL
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.MEETING
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.OFF_QUEUE_WORK
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.ON_QUEUE_WORK
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.TIME_OFF
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.TRAINING
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.UNAVAILABLE
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BusinessUnitActivityCode.Category.UNSCHEDULED
import com.soywiz.klock.DateTime
import com.soywiz.klock.YearMonth
import com.soywiz.klock.months

internal val YearMonth.monthRange get() =
    DateTime(year.year, month1, 1)
        .run { localUnadjusted.utc..this.plus(1.months).localUnadjusted.utc }

internal val BusinessUnitActivityCode.Category?.toCategory get() =
    when (this) {
        ON_QUEUE_WORK -> Category.ON_QUEUE
        BREAK -> Category.BREAK
        MEAL -> Category.MEAL
        MEETING -> Category.MEETING
        OFF_QUEUE_WORK -> Category.OFF_QUEUE_WORK
        TIME_OFF -> Category.TIME_OFF
        TRAINING -> Category.TRAINING
        UNAVAILABLE -> Category.UNAVAILABLE
        null, UNSCHEDULED -> Category.UNSCHEDULED
    }

internal val ActivityCode.Category?.toCategory get() =
    when (this) {
        Category.ON_QUEUE -> ON_QUEUE_WORK
        Category.BREAK -> BREAK
        Category.MEAL -> MEAL
        Category.MEETING -> MEETING
        Category.OFF_QUEUE_WORK -> OFF_QUEUE_WORK
        Category.TIME_OFF -> TIME_OFF
        Category.TRAINING -> TRAINING
        Category.UNAVAILABLE -> UNAVAILABLE
        null, Category.UNSCHEDULED -> UNSCHEDULED
    }

internal val BusinessUnitActivityCode.toEntity get() =
    ActivityCode(
        category = category.toCategory,
        name = name,
        countsAsPaidTime = countsAsPaidTime,
        countsAsWorkTime = countsAsWorkTime,
        isDefault = defaultCode,
        isActive = active,
        agentTimeOffSelectable = agentTimeOffSelectable,
        lengthInMinutes = lengthInMinutes,
        id = id
    )

internal fun BuAgentScheduleActivity.toActivity(category: Category) = Activity(
    category = category,
    startTime = DateTime.parse(startDate).utc,
    lengthInMinutes = lengthMinutes,
    description = description,
    countsAsPaidTime = paid
)

internal fun BuAgentScheduleShift.toShift(categories: Map<String, ActivityCode>) =
    Shift(
        startDate = DateTime.parse(startDate).utc,
        lengthInMinutes = lengthMinutes,
        activities = activities
            .map { it.toActivity(categories[it.activityCodeId]?.category
                ?: Category.UNSCHEDULED) }
    )

internal fun BuCurrentAgentScheduleSearchResponse.shifts(categories: Map<String, ActivityCode>): List<Shift> =
    agentSchedules
        .flatMap(BuAgentScheduleSearchResponse::shifts)
        .map { it.toShift(categories) }
