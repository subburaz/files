package com.genesys.purecloud.wfmshared.data.repositories

import com.genesys.purecloud.wfmshared.data.adapters.monthRange
import com.genesys.purecloud.wfmshared.data.adapters.shifts
import com.genesys.purecloud.wfmshared.domain.common.NetworkException
import com.genesys.purecloud.wfmshared.domain.common.Result
import com.genesys.purecloud.wfmshared.domain.common.getOrThrow
import com.genesys.purecloud.wfmshared.domain.common.runCatching
import com.genesys.purecloud.wfmshared.domain.entities.Shift
import com.genesys.purecloud.wfmshared.domain.repositories.IActivityCodeRepository
import com.genesys.purecloud.wfmshared.domain.repositories.IUserScheduleRepository
import com.genesys.purecloud.wfmshared.purecloudapi.api.WorkforceManagementApi
import com.genesys.purecloud.wfmshared.purecloudapi.entities.BuGetCurrentAgentScheduleRequest
import com.soywiz.klock.DateTime
import com.soywiz.klock.ISO8601
import com.soywiz.klock.YearMonth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.withContext

val ISO8601_FORMAT =
    ISO8601.IsoDateTimeFormat("YYYYMMDDThhmmssZ", "YYYY-MM-DDThh:mm:ssZ")

private fun ClosedRange<DateTime>.toRequest() =
    BuGetCurrentAgentScheduleRequest(
        start.format(ISO8601_FORMAT),
        endInclusive.format(ISO8601_FORMAT)
    )

class UserScheduleRepository(
    private val scope: CoroutineScope,
    private val api: () -> WorkforceManagementApi,
    private val activityCodeRepository: IActivityCodeRepository
) : IUserScheduleRepository {
    override suspend fun getUserSchedule(month: YearMonth): Result<List<Shift>> =
        withContext(scope.coroutineContext) {
            Result.runCatching {
                val activityCategories = activityCodeRepository.getActivityCodes()
                    .getOrThrow()

                api().postWorkforcemanagementAgentschedulesMine(month.monthRange.toRequest())
                    .run {
                        takeIf { success }
                            ?.run { body().shifts(activityCategories) }
                            ?: throw NetworkException(status)
                    }
            }
        }
}
