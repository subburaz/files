package com.genesys.purecloud.wfmshared.data.repositories

import com.genesys.purecloud.wfmshared.data.adapters.toEntity
import com.genesys.purecloud.wfmshared.domain.common.NetworkException
import com.genesys.purecloud.wfmshared.domain.common.Result
import com.genesys.purecloud.wfmshared.domain.common.runCatching
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode
import com.genesys.purecloud.wfmshared.domain.repositories.IActivityCodeRepository
import com.genesys.purecloud.wfmshared.purecloudapi.api.WorkforceManagementApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.withContext

class ActivityCodeRepository(
    private val scope: CoroutineScope,
    private val api: () -> WorkforceManagementApi
) : IActivityCodeRepository {
    override suspend fun getActivityCodes(): Result<Map<String, ActivityCode>> =
        withContext(scope.coroutineContext) {
                api().getWorkforcemanagementBusinessunitActivitycodes("mine")
                    .runCatching {
                        takeIf { success }
                            ?.run { body().entities }
                            ?.run { associateBy({ it.id }, { it.toEntity }) }
                            ?: throw NetworkException(status)
                    }
        }
}
