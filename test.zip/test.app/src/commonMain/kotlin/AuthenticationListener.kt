package com.genesys.purecloud.wfmshared

data class AuthenticationData(
    val apiUrl: String,
    val accessToken: String,
    val userAgent: String
)

interface AuthenticationListener {
    fun loggedIn(authenticationData: AuthenticationData)

    fun loggedOut()
}
