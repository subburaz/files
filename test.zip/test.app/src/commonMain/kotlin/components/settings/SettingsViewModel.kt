package com.genesys.purecloud.wfmshared.components.settings

import com.genesys.purecloud.wfmshared.purecloudapi.actions.getUsersInfo
import com.genesys.purecloud.wfmshared.purecloudapi.entities.User
import com.genesys.purecloud.wfmshared.util.observable.PublishSubject
import com.genesys.purecloud.wfmshared.util.thirdPartyDependencies
import com.genesys.purecloud.wfmshared.viewmodels.ISettingsViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val bgScope: CoroutineScope,
    uiScope: CoroutineScope
) : ISettingsViewModel {
    override val userSettingsModel = PublishSubject(UserSettingsModel(), uiScope)
    override val dependencyInformation get() =
        thirdPartyDependencies.sortedBy { it.projectName.toLowerCase() }

    // internal variables of the raw data from the HTTP get request, used to generate the consumer visible data
    private var userSettings: User = User("", "")
        set(value) {
            field = value

            userSettingsModel.postValue(UserSettingsModel(
                id = value.id,
                name = value.username!!,
                images = value.images?.get(0)
            ))
        }

    override fun getUserSettingsInfo(): Job {
        return bgScope.launch {
            userSettings = getUsersInfo()!!
        }
    }
}
