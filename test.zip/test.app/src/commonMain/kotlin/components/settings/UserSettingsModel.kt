package com.genesys.purecloud.wfmshared.components.settings

import com.genesys.purecloud.wfmshared.purecloudapi.entities.UserImage

data class UserSettingsModel(
    val id: String = "",
    val name: String = "",
    val images: UserImage? = UserImage()
)
