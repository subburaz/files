package com.genesys.purecloud.wfmshared.components.timeoffrequest.create

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.components.timeoffrequest.edit.NOTES_MAX_LENGTH
import com.genesys.purecloud.wfmshared.domain.common.getOrThrow
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode
import com.genesys.purecloud.wfmshared.domain.repositories.IActivityCodeRepository
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.purecloudapi.actions.getUsersManagementUnit
import com.genesys.purecloud.wfmshared.purecloudapi.actions.postUsersTimeOffRequests
import com.genesys.purecloud.wfmshared.purecloudapi.entities.CreateAgentTimeOffRequest
import com.genesys.purecloud.wfmshared.purecloudapi.selectors.ActivityCodeSelectors.getAgentTimeOffSelectableActivityCodes
import com.genesys.purecloud.wfmshared.purecloudapi.selectors.ActivityCodeSelectors.getDefaultTimeOffActivityCode
import com.genesys.purecloud.wfmshared.util.DAYS_PER_YEAR
import com.genesys.purecloud.wfmshared.util.DEFAULT_TIME_ZONE_NAME
import com.genesys.purecloud.wfmshared.util.MINUTES_PER_HOUR
import com.genesys.purecloud.wfmshared.util.TimeDuration
import com.genesys.purecloud.wfmshared.util.dateFormatDateWithSlashes
import com.genesys.purecloud.wfmshared.util.dateFormatDayShort
import com.genesys.purecloud.wfmshared.util.dateFormatISO8601
import com.genesys.purecloud.wfmshared.util.dateTimeFormatISO8601
import com.genesys.purecloud.wfmshared.util.observable.PublishSubject
import com.genesys.purecloud.wfmshared.util.observable.SimpleObservable
import com.genesys.purecloud.wfmshared.util.resources.CommonStrings
import com.genesys.purecloud.wfmshared.util.startOfDay
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestCreateViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestCreateViewModel.SubmitResult
import com.soywiz.klock.DateFormat
import com.soywiz.klock.DateTimeTz
import com.soywiz.klock.days
import com.soywiz.klock.minutes
import com.soywiz.klock.parse
import com.soywiz.klock.parseUtc
import dev.icerock.moko.resources.desc.desc
import io.ktor.client.features.ResponseException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.kodein.di.erased.instance

const val DEFAULT_DURATION_HOURS = 8
const val DEFAULT_DURATION_IN_MINUTES = DEFAULT_DURATION_HOURS * MINUTES_PER_HOUR

const val DEFAULT_START_TIME_OFFSET_IN_MINUTES = 480 // Same value as web-contact-center-wfm/src/js/views/agent/schedule/AgentTimeOff.ts

const val DEFAULT_MIN_TOR_DATE_DAYS_FROM_NOW = -3 * DAYS_PER_YEAR
const val DEFAULT_MAX_TOR_DATE_DAYS_FROM_NOW = 3 * DAYS_PER_YEAR

class TimeOffRequestCreateViewModel(
    private val bgScope: CoroutineScope,
    uiScope: CoroutineScope,
    private val activityCodeRepository: IActivityCodeRepository
) : ITimeOffRequestCreateViewModel {

    private val commonStrings: CommonStrings by kodein.instance()
    private val timeFormatter = DateFormat(commonStrings.getString(MR.strings.date_format_time))

    private val today = DateTimeTz.nowLocal().startOfDay

    private var activityCodeMap: Map<String, ActivityCode> = emptyMap()
    private var requestTimeZone = DEFAULT_TIME_ZONE_NAME

    override val submitResult = SimpleObservable<SubmitResult>(uiScope)
    override val viewState = PublishSubject<TimeOffRequestCreateViewState>(TimeOffRequestCreateViewState(), uiScope)

    override val notesMaxLength = NOTES_MAX_LENGTH

    private fun updateValidation() {
        val isValid = (
            selectedActivityCodeId.isNotEmpty() &&
            selectedStartDate.isNotEmpty() &&
            selectedEndDate.isNotEmpty() &&
            (selectedNotes.length < notesMaxLength)
        )

        if (isValid != viewState.value.canSubmit) {
            viewState.postValue(viewState.value.copy(
                canSubmit = isValid
            ))
        }
    }

    private fun updateTimes(duration: TimeDuration = viewState.value.torDuration) {
        var startTimeStr = ""
        var endTimeStr = ""
        if (!selectedIsFullDay) {
            val start = dateFormatISO8601.parse(selectedStartDate) + selectedStartTimeOffsetInMinutes.minutes
            val end = start + duration.lengthInMinutes.minutes
            startTimeStr = start.format(timeFormatter)
            endTimeStr = end.format(timeFormatter)
        }

        viewState.postValue(viewState.value.copy(
            startTime = startTimeStr,
            endTime = endTimeStr
        ))
    }

    override var selectedActivityCodeId = ""
        set(value) {
            if (value != field) {
                field = value
                updateValidation()

                selectedDuration = TimeDuration(activityCodeMap[value]?.lengthInMinutes ?: selectedDuration.lengthInMinutes)
            }
        }

    override var selectedIsFullDay = true
        set(value) {
            field = value
            updateValidation()

            updateTimes()

            viewState.postValue(viewState.value.copy(
                startTimePickerIsVisible = false
            ))
        }

    /**
     * "yyyy-MM-dd"
     */
    override var selectedStartDate = today.format(dateFormatISO8601)
        set(value) {
            field = value
            updateValidation()

            val date = dateFormatISO8601.parse(value)

            val endDate = dateFormatISO8601.parse(selectedEndDate)

            if (endDate < date) {
                selectedEndDate = value
            }

            viewState.postValue(viewState.value.copy(
                start = date.local,
                startDate = date.local.format(dateFormatDateWithSlashes),
                startDay = date.local.format(dateFormatDayShort),
                startDatePickerIsVisible = viewState.value.startDatePickerIsVisible && selectedIsFullDay,
                startTimePickerIsVisible = viewState.value.startDatePickerIsVisible && !selectedIsFullDay
            ))
        }

    override var selectedStartTimeOffsetInMinutes = DEFAULT_START_TIME_OFFSET_IN_MINUTES
        set(value) {
            field = value
            updateValidation()

            updateTimes()

            viewState.postValue(viewState.value.copy(
                startTimeHours = value / MINUTES_PER_HOUR,
                startTimeMinutes = value % MINUTES_PER_HOUR
            ))
        }

    /**
     * "yyyy-MM-dd"
     */
    override var selectedEndDate = today.format(dateFormatISO8601)
        set(value) {
            field = value
            updateValidation()

            val date = dateFormatISO8601.parse(value)
            val startDate = dateFormatISO8601.parse(selectedStartDate)

            if (date < startDate) {
                selectedStartDate = value
            }

            viewState.postValue(viewState.value.copy(
                end = date.local,
                endDate = date.local.format(dateFormatDateWithSlashes),
                endDay = date.local.format(dateFormatDayShort)
            ))
        }

    override var selectedNotes = ""
        set(value) {
            updateValidation()
            field = value
        }

    override var selectedDuration = TimeDuration(DEFAULT_DURATION_IN_MINUTES)
        set(value) {
            if (value != field) {
                updateValidation()
                field = value

                viewState.postValue(viewState.value.copy(
                    torDuration = value
                ))

                updateTimes(value)
            }
        }

    override fun initialize(): Job {
        selectedIsFullDay = true
        selectedStartDate = today.format(dateFormatISO8601)
        selectedStartTimeOffsetInMinutes = DEFAULT_START_TIME_OFFSET_IN_MINUTES
        selectedEndDate = today.format(dateFormatISO8601)
        selectedNotes = ""

        return bgScope.launch {
            activityCodeMap = activityCodeRepository.getActivityCodes().getOrThrow()
            val defaultActivityCode = getDefaultTimeOffActivityCode(activityCodeMap)
            selectedDuration = TimeDuration(defaultActivityCode?.lengthInMinutes ?: DEFAULT_DURATION_IN_MINUTES)
            selectedActivityCodeId = defaultActivityCode?.id ?: ""

            viewState.postValue(viewState.value.copy(
                selectableActivityCodes = getAgentTimeOffSelectableActivityCodes(activityCodeMap),
                activityId = selectedActivityCodeId
            ))

            getUsersManagementUnit()?.run {
                requestTimeZone = timeZone

                var torEarliestDaysFromNow = DEFAULT_MIN_TOR_DATE_DAYS_FROM_NOW
                var torLatestDaysFromNow = DEFAULT_MAX_TOR_DATE_DAYS_FROM_NOW

                settings?.timeOff?.run {
                    if (submissionRangeEnforced == true) {
                        torEarliestDaysFromNow = submissionEarliestDaysFromNow ?: DEFAULT_MIN_TOR_DATE_DAYS_FROM_NOW
                        torLatestDaysFromNow = submissionLatestDaysFromNow ?: DEFAULT_MAX_TOR_DATE_DAYS_FROM_NOW
                    }
                }

                val earliestDate = today + torEarliestDaysFromNow.days
                val latestDate = today + torLatestDaysFromNow.days

                viewState.postValue(viewState.value.copy(
                    startMin = earliestDate,
                    endMax = latestDate
                ))

                val currentStartDate = dateFormatISO8601.parseUtc(selectedStartDate)
                val currentEndDate = dateFormatISO8601.parseUtc(selectedEndDate)

                if (currentStartDate < earliestDate) {
                    selectedStartDate = earliestDate.format(dateFormatISO8601)
                }

                if (currentEndDate > latestDate) {
                    selectedEndDate = latestDate.format(dateFormatISO8601)
                }
            }
        }
    }

    @ExperimentalStdlibApi
    override fun submitTimeOffRequest(): Job {
        updateTimes()
        updateValidation()

        return bgScope.launch {
            var fullDayDates = emptyList<String>()
            var partialDayDates = emptyList<String>()

            val startDate = dateFormatISO8601.parseUtc(selectedStartDate)
            val endDate = dateFormatISO8601.parseUtc(selectedEndDate)

            val dates = generateSequence(startDate) {
                if (it >= endDate) { null } else {
                    it + 1.days
                }
            }.toList()

            if (selectedIsFullDay) {
                fullDayDates = dates.map {
                    it.format(dateFormatISO8601)
                }
            } else {
                partialDayDates = dates.map {
                    (it.localUnadjusted.utc + selectedStartTimeOffsetInMinutes.minutes)
                        .format(dateTimeFormatISO8601)
                }
            }
            try {
                postUsersTimeOffRequests(CreateAgentTimeOffRequest(
                    activityCodeId = selectedActivityCodeId,
                    dailyDurationMinutes = selectedDuration.lengthInMinutes,
                    notes = selectedNotes,
                    fullDayManagementUnitDates = fullDayDates.toSet(),
                    partialDayStartDateTimes = partialDayDates.toSet()
                ))

                submitResult.postValue(SubmitResult(true, MR.strings.status_create_request_success.desc()))
            } catch (cause: ResponseException) {
                submitResult.postValue(SubmitResult(false, MR.strings.status_create_request_failure.desc()))
            }
        }
    }

    override fun toggleStartDateTimeVisibility() {
        with(viewState.value) {
            viewState.postValue(
                this.copy(
                    startDatePickerIsVisible = !startDatePickerIsVisible && !startTimePickerIsVisible,
                    startTimePickerIsVisible = false,
                    endDatePickerIsVisible = false,
                    durationPickerIsVisible = false
                )
            )
        }
    }

    override fun toggleEndDateVisibility() {
        with(viewState.value) {
            viewState.postValue(
                this.copy(
                    startDatePickerIsVisible = false,
                    startTimePickerIsVisible = false,
                    endDatePickerIsVisible = !endDatePickerIsVisible,
                    durationPickerIsVisible = false
                )
            )
        }
    }

    override fun toggleDurationVisibility() {
        with(viewState.value) {
            viewState.postValue(
                this.copy(
                    startDatePickerIsVisible = false,
                    startTimePickerIsVisible = false,
                    endDatePickerIsVisible = false,
                    durationPickerIsVisible = !durationPickerIsVisible
                )
            )
        }
    }
}
