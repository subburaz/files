package com.genesys.purecloud.wfmshared.components.timeoffrequest.create

import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode
import com.genesys.purecloud.wfmshared.util.TimeDuration
import com.soywiz.klock.DateTime

data class TimeOffRequestCreateViewState(
    val selectableActivityCodes: List<ActivityCode> = emptyList(),
    val activityId: String = "",
    val startDay: String = "",
    val startDate: String = "",
    val startTime: String = "",
    val startTimeHours: Int = 0,
    val startTimeMinutes: Int = 0,
    val endDay: String = "",
    val endDate: String = "",
    val endTime: String = "",
    val torDuration: TimeDuration = TimeDuration(DEFAULT_DURATION_IN_MINUTES),
    val start: DateTime = DateTime.now(),
    val startMin: DateTime = DateTime.now(),
    val end: DateTime = DateTime.now(),
    val endMax: DateTime = DateTime.now(),
    val canSubmit: Boolean = false,
    val startDatePickerIsVisible: Boolean = false,
    val startTimePickerIsVisible: Boolean = false,
    val endDatePickerIsVisible: Boolean = false,
    val durationPickerIsVisible: Boolean = false
)
