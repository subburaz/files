package com.genesys.purecloud.wfmshared.components.timeoffrequest.list

enum class TimeOffRequestListCellType {
    SECTION_HEADER_LIST_ITEM,
    EMPTY_SECTION_LIST_ITEM,
    LOADING_INDICATOR_LIST_ITEM,
    SINGLE_DAY_FULL_TOR_LIST_ITEM,
    SINGLE_DAY_PARTIAL_TOR_LIST_ITEM,
    MULTIPLE_DAY_TOR_LIST_ITEM
}
