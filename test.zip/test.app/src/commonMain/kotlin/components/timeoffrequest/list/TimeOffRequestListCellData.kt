package com.genesys.purecloud.wfmshared.components.timeoffrequest.list

import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.util.DateTime

data class TimeOffRequestListCellData(
    val type: TimeOffRequestListCellType,
    val id: String = "",
    val notes: String = "",
    val startDate: String = "",
    val startDay: String = "",
    val startTime: String = "",
    val endDate: String = "",
    val endDay: String = "",
    val endTime: String = "",

    val dailyDurationMinutes: Int = 1,
    val supportText: String = "",
    val status: TimeOffRequestResponse.Status = TimeOffRequestResponse.Status.PENDING,
    val dates: List<DateTime> = listOf(),
    val crossesDst: Boolean = false,
    val pending: Boolean = false,
    val occursThisWeek: Boolean = false,
    val occursAfterThisWeek: Boolean = false,
    val editable: Boolean = false,

    // FIXME: This is a hack so that TimeOffRequestResponse gets exported to iOS, this needs to go away
    var hack: TimeOffRequestResponse? = null
)
