package com.genesys.purecloud.wfmshared.components.timeoffrequest.list

import com.genesys.purecloud.wfmshared.purecloudapi.actions.getUserInfo
import com.genesys.purecloud.wfmshared.purecloudapi.actions.getUsersManagementUnit
import com.genesys.purecloud.wfmshared.purecloudapi.actions.getUsersTimeOffRequests
import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import com.genesys.purecloud.wfmshared.purecloudapi.entities.User
import com.genesys.purecloud.wfmshared.purecloudapi.selectors.TimeOffRequestSelectors
import com.genesys.purecloud.wfmshared.util.DAYS_PER_WEEK
import com.genesys.purecloud.wfmshared.util.DEFAULT_START_DAY_OF_WEEK
import com.genesys.purecloud.wfmshared.util.DEFAULT_TIME_ZONE_NAME
import com.genesys.purecloud.wfmshared.util.DateTime
import com.genesys.purecloud.wfmshared.util.observable.PublishSubject
import com.genesys.purecloud.wfmshared.util.observable.Subject
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestListViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

internal class TimeOffRequestListViewModel(private val bgScope: CoroutineScope, uiScope: CoroutineScope) :
    ITimeOffRequestListViewModel {
    // Mutable observers that hold the data that consumers of the ViewModel will need
    // These are private so that only this class can mutate the values
    private val allTimeOffRequests: PublishSubject<List<TimeOffRequestListCellData>> = PublishSubject(emptyList(), uiScope)
    private val pendingTimeOffRequests: PublishSubject<List<TimeOffRequestListCellData>> = PublishSubject(emptyList(), uiScope)
    private val thisWeeksTimeOffRequests: PublishSubject<List<TimeOffRequestListCellData>> = PublishSubject(emptyList(), uiScope)
    private val upcomingTimeOffRequests: PublishSubject<List<TimeOffRequestListCellData>> = PublishSubject(emptyList(), uiScope)
    private val users = mutableMapOf<String, User>()
    private val isLoading: PublishSubject<Boolean> = PublishSubject(false, uiScope)

    // Helper variables
    private var weekEnd: DateTime = DateTime.now().plusDays(DAYS_PER_WEEK)
    private var weekStart: DateTime = DateTime.now()
        set(value) {
            weekEnd = value.plusDays(DAYS_PER_WEEK).minusSeconds(1)
            field = value
        }

    // internal variables of the raw data from the HTTP get request, used to generate the consumer visible data
    internal var timeOffRequests: List<TimeOffRequestResponse> = emptyList()
        set(value) {
            field = value
            allTimeOffRequests.postValue(TimeOffRequestSelectors.getTimeOffRequestsCellDataList(isLoading.value, value, weekStart, weekEnd, timeZoneName, users))
        }

    internal var timeZoneName = DEFAULT_TIME_ZONE_NAME

    internal var startDayOfWeek = DEFAULT_START_DAY_OF_WEEK
        set(value) {
            weekStart = DateTime.now().startOfWeek(timeZoneName, value)

            field = value
        }

    init {
        allTimeOffRequests.observe {
            pendingTimeOffRequests.postValue(TimeOffRequestSelectors.getPendingTimeOffRequestsCellData(isLoading.value, it))
            thisWeeksTimeOffRequests.postValue(TimeOffRequestSelectors.getThisWeeksTimeOffRequestsCellData(isLoading.value, it))
            upcomingTimeOffRequests.postValue(TimeOffRequestSelectors.getUpcomingTimeOffRequestsCellData(isLoading.value, it))
        }

        isLoading.observe {
            allTimeOffRequests.postValue(TimeOffRequestSelectors.getTimeOffRequestsCellDataList(isLoading.value, timeOffRequests, weekStart, weekEnd, timeZoneName, users))
        }
    }

    /**
     * Returns an Observable that contains all of the time off requests.
     */
    override fun getAllTimeOffRequests(): Subject<List<TimeOffRequestListCellData>> { return allTimeOffRequests }

    /**
     * Returns an Observable that contains all of the pending time off requests.
     */
    override fun getPendingTimeOffRequests(): Subject<List<TimeOffRequestListCellData>> { return pendingTimeOffRequests }

    /**
     * Returns an Observable that contains all time off requests that occur this week.
     */
    override fun getThisWeeksTimeOffRequests(): Subject<List<TimeOffRequestListCellData>> { return thisWeeksTimeOffRequests }

    /**
     * Returns an Observable that contains all time off requests that happen in the future.
     */
    override fun getUpcomingTimeOffRequests(): Subject<List<TimeOffRequestListCellData>> { return upcomingTimeOffRequests }

    /**
     * Requests the latest time off requests from the server, updates the Observables on completion.
     */
    override fun updateTimeOffRequests(): Job {
        return bgScope.launch {
            isLoading.postValue(true)
            val newTimeOffRequests = getUsersTimeOffRequests()
            val managementUnit = getUsersManagementUnit()
            // val submittedByUserIdList = mutableListOf<String>()
            newTimeOffRequests.forEach {
                val submittedByUserId = it.submittedBy.id
                if (!users.containsKey(submittedByUserId)) {
                    val user = getUserInfo(submittedByUserId)
                    if (user != null) users[submittedByUserId] = user
                }
            }

            timeZoneName = managementUnit?.timeZone ?: DEFAULT_TIME_ZONE_NAME
            startDayOfWeek = managementUnit?.startDayOfWeek ?: DEFAULT_START_DAY_OF_WEEK
            timeOffRequests = newTimeOffRequests

            isLoading.postValue(false)
        }
    }
}
