package com.genesys.purecloud.wfmshared.components.timeoffrequest.details

import com.genesys.purecloud.wfmshared.purecloudapi.entities.TimeOffRequestResponse
import dev.icerock.moko.resources.desc.StringDesc
import dev.icerock.moko.resources.desc.desc

data class TimeOffRequestDetailsModel(
    val id: String = "",
    val type: StringDesc = "".desc(),
    val isFullDayRequest: Boolean = true,
    val startDate: String = "",
    val startDay: String = "",
    val startTime: String = "",
    val endDate: String = "",
    val endDay: String = "",
    val endTime: String = "",
    val duration: String = "",
    val notes: String = "",
    val status: TimeOffRequestResponse.Status = TimeOffRequestResponse.Status.CANCELED,
    val submittedByUserName: String = "",
    val submittedByDate: String = "",
    val hasOccurred: Boolean = false
) {
    val hasNotes get() = notes.isNotBlank()

    val canEditNotes get() = status == TimeOffRequestResponse.Status.PENDING

    val canCancelRequest get() =
        when (status) {
            TimeOffRequestResponse.Status.PENDING, TimeOffRequestResponse.Status.APPROVED -> !hasOccurred
            else -> false
        }

    val canEditRequest get() = canEditNotes || canCancelRequest
}
