package com.genesys.purecloud.wfmshared.components.timeoffrequest.details

import com.genesys.purecloud.wfmshared.domain.repositories.IActivityCodeRepository
import com.genesys.purecloud.wfmshared.purecloudapi.actions.fetchTimeOffRequestDetails
import com.genesys.purecloud.wfmshared.util.observable.PublishSubject
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestDetailsViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

open class TimeOffRequestDetailsViewModel(
    private val bgScope: CoroutineScope,
    uiScope: CoroutineScope,
    private val activityCodeRepository: IActivityCodeRepository
) : ITimeOffRequestDetailsViewModel {
    override val timeOffRequestDetailsModel = PublishSubject(TimeOffRequestDetailsModel(), uiScope)
    override val isLoading = PublishSubject(false, uiScope)
    override val isInitialized = PublishSubject(false, uiScope)

    override fun fetchTimeOffRequest(torId: String): Job {
        return bgScope.launch {
            isLoading.postValue(true)
            timeOffRequestDetailsModel.postValue(fetchTimeOffRequestDetails(torId, activityCodeRepository))
            isLoading.postValue(false)
            isInitialized.postValue(true)
        }
    }

    override fun reset() {
        timeOffRequestDetailsModel.postValue(TimeOffRequestDetailsModel())
        isLoading.postValue(false)
        isInitialized.postValue(false)
    }
}
