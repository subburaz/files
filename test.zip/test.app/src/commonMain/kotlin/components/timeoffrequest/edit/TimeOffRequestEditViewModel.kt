package com.genesys.purecloud.wfmshared.components.timeoffrequest.edit

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.components.timeoffrequest.details.TimeOffRequestDetailsViewModel
import com.genesys.purecloud.wfmshared.domain.repositories.IActivityCodeRepository
import com.genesys.purecloud.wfmshared.purecloudapi.actions.patchUsersTimeOffRequest
import com.genesys.purecloud.wfmshared.purecloudapi.entities.AgentTimeOffRequestPatch
import com.genesys.purecloud.wfmshared.util.observable.PublishSubject
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestEditViewModel
import dev.icerock.moko.resources.StringResource
import dev.icerock.moko.resources.desc.StringDesc
import dev.icerock.moko.resources.desc.desc
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

// max length is enforced server side, 100 is the max value used on the web client
const val NOTES_MAX_LENGTH = 100

class TimeOffRequestEditViewModel(
    private val bgScope: CoroutineScope,
    uiScope: CoroutineScope,
    activityCodeRepository: IActivityCodeRepository
) : ITimeOffRequestEditViewModel, TimeOffRequestDetailsViewModel(bgScope, uiScope, activityCodeRepository) {

    override val notesMaxLength get() = NOTES_MAX_LENGTH
    override var notes: String? = null
        set(value) {
            val notesHaveChanged = value != timeOffRequestDetailsModel.value.notes

            if (notesHaveChanged != canUpdate.value) {
                canUpdate.postValue(notesHaveChanged)
            }

            field = value
        }

    override val canUpdate: PublishSubject<Boolean> = PublishSubject(false, uiScope)
    override val editSucceeded: PublishSubject<Boolean?> = PublishSubject(false, uiScope)
    override val userMessage: PublishSubject<StringDesc?> = PublishSubject(null, uiScope)

    private suspend fun patchTimeOffRequest(
        requestBody: AgentTimeOffRequestPatch,
        successMessage: StringResource,
        failureMessage: StringResource
    ) {
        val response = patchUsersTimeOffRequest(
            requestBody = requestBody,
            userTorId = timeOffRequestDetailsModel.value.id
        )

        userMessage.postValue(
            when (response) {
                null -> failureMessage.desc()
                else -> successMessage.desc()
            }
        )

        editSucceeded.postValue(response != null)
    }

    override fun cancelTimeOffRequest(): Job? {
        if (!timeOffRequestDetailsModel.value.canCancelRequest) {
            userMessage.postValue(MR.strings.status_cancel_request_unavailable.desc())
            return null
        }

        return bgScope.launch {
            patchTimeOffRequest(
                requestBody = AgentTimeOffRequestPatch(
                    markedAsRead = true,
                    status = AgentTimeOffRequestPatch.Status.CANCELED,
                    notes = timeOffRequestDetailsModel.value.notes
                ),
                successMessage = MR.strings.status_cancel_request_success,
                failureMessage = MR.strings.status_cancel_request_failure
            )
        }
    }

    override fun updateTimeOffRequest(): Job? {
        if (!canUpdate.value) {
            userMessage.postValue(MR.strings.status_update_request_unavailable.desc())
            return null
        }

        return bgScope.launch {
            patchTimeOffRequest(
                requestBody = AgentTimeOffRequestPatch(
                    notes = notes!!,
                    markedAsRead = true
                ),
                successMessage = MR.strings.status_update_request_success,
                failureMessage = MR.strings.status_update_request_failure
            )
        }
    }

    override fun reset() {
        notes = null
        canUpdate.postValue(false)
        editSucceeded.postValue(null)
        userMessage.postValue(null)

        super.reset()
    }
}
