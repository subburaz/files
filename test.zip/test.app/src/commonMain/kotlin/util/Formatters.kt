package com.genesys.purecloud.wfmshared.util

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.util.resources.CommonStrings
import com.soywiz.klock.DateFormat
import com.soywiz.klock.DateTime
import org.kodein.di.erased.instance

private val commonStrings: CommonStrings by kodein.instance()

fun formatDuration(lengthInMinutes: Int): String {
    val hours = lengthInMinutes / MINUTES_PER_HOUR
    val minutes = lengthInMinutes % MINUTES_PER_HOUR
    val hourAbbreviation = commonStrings.getString(MR.strings.hour_abbreviation)
    val minuteAbbreviation = commonStrings.getString(MR.strings.minute_abbreviation)

    return "$hours$hourAbbreviation $minutes$minuteAbbreviation"
}

const val DATE_FORMAT_ISO8601 = "yyyy-MM-dd"
const val DATE_TIME_FORMAT_ISO8601 = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'"
val dateFormatISO8601 = DateFormat(DATE_FORMAT_ISO8601)
val dateTimeFormatISO8601 = DateFormat(DATE_TIME_FORMAT_ISO8601)
val dateFormatDateWithSlashes: DateFormat by lazy { DateFormat(commonStrings.getString(MR.strings.date_format_date_with_slashes)) }
val dateFormatDayShort: DateFormat by lazy { DateFormat(commonStrings.getString(MR.strings.date_format_day_short)) }

/**
 * @param year The year
 * @param month The month (1-based, values other than 1-12 will be clamped to that range)
 * @param dateOfMonth The date in the month (1-based, will be clamped with the range 1:maxDaysInMonth)
 */
fun formatToISO8601Date(year: Int, month: Int, dateOfMonth: Int): String {
    return DateTime.createClamped(
        year = year,
        month = month,
        day = dateOfMonth,
        hour = 0,
        minute = 0,
        second = 0,
        milliseconds = 0
    ).format(dateFormatISO8601)
}
