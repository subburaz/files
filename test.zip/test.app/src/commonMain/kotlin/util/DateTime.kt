package com.genesys.purecloud.wfmshared.util

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.purecloudapi.entities.ManagementUnit.StartDayOfWeek
import com.genesys.purecloud.wfmshared.util.resources.CommonStrings
import org.kodein.di.erased.instance

const val GMT_TIME_ZONE_NAME = "GMT"
val DEFAULT_START_DAY_OF_WEEK = StartDayOfWeek.SUNDAY
const val DEFAULT_TIME_ZONE_NAME = GMT_TIME_ZONE_NAME
const val SECONDS_PER_MINUTE = 60
const val MINUTES_PER_HOUR = 60
const val HOURS_PER_DAY = 24
const val HOURS_PER_HALF_DAY = 12
const val DAYS_PER_WEEK = 7
const val DAYS_PER_YEAR = 365
const val SECONDS_PER_DAY = HOURS_PER_DAY * MINUTES_PER_HOUR * SECONDS_PER_MINUTE
const val DEFAULT_DAY_START_IN_MINUTES = 480

// This is the default length of a time off if it is partial day
const val DEFAULT_DURATION_IN_MINUTES = 120
const val AM = "AM"
const val PM = "PM"
const val INVALID_DATE_FORMAT_EXCEPTION_MESSAGE = "DateTime format invalid, valid formats are YYYY-MM-DD, YYYY-MM-DDTHH:MM:SSZ, YYYY-MM-DDTHH:MM:SS.SSSZ"

const val ISO8601_DATE_FORMAT = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'"

/**
 * This class is responsible for representing, formatting, and comparing a date with a time.
 */
expect class DateTime : Comparable<DateTime> {
    fun plusSeconds(seconds: Int): DateTime
    fun minusSeconds(seconds: Int): DateTime

    fun plusMinutes(minutes: Int): DateTime
    fun minusMinutes(minutes: Int): DateTime

    fun plusDays(days: Int): DateTime
    fun minusDays(days: Int): DateTime

    fun startOfDay(timeZoneName: String = DEFAULT_TIME_ZONE_NAME): DateTime

    fun startOfWeek(timeZoneName: String = DEFAULT_TIME_ZONE_NAME, startDayOfWeek: StartDayOfWeek): DateTime

    override fun equals(other: Any?): Boolean
    override fun hashCode(): Int
    override operator fun compareTo(other: DateTime): Int

    /**
     * Whether this date and the given date are both either observing DST or not observing DST for the given timezone.
     */
    fun crossesDst(endDate: DateTime, timeZoneName: String = DEFAULT_TIME_ZONE_NAME): Boolean

    /**
     * Formats this date using the given format string pattern for the given timezone.
     */
    internal fun formatDate(formatString: String, timeZoneName: String): String

    /**
     * Determines whether or not this point in time occurs before the given point in time.
     */
    fun isBefore(dateTime: DateTime): Boolean

    /**
     * Determines whether or not this point in time occurs before the given point in time.
     */
    fun isAfter(dateTime: DateTime): Boolean

    companion object {
        /**
         * Parses an ISO String in the formats "YYYY-MM-DD", "YYYY-MM-DDTHH:MM:SSZ", or "YYYY-MM-DDTHH:MM:SS.SSSZ" and returns a DateTime object.
         */
        fun parse(dateString: String): DateTime

        /**
         * Returns a dateTime object representing the current moment in time
         */
        fun now(): DateTime
    }
}

private val commonStrings: CommonStrings by kodein.instance()

/**
 * Formats this date with slashes using a localized string pattern.
 * Example: "01/01/2000"
 */
fun DateTime.formatDateWithSlashes(timeZoneName: String): String {
    return formatDate(commonStrings.getString(MR.strings.date_format_date_with_slashes), timeZoneName)
}

/**
 * Formats this date as the weekday abbreviation using a localized string pattern.
 * Example: "Wed"
 */
fun DateTime.formatWeekdayShort(timeZoneName: String): String {
    return formatDate(commonStrings.getString(MR.strings.date_format_day_short), timeZoneName)
}

/**
 * Formats this time with slashes using a localized string pattern.
 * Example: "12:30 PM"
 */
fun DateTime.formatTime(timeZoneName: String): String {
    return formatDate(commonStrings.getString(MR.strings.date_format_time), timeZoneName)
}

/**
 * Formats this date with hyphens using a localized string pattern.
 * Example: "2000-01-22"
 */
fun DateTime.formatDateWithHyphens(timeZoneName: String): String {
    return formatDate(commonStrings.getString(MR.strings.date_format_date_with_hyphens), timeZoneName)
}

/**
 * Formats this date and Time into ISO 8601 format for the given timezone.
 * Example: "2000-01-22T09:35:06Z"
 */
fun DateTime.formatDateTimeIntoISO8601(): String {
    return formatDate(ISO8601_DATE_FORMAT, GMT_TIME_ZONE_NAME)
}
