package com.genesys.purecloud.wfmshared.util.coroutines

import kotlin.coroutines.CoroutineContext

internal expect val bgContext: CoroutineContext
internal expect val uiContext: CoroutineContext
