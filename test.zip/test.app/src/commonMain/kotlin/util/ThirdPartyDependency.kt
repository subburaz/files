package com.genesys.purecloud.wfmshared.util

data class ThirdPartyDependency(
    val projectName: String,
    val projectLink: String,
    val licenseName: String,
    val licenseLink: String
)

internal expect val thirdPartyDependencies: List<ThirdPartyDependency>

internal val commonDependencies = arrayOf(
    ThirdPartyDependency(
        projectName = "kotlinx.coroutines",
        projectLink = "https://github.com/Kotlin/kotlinx.coroutines",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/Kotlin/kotlinx.coroutines/master/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "kotlin-reflect",
        projectLink = "https://github.com/JetBrains/kotlin/tree/master/core/reflection.jvm/src/kotlin/reflect",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/JetBrains/kotlin/master/license/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "kotlin-stdlib",
        projectLink = "https://github.com/JetBrains/kotlin/tree/master/libraries/stdlib",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/JetBrains/kotlin/master/license/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "kodein-di",
        projectLink = "https://github.com/Kodein-Framework/Kodein-DI",
        licenseName = "MIT License",
        licenseLink = "https://raw.githubusercontent.com/Kodein-Framework/Kodein-DI/master/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "ktor",
        projectLink = "https://github.com/ktorio/ktor",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/ktorio/ktor/master/LICENSE"
    ),

    ThirdPartyDependency(
        projectName = "kotlinx-serialization",
        projectLink = "https://github.com/Kotlin/kotlinx.serialization",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/Kotlin/kotlinx.serialization/master/license/LICENSE.txt"
    ),

    ThirdPartyDependency(
        projectName = "moko-resources",
        projectLink = "https://github.com/icerockdev/moko-resources",
        licenseName = "Apache 2.0",
        licenseLink = "https://raw.githubusercontent.com/icerockdev/moko-resources/master/LICENSE.md"
    ),

    ThirdPartyDependency(
        projectName = "klock",
        projectLink = "https://github.com/korlibs/klock",
        licenseName = "Creative Commons Zero v1.0 Universal",
        licenseLink = "https://raw.githubusercontent.com/korlibs/klock/master/LICENSE"
    )
)
