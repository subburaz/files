package com.genesys.purecloud.wfmshared.util

internal expect object Logger {
    fun logVerbose(tag: String, message: String, cause: Throwable? = null)
    fun logDebug(tag: String, message: String, cause: Throwable? = null)
    fun logError(tag: String, message: String, cause: Throwable? = null)
}
