package com.genesys.purecloud.wfmshared.util

import com.genesys.purecloud.wfmshared.purecloudapi.PureCloudApiData
import io.ktor.client.HttpClient
import io.ktor.client.features.UserAgent
import io.ktor.client.features.defaultRequest
import io.ktor.client.request.header
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonConfiguration

/**
 * @Note Dependency injection frameworks that support kotlin multi-platform are still in their infancy.
 *       For now use a very basic service locator instead.
 * @Note Ideally this would be an object, but in Kotlin Multi-platform objects are frozen when accessed from different threads.
 *       By using a class we allow this to be mutable via the parent.
 */
class ServiceLocator {
    val jsonSerializer: Json by lazy {
        Json(JsonConfiguration.Stable.copy(ignoreUnknownKeys = true))
    }

    /**
     * apiData is nullable because this shared library relies on having valid api data.
     * Since there is no way to enforce that the consumer of the library properly initialized the apiData,
     * null is used so that the code that uses this package internal service locator can detect that cause and log the error.
     */
    var apiData: PureCloudApiData? = null
        private set

    var localeData: LocaleData = LocaleData()
        private set

    var httpClient: HttpClient = this.generateHttpClient()
        private set

    private fun generateHttpClient(): HttpClient {
        return HttpClient {
            install(UserAgent) {
                agent = apiData?.userAgent ?: ""
            }

            defaultRequest {
                header("Accept", "*/*")
                header("Authorization", "bearer ${apiData?.accessToken ?: ""}")
            }
        }
    }

    fun initializeApiData(apiUrl: String, accessToken: String, userAgent: String) {
        apiData = PureCloudApiData(
            apiUrl = apiUrl,
            accessToken = accessToken,
            userAgent = userAgent
        )
        httpClient = generateHttpClient()
    }

    fun resetApiData() {
        apiData = null
    }

    fun initializeLocaleData(languageCode: String, scriptCode: String, regionCode: String, variantCode: String) {
        localeData = LocaleData(
            languageCode = languageCode,
            scriptCode = scriptCode,
            regionCode = regionCode,
            variantCode = variantCode
        )
    }

    fun reset() {
        apiData = null
        localeData = LocaleData()
        httpClient = this.generateHttpClient()
    }

    companion object TestUtils {
        fun setHttpClient(locator: ServiceLocator, client: HttpClient) {
            locator.httpClient = client
        }
    }
}
