package com.genesys.purecloud.wfmshared.util.resources

import com.genesys.purecloud.wfmshared.MR
import dev.icerock.moko.resources.StringResource
import dev.icerock.moko.resources.desc.StringDesc
import dev.icerock.moko.resources.desc.desc

private val common: List<StringResource> = listOf(
    MR.strings.date_format_time,
    MR.strings.date_format_day_short,
    MR.strings.date_format_date_with_slashes,
    MR.strings.date_format_date_with_hyphens,
    MR.strings.hour_abbreviation,
    MR.strings.minute_abbreviation
)

private val resourceDescriptionMap: Map<StringResource, StringDesc> = common.map {
    it to it.desc()
}.toMap()

class CommonStrings {
    private var commonStrings: Map<StringResource, String> = emptyMap()

    val resourceMap = resourceDescriptionMap

    fun getString(resource: StringResource): String {
        return commonStrings[resource] ?: throw Exception("CommonStrings.getString: common string not found for resource $resource")
    }

    fun update(stringMap: Map<StringResource, String>) {
        commonStrings = stringMap
    }
}
