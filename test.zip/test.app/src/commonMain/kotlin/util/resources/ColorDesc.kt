package com.genesys.purecloud.wfmshared.util.resources

class ColorDesc(hexColor: String) {
    internal val aarrggbb = formatToAARRGGBB(hexColor)
}
