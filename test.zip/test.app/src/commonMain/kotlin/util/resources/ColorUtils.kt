package com.genesys.purecloud.wfmshared.util.resources

private const val VALIDATION_REGEX_RGB = "^#[\\p{XDigit}]{3}$"
private const val VALIDATION_REGEX_RRGGBB = "^#[\\p{XDigit}]{6}$"
private const val VALIDATION_REGEX_AARRGGBB = "^#[\\p{XDigit}]{8}$"

internal const val HEX_COLOR_VALUE_START_INDEX = 1

internal const val HEX_COLOR_RGB_R_INDEX = 0
internal const val HEX_COLOR_RGB_G_INDEX = 1
internal const val HEX_COLOR_RGB_B_INDEX = 2

internal enum class ColorDescSourceType {
    RGB,
    RRGGBB,
    AARRGGBB,
    INVALID
}

internal fun getSourceType(hexColor: String): ColorDescSourceType {
    if (VALIDATION_REGEX_RGB.toRegex().matchEntire(hexColor) != null) {
        return ColorDescSourceType.RGB
    }

    if (VALIDATION_REGEX_RRGGBB.toRegex().matchEntire(hexColor) != null) {
        return ColorDescSourceType.RRGGBB
    }

    if (VALIDATION_REGEX_AARRGGBB.toRegex().matchEntire(hexColor) != null) {
        return ColorDescSourceType.AARRGGBB
    }

    return ColorDescSourceType.INVALID
}

internal fun formatToAARRGGBB(hexColor: String): String {
    val sourceType = getSourceType(hexColor)
    val hashlessHexColor = hexColor.substring(HEX_COLOR_VALUE_START_INDEX)

    return when (sourceType) {
        ColorDescSourceType.RGB -> {
            val r = hashlessHexColor[HEX_COLOR_RGB_R_INDEX]
            val g = hashlessHexColor[HEX_COLOR_RGB_G_INDEX]
            val b = hashlessHexColor[HEX_COLOR_RGB_B_INDEX]
            "#FF$r$r$g$g$b$b"
        }
        ColorDescSourceType.RRGGBB -> "#FF$hashlessHexColor"
        ColorDescSourceType.AARRGGBB -> hexColor
        ColorDescSourceType.INVALID -> throw Exception("formatToAARRGGBB - Invalid color $hexColor")
    }
}
