package com.genesys.purecloud.wfmshared.util.resources

enum class CommonColors(hexColor: String) {
    TOR_APPROVED("#5CB300"),
    TOR_DENIED("#FF0000"),
    TOR_CANCELED("#9CA1A3"),
    TOR_PENDING("#EBC56C"),

    CATEGORY_ON_QUEUE_WORK("#B5EAFC"),
    CATEGORY_BREAK("#E1C4AE"),
    CATEGORY_MEAL("#F6E2AC"),
    CATEGORY_MEETING("#F8B0B0"),
    CATEGORY_OFF_QUEUE_WORK("#D0AEA8"),
    CATEGORY_TIME_OFF("#EDC1F0"),
    CATEGORY_TRAINING("#B4E5D1"),
    CATEGORY_UNAVAILABLE("#CFCFCF")
    ;

    val description = ColorDesc(hexColor)
}
