package com.genesys.purecloud.wfmshared.util.resources

const val CREATE_TOR_EVENT = "create_tor"
const val EDIT_TOR_EVENT = "edit_tor"
const val LOGOUT_EVENT = "logout"

const val LOGIN_SCREEN = "login_screen"
const val VIEW_TOR_LIST_SCREEN = "view_tor_list_screen"
const val CREATE_TOR_SCREEN = "create_tor_screen"
const val DETAIL_SCREEN = "detail_tor_screen"
const val EDIT_SCREEN = "edit_tor_screen"
const val SCHEDULE_SCREEN = "schedule_screen"
const val SETTINGS_SCREEN = "settings_screen"
