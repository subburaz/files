package com.genesys.purecloud.wfmshared.util

import com.genesys.purecloud.wfmshared.MR
import com.genesys.purecloud.wfmshared.kodein
import com.genesys.purecloud.wfmshared.util.resources.CommonStrings
import org.kodein.di.erased.instance

private val commonStrings: CommonStrings by kodein.instance()

class TimeDuration(val lengthInMinutes: Int) {
    val hours
        get() = lengthInMinutes / MINUTES_PER_HOUR

    val minutes
        get() = lengthInMinutes % MINUTES_PER_HOUR

    override fun toString(): String {
        val hourAbbreviation = commonStrings.getString(MR.strings.hour_abbreviation)
        val minuteAbbreviation = commonStrings.getString(MR.strings.minute_abbreviation)

        return "$hours$hourAbbreviation $minutes$minuteAbbreviation"
    }
}
