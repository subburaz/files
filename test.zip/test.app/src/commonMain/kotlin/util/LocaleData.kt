package com.genesys.purecloud.wfmshared.util

const val DEFAULT_LANGUAGE_CODE = "en"
const val DEFAULT_SCRIPT_CODE = ""
const val DEFAULT_REGION_CODE = "US"
const val DEFAULT_VARIANT_CODE = ""

data class LocaleData(
    val languageCode: String = DEFAULT_LANGUAGE_CODE,
    val scriptCode: String = DEFAULT_SCRIPT_CODE,
    val regionCode: String = DEFAULT_REGION_CODE,
    val variantCode: String = DEFAULT_VARIANT_CODE
) {
    val localeIdentifier get() = "${languageCode}_$regionCode"

    companion object {
        val defaultLocalIdentifier get() = "${DEFAULT_LANGUAGE_CODE}_$DEFAULT_REGION_CODE"
    }
}
