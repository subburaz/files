package com.genesys.purecloud.wfmshared.util

import com.genesys.purecloud.wfmshared.presentation.viewmodels.IScheduleViewModel
import com.genesys.purecloud.wfmshared.util.resources.CommonStrings
import com.genesys.purecloud.wfmshared.viewmodels.ISettingsViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestCreateViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestDetailsViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestEditViewModel
import com.genesys.purecloud.wfmshared.viewmodels.ITimeOffRequestListViewModel
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.erased.instance

class ViewModelProvider(override val kodein: Kodein) : KodeinAware {
    val timeOffRequestListViewModel: ITimeOffRequestListViewModel by instance()
    val timeOffRequestDetailsViewModel: ITimeOffRequestDetailsViewModel by instance()
    val timeOffRequestEditViewModel: ITimeOffRequestEditViewModel by instance()
    val timeOffRequestCreateViewModel: ITimeOffRequestCreateViewModel by instance()
    val scheduleViewModel: IScheduleViewModel by instance()
    val settingsViewModel: ISettingsViewModel by instance()
    val commonStrings: CommonStrings by instance()
}
