package com.genesys.purecloud.wfmshared.util

import com.soywiz.klock.DateTime
import com.soywiz.klock.DateTimeTz

val DateTimeTz.startOfDay: DateTime
    get() = DateTime.createClamped(
        year = yearInt,
        month = month1,
        day = dayOfMonth,
        hour = 0,
        minute = 0,
        second = 0,
        milliseconds = 0
    )
