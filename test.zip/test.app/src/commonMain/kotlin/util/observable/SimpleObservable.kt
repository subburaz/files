package com.genesys.purecloud.wfmshared.util.observable

import com.genesys.purecloud.wfmshared.util.coroutines.WFMSharedScope
import com.genesys.purecloud.wfmshared.util.coroutines.uiContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

open class SimpleObservable<T>(
    protected val scope: CoroutineScope = WFMSharedScope(uiContext)
) : Observable<T> {
    private val observers = mutableListOf<Observer<T>> ()

    /**
     * Adds the given observer to the observers list and posts the current value of this observable to the newly added observer.
     */
    override fun observe(newObserver: Observer<T>): Job {
        return scope.launch {
            observers.add(newObserver)
        }
    }

    /**
     * Removes the given observer from the observers list.
     */
    override fun removeObserver(observerToRemove: Observer<T>): Job {
        return scope.launch {
            observers.remove(observerToRemove)
        }
    }

    /**
     * Posts a task to the observables coroutine scope to set the given value.
     * If there are any observers they will receive the new value.
     */
    internal open fun postValue(newValue: T) =
        scope.launch {
        observers.forEach {
            it(newValue)
        }
    }
}

internal inline fun <T> SimpleObservable<Boolean>.doLoad(block: () -> T) =
    try {
        this.postValue(true)
        block()
    } finally {
        this.postValue(false)
    }
