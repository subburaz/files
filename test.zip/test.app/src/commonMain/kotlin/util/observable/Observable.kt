package com.genesys.purecloud.wfmshared.util.observable

import kotlinx.coroutines.Job

typealias Observer<T> = (T) -> Unit

interface Observable<out T> {
    /**
     * Adds the given observer to the observers list and posts the current value of this observable
     * to the newly added observer.
     */
    fun observe(newObserver: Observer<T>): Job

    /**
     * Removes the given observer from the observers list.
     */
    fun removeObserver(observerToRemove: Observer<T>): Job
}
