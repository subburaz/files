package com.genesys.purecloud.wfmshared.util.observable

import com.genesys.purecloud.wfmshared.util.coroutines.WFMSharedScope
import com.genesys.purecloud.wfmshared.util.coroutines.uiContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Manages a value and publishes changes of that value to all observers.
 *
 * @param T The type of the value to manage.
 * @property value The initial value this observerable manages.
 * @property scope The coroutine scope to use for setting values and notifying observers, defaults to a UI thread scope.
 */
open class PublishSubject<T>(
    initialValue: T,
    scope: CoroutineScope = WFMSharedScope(uiContext)
) : Subject<T>, SimpleObservable<T>(scope) {
    final override var value = initialValue
        private set

    override fun observe(newObserver: Observer<T>): Job {
        super.observe(newObserver)

        return scope.launch {
            newObserver(value)
        }
    }

    /**
     * Posts a task to the observables coroutine scope to set the given value.
     * If there are any observers they will receive the new value.
     */
    override fun postValue(newValue: T): Job {
        value = newValue

        return super.postValue(newValue)
    }
}
