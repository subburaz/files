package com.genesys.purecloud.wfmshared.util.observable

/**
 * Provides access to a value and allows observing changes to that value.
 *
 * @param T The type of the value to observe.
 */
interface Subject<out T> :
    Observable<T> {

    /**
     * The current value.
     */
    val value: T
}
