package com.genesys.purecloud.wfmshared.util

class NamedItem<T>(val item: T, private val name: String) {
    override fun toString(): String = name
}
