package com.genesys.purecloud.wfmshared

import com.genesys.purecloud.wfmshared.di.dataModule
import com.genesys.purecloud.wfmshared.di.domainModule
import com.genesys.purecloud.wfmshared.di.infrastructureModule
import com.genesys.purecloud.wfmshared.di.presentationModule
import com.genesys.purecloud.wfmshared.util.ServiceLocator
import org.kodein.di.Kodein
import org.kodein.di.erased.instance

// warning: defining modules as val properties instead of functions crashes on iOS
val kodein = Kodein {
    importAll(
        infrastructureModule(),
        dataModule(),
        domainModule(),
        presentationModule()
    )
}

private val authListener: AuthenticationListener by kodein.instance()

val serviceLocator: ServiceLocator by lazy {
    ServiceLocator()
}

fun initializeApi(apiUrl: String, accessToken: String, userAgent: String) {
    authListener.loggedIn(AuthenticationData(apiUrl, accessToken, userAgent))

    serviceLocator.initializeApiData(
        apiUrl = apiUrl,
        accessToken = accessToken,
        userAgent = userAgent
    )
}

fun resetApi() {
    serviceLocator.resetApiData()

    authListener.loggedOut()
}

fun setLocale(languageCode: String, scriptCode: String, regionCode: String, variantCode: String) {
    serviceLocator.initializeLocaleData(
        languageCode = languageCode,
        scriptCode = scriptCode,
        regionCode = regionCode,
        variantCode = variantCode
    )
}
