package com.genesys.purecloud.wfmshared.domain.entities

data class ActivityCode(
    /* The globally unique identifier for the object. */
    val id: String,

    /* The name of the activity code. Default activity codes will be created with an empty name */
    val name: String,

    /* Whether this activity code is active or has been deleted */
    val isActive: Boolean,

    /* Whether this is a default activity code */
    val isDefault: Boolean,

    /* The activity code's category. */
    val category: Category,

    /* The default length of the activity in minutes */
    val lengthInMinutes: Int,

    /* Whether an agent is paid while performing this activity */
    val countsAsPaidTime: Boolean,

    /* Indicates whether or not the activity should be counted as contiguous work time for calculating daily constraints */
    val countsAsWorkTime: Boolean,

    /* Whether an agent can select this activity code when creating or editing a time off request. Null if the activity's category is not time off. */
    val agentTimeOffSelectable: Boolean?
) {
    enum class Category {
        ON_QUEUE,
        BREAK,
        MEAL,
        MEETING,
        OFF_QUEUE_WORK,
        TIME_OFF,
        TRAINING,
        UNAVAILABLE,
        UNSCHEDULED;
    }
}
