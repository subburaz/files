package com.genesys.purecloud.wfmshared.domain.entities

import com.soywiz.klock.DateTime

data class Shift(
    val startDate: DateTime,
    val lengthInMinutes: Int,
    val activities: List<Activity>
)
