package com.genesys.purecloud.wfmshared.domain.entities

import com.soywiz.klock.DateTime

data class Activity(
    val category: ActivityCode.Category,
    val startTime: DateTime,
    val lengthInMinutes: Int,
    val description: String?,
    val countsAsPaidTime: Boolean
)
