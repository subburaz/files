package com.genesys.purecloud.wfmshared.domain.usecases

import com.genesys.purecloud.wfmshared.domain.common.UseCase
import com.genesys.purecloud.wfmshared.domain.entities.Shift
import com.genesys.purecloud.wfmshared.domain.repositories.IUserScheduleRepository
import com.soywiz.klock.YearMonth

class GetScheduleUseCase(
    private val repository: IUserScheduleRepository
) : UseCase<YearMonth, List<Shift>> {
    override suspend fun invoke(param: YearMonth) = repository.getUserSchedule(param)
}
