package com.genesys.purecloud.wfmshared.domain.common

import io.ktor.http.HttpStatusCode

class NetworkException(val status: HttpStatusCode) : Exception("Network Exception $status") {
    constructor(status: Int) : this(HttpStatusCode.fromValue(status))
}
