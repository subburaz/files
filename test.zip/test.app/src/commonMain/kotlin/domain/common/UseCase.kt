package com.genesys.purecloud.wfmshared.domain.common

interface UseCase<in P, out R> where R : Any {
    suspend operator fun invoke(param: P): Result<R>
}
