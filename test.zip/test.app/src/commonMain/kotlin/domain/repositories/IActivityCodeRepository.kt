package com.genesys.purecloud.wfmshared.domain.repositories

import com.genesys.purecloud.wfmshared.domain.common.Result
import com.genesys.purecloud.wfmshared.domain.entities.ActivityCode

interface IActivityCodeRepository {
    suspend fun getActivityCodes(): Result<Map<String, ActivityCode>>
}
