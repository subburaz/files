package com.genesys.purecloud.wfmshared.domain.repositories

import com.genesys.purecloud.wfmshared.domain.common.Result
import com.genesys.purecloud.wfmshared.domain.entities.Shift
import com.soywiz.klock.YearMonth

interface IUserScheduleRepository {
    suspend fun getUserSchedule(month: YearMonth): Result<List<Shift>>
}
